<!-- Meta Title Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('meta_title', 'Meta Title:'); ?>

    <?php echo Form::text('meta_title', null, ['class' => 'form-control']); ?>

</div>

<!-- Meta Content Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('meta_content', 'Meta Content:'); ?>

    <?php echo Form::text('meta_content', null, ['class' => 'form-control']); ?>

</div>

<!-- Meta Og Title Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('meta_og_title', 'Meta Og Title:'); ?>

    <?php echo Form::text('meta_og_title', null, ['class' => 'form-control']); ?>

</div>

<!-- Meta Og Content Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('meta_og_content', 'Meta Og Content:'); ?>

    <?php echo Form::text('meta_og_content', null, ['class' => 'form-control']); ?>

</div><?php /**PATH C:\xampp\htdocs\blog\resources\views/meta_seos/fields.blade.php ENDPATH**/ ?>