<div class="table-responsive">
    <table class="table" id="bannerHomes-table">
        <thead>
        <tr>
            <th>Banner</th>
            <th colspan="3">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $bannerHomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bannerHome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($bannerHome->banner); ?></td>
                <td width="120">
                    <?php echo Form::open(['route' => ['bannerHomes.destroy', $bannerHome->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('bannerHomes.show', [$bannerHome->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-eye"></i>
                        </a>
                        <a href="<?php echo e(route('bannerHomes.edit', [$bannerHome->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-edit"></i>
                        </a>
                        <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\Users\cuong123\Desktop\New folder (2)\blog\resources\views/banner_homes/table.blade.php ENDPATH**/ ?>