<?php $__env->startSection('content'); ?>
<?php  

    $news =  new \App\Models\post();

    $news = $news->orderBy('id')->take(10)->get();

?>
<div class="box_breadcrumb">
    <div class="container">
        <ul class="breadcrumb">
            <li><a href="/">Trang chủ</a></li>
            <li><a href="/tin-tuc-su-kien" title="Tin Tức / Sự Kiện">Tin Tức / Sự Kiện</a></li>
        </ul>
    </div>
</div>
<div class="container">
    <div class="wrapper">
        <div class="row">
            <div class="col-sm-8">
                <div class="box_module">
                    <div class="box_title">
                        <h1 class="title"><a href="/tin-tuc-su-kien" title="Tin Tức / Sự Kiện">Tin Tức / Sự Kiện</a></h1>
                    </div>
                    <div class="box_content">
                        <div class="layout_category_default">
                            <?php if(count($news)>0): ?>
                            <?php for($i=0; $i<3; $i++): ?>
                            <div class="item">
                                <div class="image"><a href="<?php echo e(route('single', @$news[$i]['link'])); ?>" title="<?php echo e(@$news[$i]['title']); ?>"><img src="<?php echo e(@url($news[$i]['image'])); ?>" alt="<?php echo e(@$news[$i]['title']); ?>"></a></div>
                                <div class="info">
                                    <h2 class="title"><a href="<?php echo e(route('single', @$news[$i]['link'])); ?>" title="<?php echo e(@$news[$i]['title']); ?>">BẢO LÃNH BẢO HIỂM GENERALI TẠI NHA KHOA WIN SMILE</a></h2>
                                    <div class="desc hidden-xs"> ... <a href="/bao-lanh-bao-hiem-generali-tai-nha-khoa-win-smile">Xem thêm</a></div>
                                    <div class="time"><span class="category">Chuyên mục <a href="/tin-tuc" title="Tin tức">Tin tức</a></span><span class="date">Ngày 20/11/2021</span></div>
                                </div>
                            </div>
                            <?php endfor; ?>
                            <?php endif; ?>

                           
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="box_pagination">
                                    <a href="javascript:;" class="active">1</a> <a href="/tin-tuc-su-kien/page/2">2</a> <a href="/tin-tuc-su-kien/page/3">3</a> <a href="/tin-tuc-su-kien/page/4">4</a> <a href="/tin-tuc-su-kien/page/5">5</a> <a href="/tin-tuc-su-kien/page/2" class="next">Next</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 hidden-xs">
                <div style="padding-left: 20px;">
                    <div class="box_adsRight" id="box_adsRight">
                        <a href="" title="Ảnh 1"><img src="<?php echo e(('public/files/upload/default/images/quang-cao/ads-right.jpg')); ?>" alt="Ảnh 1"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="box_defaultCategoryHot">
    <div class="container">
        <div class="box_title">
            <h2 class="title"><a href="/blog" title="Blog kiến thức">Blog kiến thức</a></h2>
            <a href="/blog" class="view_all">Xem tất cả</a>
        </div>
        <div class="box_content">
            <div class="row">
                
               
                <?php if(count($news)>=9): ?>
                <?php for($i=3; $i<10; $i++): ?>
                <div class="col-sm-4 col-xs-6">
                    <div class="item">
                        <div class="image">
                            <a href="<?php echo e(route('single', @$news[$i]['link'])); ?>" title="<?php echo e(@$news[$i]['title']); ?>"><img src="<?php echo e(@url($news[$i]['image'])); ?>" alt="Viêm lợi sau khi bọc răng sứ. Nguyên nhân và cách khắc phục."><span>Xem thêm</span></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/viem-loi-sau-khi-boc-rang-su-nguyen-nhan-va-cach-khac-phuc" title="<?php echo e(@$news[0]['title']); ?>"></a></h3>
                           
                            <div class="desc"><?php echo @_substr($news[$i]['content'], 150); ?> <a href="<?php echo e(route('single', @$news[$i]['link'])); ?>">Xem thêm</a></div>
                        </div>
                    </div>
                </div>
                <?php endfor; ?>
                <?php endif; ?>
              
            </div>
        </div>
       <!--  <div class="control"><a href="/blog" class="btn_yellow">Xem tất cả Blog kiến thức</a></div> -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cuong123\Desktop\New folder (2)\blog\resources\views/frontend/blog.blade.php ENDPATH**/ ?>