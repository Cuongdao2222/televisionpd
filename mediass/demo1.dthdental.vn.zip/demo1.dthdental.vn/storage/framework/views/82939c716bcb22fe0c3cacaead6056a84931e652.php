<!DOCTYPE html>
<html>
    <head>
        <title>Nha Khoa Thẩm Mỹ Quốc Tế Win Smile</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="">
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta property="og:type" content="website">
        <meta property="og:title" content="Nha Khoa Thẩm Mỹ Quốc Tế Win Smile">
        <meta property="og:description" content="">
        <meta property="og:image" content="">
        <link href="<?php echo e(asset('public/files/upload/default/images/he-thong/favicon.png')); ?>" rel="icon" type="image/x-icon">
        <link href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css')}}" media="screen" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('public/template/frontend/css/bootstrap.min.css')); ?>" media="screen" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('public/template/frontend/css/fontawesome-all.min.css')); ?>" media="screen" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('public/template/frontend/plugins/fancybox/source/jquery.fancybox.css')); ?>" media="screen" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('public/template/frontend/plugins/fancybox/source/jquery.fancybox-thumbs.css')); ?>" media="screen" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('public/template/frontend/plugins/bxslider/jquery.bxslider.css')); ?>" media="screen" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('public/template/frontend/css/font.css?v=24112021014725')); ?>" media="screen" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('public/template/frontend/css/style.css?v=24112021014725')); ?>" media="screen" rel="stylesheet" type="text/css">
        <!-- Facebook Pixel Code -->
       <!--  <script>
            !function(f,b,e,v,n,t,s)
            {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window, document,'script',
            'https://connect.facebook.net/en_US/fbevents.js');
            fbq('init', '3293259967564888');
            fbq('track', 'PageView');
        </script> -->
        <noscript><img height="1" width="1" style="display:none"
            src="https://www.facebook.com/tr?id=3293259967564888&ev=PageView&noscript=1"
            /></noscript>
        <!-- End Facebook Pixel Code -->
        <!-- Facebook Pixel Code -->
       <!--  <script>
            !function(f,b,e,v,n,t,s)
            {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window, document,'script',
            'https://connect.facebook.net/en_US/fbevents.js');
            fbq('init', '640609279887826');
            fbq('track', 'PageView');
        </script> -->
        <noscript><img height="1" width="1" style="display:none"
            src="https://www.facebook.com/tr?id=640609279887826&ev=PageView&noscript=1"
            /></noscript>
        <!-- End Facebook Pixel Code -->
        <!-- Google Tag Manager -->
       
        <!-- End Google Tag Manager -->
    </head>
    <body class="body">
        <!-- Global site tag (gtag.js) - Google Analytics -->
       
       
        <div id="fb-root"></div>
        
      
        <div id="fb-root"></div>
       
        <!-- Start of widget script <script type="text/javascript">function loadJsAsync(t,e){var n=document.createElement("script");n.type="text/javascript",n.src=t,n.addEventListener("load",function(t){e(null,t)},!1);var a=document.getElementsByTagName("head")[0];a.appendChild(n)}window.addEventListener("DOMContentLoaded",function(){loadJsAsync("https://webchat.caresoft.vn:8090/js/CsChat.js?v=2.0",function(){var t={domain:"WINSMILE"};embedCsChat(t)})},!1);</script> -->
        <!-- Google Tag Manager (noscript) -->
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P3BBXGG"
            height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
        <!-- End Google Tag Manager (noscript) -->    
        <div class="box_top hidden-xs">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="hotline">
                            <span class="item">Hà Nội: <a href="tel:0966688234">0966.688.234</a></span>
                            <span class="item">TP.Hồ Chí Minh: <a href="tel:0966688234">0966 688 234</a></span>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="social">
                            <a href="https://www.facebook.com/nhakhoaquoctewinsmile" target="_blank"><img src="<?php echo e(asset('public/template/frontend/img/icon_2.png')); ?>"></a>
                            <a href="" target="_blank"><img src="<?php echo e(asset('public/template/frontend/img/icon_3.png')); ?>"></a>
                            <a href="https://www.youtube.com/channel/UCuhJRuawEhoFPDMZkzts7og" target="_blank"><img src="<?php echo e(asset('public/template/frontend/img/icon_4.png')); ?>"></a>
                        </div>
                        <div class="open">
                            <span class="item">Giờ mở cửa: <span>8h00 - 20h00</span></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="box_header" id="box_header">
            <div class="container">
                <div class="box_content">
                    <div class="item menu">
                        <div class="box_menuMain2 left">
                            <ul>
                                <li class="dropdown" data-level="2">
                                    <a href="/rang-su-tham-my" target="_self" class=""><span class="title">Răng sứ</span></a>
                                    <div class="dropdown_wrap">
                                        <ul>
                                            <li class="dropdown" data-level="3">
                                                <a href="/dan-su" target="_self" class=""><span class="title">Dán sứ</span></a>
                                                <div class="dropdown_wrap">
                                                    <ul>
                                                        <li data-level="4" data-max="3" data-key="3"><a href="/dan-su-veneer-lisi" target="_self" class=""><span class="title">Dán sứ Veneer Lisi</span></a></li>
                                                        <li data-level="4" data-max="3" data-key="4"><a href="/dan-su-veneer" target="_self" class=""><span class="title">Dán sứ Veneer Emax Laminate</span></a></li>
                                                        <li data-level="4" data-max="3" data-key="5"><a href="/dan-su-suon-ziconia" target="_self" class=""><span class="title">Dán sứ sườn Ziconia</span></a></li>
                                                    </ul>
                                                </div>
                                            </li>
                                            <li class="dropdown" data-level="3">
                                                <a href="/boc-su" target="_self" class=""><span class="title">Bọc sứ</span></a>
                                                <div class="dropdown_wrap">
                                                    <ul>
                                                        <li data-level="4" data-max="3" data-key="7"><a href="/rang-su-orodent" target="_self" class=""><span class="title">Răng sứ Orodent</span></a></li>
                                                        <li data-level="4" data-max="3" data-key="8"><a href="/rang-su-biodiamond" target="_self" class=""><span class="title">Răng sứ Biodiamond</span></a></li>
                                                        <li data-level="4" data-max="3" data-key="9"><a href="/rang-su-lava-3m" target="_self" class=""><span class="title">Răng sứ Lava 3M</span></a></li>
                                                        <li data-level="4" data-max="3" data-key="10"><a href="/rang-su-nacera-q3" target="_self" class=""><span class="title">Răng sứ Nacera Q3</span></a></li>
                                                        <li data-level="4" data-max="3" data-key="11"><a href="/rang-su-nacera" target="_self" class=""><span class="title">Răng sứ Nacera</span></a></li>
                                                        <li data-level="4" data-max="3" data-key="12"><a href="/rang-su-ht-smile" target="_self" class=""><span class="title">Răng sứ HT Smile</span></a></li>
                                                        <li data-level="4" data-max="3" data-key="13"><a href="/rang-su-ceramill" target="_self" class=""><span class="title">Răng sứ Ceramill</span></a></li>
                                                        <li data-level="4" data-max="3" data-key="14"><a href="/rang-su-venus" target="_self" class=""><span class="title">Răng sứ Venus</span></a></li>
                                                        <li data-level="4" data-max="3" data-key="15"><a href="/rang-su-katana" target="_self" class=""><span class="title">Răng sứ Katana</span></a></li>
                                                        <li data-level="4" data-max="3" data-key="16"><a href="https://winsmile.vn/boc-rang-su" target="_self" class=""><span class="title">Bọc răng sứ</span></a></li>
                                                    </ul>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                               
                            </ul>
                        </div>
                    </div>
                    <div class="item logo"><a href="/"><img src="<?php echo e(asset('public/files/upload/default/images/he-thong/logo.png')); ?>"></a></div>
                    <div class="item menu">
                        <div class="box_menuMain2 right">
                            <ul>
                                <li data-level="2" data-max="1" data-key="1"><a href="/ve-winsmile" target="_self" class=""><span class="title">Về WinSmile</span></a></li>
                                <li data-level="2" data-max="1" data-key="2"><a href="/tin-tuc-su-kien" target="_self" class=""><span class="title">Sự kiện / Blog</span></a></li>
                                <li data-level="2" data-max="1" data-key="3"><a href="/cam-nhan-khach-hang" target="_self" class=""><span class="title">Cảm nhận khách hàng</span></a></li>
                                <li data-level="2" data-max="1" data-key="4"><a href="/lien-he" target="_self" class=""><span class="title">Liên hệ</span></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <a href="/" class="logo_mobile"><img src="<?php echo e(asset('public/files/upload/default/images/he-thong/logo-white.png')); ?>"></a>
            <a href="javascript:;" class="toggle" id="menu_toggle">
            <span class="line"></span>
            <span class="line"></span>
            <span class="line"></span>
            <span class="line"></span>
            </a>
        </div>
        <div class="box_bxslider hidden-xs" id="box_bxslider">
            <div class="box_content">
                <ul class="bxslider">
                    <li><a href=""><img src="<?php echo e(asset('public/files/upload/default/images/Banner/chuong-trinh-uu-dai-thang-11-nha-khoa-win-smile.jpg')); ?>" alt="Win Smile - Thành công từ những nụ cười"></a></li>
                    <li><a href=""><img src="<?php echo e(asset('public/files/upload/default/images/Banner/The-Member-Ship.png')); ?>" alt="Sở hữu thẻ Premium Nha Khoa Win Smile với hàng ngàn ưu đãi"></a></li>
                </ul>
            </div>
        </div>
        <div class="box_bxslider_mobile hidden-sm hidden-md hidden-lg" id="box_bxslider_mobile">
            <div class="box_content">
                <ul class="bxslider">
                    <li><a href=""><img src="<?php echo e(asset('public/files/upload/default/images/Banner/chuong-trinh-uu-dai-thang-11-nha-khoa-win-smile-mobile.jpg')); ?>" alt="Win Smile - Thành công từ những nụ cười"></a></li>
                    <li><a href=""><img src="" alt="Sở hữu thẻ Premium Nha Khoa Win Smile với hàng ngàn ưu đãi"></a></li>
                </ul>
            </div>
        </div>
        <div class="box_defaultHighlightCategory">
            <div class="container">
                <div class="wrapper">
                    <div class="box_wrap">
                        <div class="box_title">
                            <h1 class="title"><a href="/ve-winsmile" title="Về WinSmile">Về D’ Dental</a></h1>
                        </div>
                        <div class="box_content">
                            <p>Được thành lập vào năm 2021 bởi đội ngũ Y Bác Sĩ giàu kinh nghiệm, nhiệt huyết với nghề, Nha khoa D’ Dental mang trong mình sứ mệnh đem đến nụ cười hạnh phúc và tự tin cho khách hàng. Hai yếu tố sức khoẻ và tính thẩm mỹ luôn được đội ngũ của D’ Dental đặt lên hàng đầu trong mọi dịch vụ của phòng khám đẻ đem đến cho khách hàng những trải nghiệm hài lòng nhất tại mọi cơ sở phòng khám của D’ Dental.
                            </p>
                            <div class="controls">
                                <a href="/ve-winsmile" class="view btn_yellow">Xem chi tiết</a>
                                <a href="javascript:;" class="book go_box" data-box="box_book">Đặt lịch khám</a>
                            </div>
                        </div>
                    </div>
                    <div class="image"><img src="<?php echo e(asset('public/files/upload/default/images/bai-viet/gioithieu.png')); ?>" style="
    width: 90%;"></div>
                </div>
            </div>
        </div>
        <div class="box_productCategoryHome">
            <div class="container">
                <div class="box_title">
                    <h2 class="title"><a href="/rang-su-tham-my" title="Răng sứ thẩm mỹ">Răng sứ thẩm mỹ</a></h2>
                    <a href="/rang-su-tham-my" class="view_all">Xem tất cả</a>
                </div>
                <div class="box_desc">Win Smile tập trung cung cấp các dịch vụ nha khoa thẩm mỹ trong môi trường nhẹ nhàng, chu đáo, chuyên nghiệp. Đảm bảo mọi khách hàng tới Win Smile đều có những trải nhiệm nha khoa đẳng cấp, ưng ý nhất cho đường cười của chính mình. </div>
                <div class="box_content">
                    <div class="row productGrid">
                        <div class="col-sm-3 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/dan-su-veneer" title="Dán sứ Veneer Emax Laminate"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/ngo-lan-huong.jpg')); ?>" alt="Dán sứ Veneer Emax Laminate"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/dan-su-veneer" title="Dán sứ Veneer Emax Laminate">Dán sứ Veneer Emax Laminate</a></h3>
                                    <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                </div>
                                <div class="control">
                                    <a href="/dan-su-veneer" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/rang-su-lava-3m" title="Răng sứ Lava 3M Plus"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/quynh-kool.jpg')); ?>" alt="Răng sứ Lava 3M Plus"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/rang-su-lava-3m" title="Răng sứ Lava 3M Plus">Răng sứ Lava 3M Plus</a></h3>
                                    <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                </div>
                                <div class="control">
                                    <a href="/rang-su-lava-3m" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/rang-su-orodent" title="Răng sứ Orodent"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/bui-bich-uyen.jpg')); ?>" alt="Răng sứ Orodent"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/rang-su-orodent" title="Răng sứ Orodent">Răng sứ Orodent</a></h3>
                                    <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                </div>
                                <div class="control">
                                    <a href="/rang-su-orodent" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/rang-su-biodiamond" title="Răng sứ Bio Diamond"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/hoang-phi-huyen.jpg')); ?>" alt="Răng sứ Bio Diamond"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/rang-su-biodiamond" title="Răng sứ Bio Diamond">Răng sứ Bio Diamond</a></h3>
                                    <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                </div>
                                <div class="control">
                                    <a href="/rang-su-biodiamond" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/rang-su-nacera" title="Răng sứ Nacera"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/nguyen-tat-kiem.jpg')); ?>" alt="Răng sứ Nacera"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/rang-su-nacera" title="Răng sứ Nacera">Răng sứ Nacera</a></h3>
                                    <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                </div>
                                <div class="control">
                                    <a href="/rang-su-nacera" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/rang-su-nacera-q3" title="Răng sứ Nacera Q3"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/tran-quang-minh.jpg')); ?>" alt="Răng sứ Nacera Q3"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/rang-su-nacera-q3" title="Răng sứ Nacera Q3">Răng sứ Nacera Q3</a></h3>
                                    <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                </div>
                                <div class="control">
                                    <a href="/rang-su-nacera-q3" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/rang-su-ceramill" title="Răng sứ Ceramill"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/nguyen-quyen.jpg')); ?>" alt="Răng sứ Ceramill"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/rang-su-ceramill" title="Răng sứ Ceramill">Răng sứ Ceramill</a></h3>
                                    <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                </div>
                                <div class="control">
                                    <a href="/rang-su-ceramill" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/dan-su-veneer-lisi" title="Dán sứ Veneer Lisi"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/nguyen-kieu-my.jpg')); ?>" alt="Dán sứ Veneer Lisi"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/dan-su-veneer-lisi" title="Dán sứ Veneer Lisi">Dán sứ Veneer Lisi</a></h3>
                                    <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                </div>
                                <div class="control">
                                    <a href="/dan-su-veneer-lisi" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="control"><a href="/rang-su-tham-my" class="btn_yellow">Xem tất cả dịch vụ thẩm mỹ răng tại Winsmile</a></div>
            </div>
        </div>
        <div class="box_serviceCategoryHome">
            <div class="container">
                <div class="box_title">
                    <h2 class="title"><a href="/nha-khoa-benh-ly" title="Nha khoa bệnh lý">Nha khoa bệnh lý</a></h2>
                    <a href="/nha-khoa-benh-ly" class="view_all">Xem tất cả</a>
                </div>
                <div class="box_desc">Triết lý của WinSmile sẽ giúp bạn khỏe mạnh, hạnh phúc vì chúng tôi hiểu vai trò quan trọng trong sức khỏe răng miệng và chất lượng cuộc sống của bạn.</div>
                <div class="box_content">
                    <div class="slide">
                        <div class="item">
                            <div class="image">
                                <a href="/quy-trinh-tham-kham-tu-van-tai-nha-khoa-win-smile" title="Quy trình thăm khám tư vấn tại Nha Khoa Win Smile"><img src="<?php echo e(asset('public/files/upload/default/medium/images/dich-vu/tay-trang-rang.jpg')); ?>" alt="Quy trình thăm khám tư vấn tại Nha Khoa Win Smile"><span>Xem thêm</span></a>
                            </div>
                            <div class="info">
                                <h3 class="title"><a href="/quy-trinh-tham-kham-tu-van-tai-nha-khoa-win-smile" title="Quy trình thăm khám tư vấn tại Nha Khoa Win Smile">Quy trình thăm khám tư vấn tại Nha Khoa Win Smile</a></h3>
                            </div>
                        </div>
                        <div class="item">
                            <div class="image">
                                <a href="/dieu-tri-cuoi-ho-loi" title="Điều trị cười hở lợi"><img src="<?php echo e(asset('public/files/upload/default/medium/images/dich-vu/dieu-tri-cuoi-hoi-loi.jpg')); ?>" alt="Điều trị cười hở lợi"><span>Xem thêm</span></a>
                            </div>
                            <div class="info">
                                <h3 class="title"><a href="/dieu-tri-cuoi-ho-loi" title="Điều trị cười hở lợi">Điều trị cười hở lợi</a></h3>
                            </div>
                        </div>
                        <div class="item">
                            <div class="image">
                                <a href="/dieu-tri-nha-chu" title="Điều trị nha chu"><img src="<?php echo e(asset('public/files/upload/default/medium/images/dich-vu/dieu-tri-nha-chu-1.jpg')); ?>" alt="Điều trị nha chu"><span>Xem thêm</span></a>
                            </div>
                            <div class="info">
                                <h3 class="title"><a href="/dieu-tri-nha-chu" title="Điều trị nha chu">Điều trị nha chu</a></h3>
                            </div>
                        </div>
                        <div class="item">
                            <div class="image">
                                <a href="/dieu-tri-rang-sau" title="Điều trị răng sâu"><img src="<?php echo e(asset('public/files/upload/default/medium/images/dich-vu/dieu-tri-rang-sau.jpeg')); ?>" alt="Điều trị răng sâu"><span>Xem thêm</span></a>
                            </div>
                            <div class="info">
                                <h3 class="title"><a href="/dieu-tri-rang-sau" title="Điều trị răng sâu">Điều trị răng sâu</a></h3>
                            </div>
                        </div>
                        <div class="item">
                            <div class="image">
                                <a href="/dieu-tri-tuy-rang" title="Điều trị tủy răng"><img src="<?php echo e(asset('public/files/upload/default/medium/images/dich-vu/dieu-tri-tuy-rang.jpg')); ?>" alt="Điều trị tủy răng"><span>Xem thêm</span></a>
                            </div>
                            <div class="info">
                                <h3 class="title"><a href="/dieu-tri-tuy-rang" title="Điều trị tủy răng">Điều trị tủy răng</a></h3>
                            </div>
                        </div>
                        <div class="item">
                            <div class="image">
                                <a href="/tay-trang-rang" title="Tẩy trắng răng"><img src="<?php echo e(asset('public/files/upload/default/medium/images/dich-vu/tay-trang-rang.jpg')); ?>" alt="Tẩy trắng răng"><span>Xem thêm</span></a>
                            </div>
                            <div class="info">
                                <h3 class="title"><a href="/tay-trang-rang" title="Tẩy trắng răng">Tẩy trắng răng</a></h3>
                            </div>
                        </div>
                        <div class="item">
                            <div class="image">
                                <a href="/han-tram-rang" title="Hàn trám răng"><img src="<?php echo e(asset('public/files/upload/default/medium/images/dich-vu/han-tram-rang')); ?>" alt="Hàn trám răng"><span>Xem thêm</span></a>
                            </div>
                            <div class="info">
                                <h3 class="title"><a href="/han-tram-rang" title="Hàn trám răng">Hàn trám răng</a></h3>
                            </div>
                        </div>
                        <div class="item">
                            <div class="image">
                                <a href="/nho-rang-khon" title="Nhổ răng khôn"><img src="<?php echo e(asset('public/files/upload/default/medium/images/san-pham/nho-rang-khon-tai-winsmile.png')); ?>" alt="Nhổ răng khôn"><span>Xem thêm</span></a>
                            </div>
                            <div class="info">
                                <h3 class="title"><a href="/nho-rang-khon" title="Nhổ răng khôn">Nhổ răng khôn</a></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="box_defaultCategoryHome">
            <div class="container">
                <div class="box_title">
                    <h2 class="title"><a href="/tin-tuc-su-kien" title="Tin Tức / Sự Kiện">Tin Tức / Sự Kiện</a></h2>
                </div>
                <div class="box_desc">Các Tin Tức / Sự Kiện nổi bật của hệ thống Nha Khoa Thẩm Mỹ Quốc Tế WinSmile.</div>
                <div class="box_content">
                    <div class="row">
                        <div class="col-sm-6 col-xs-12">
                            <div class="item">
                                <div class="image">
                                    <a href="/bao-lanh-bao-hiem-generali-tai-nha-khoa-win-smile" title="BẢO LÃNH BẢO HIỂM GENERALI TẠI NHA KHOA WIN SMILE"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/bai-viet/bao-hiem-generali-niemtinbaohiem.jpg')); ?>" alt="BẢO LÃNH BẢO HIỂM GENERALI TẠI NHA KHOA WIN SMILE"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/bao-lanh-bao-hiem-generali-tai-nha-khoa-win-smile" title="BẢO LÃNH BẢO HIỂM GENERALI TẠI NHA KHOA WIN SMILE">BẢO LÃNH BẢO HIỂM GENERALI TẠI NHA KHOA WIN...</a></h3>
                                    <div class="desc"> <a href="/bao-lanh-bao-hiem-generali-tai-nha-khoa-win-smile">Xem thêm</a></div>
                                    <span class="date">Ngày 20/11/2021</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12">
                            <div class="item">
                                <div class="image">
                                    <a href="/tin-tuyen-dung-nhan-vien-kinh-doanh" title="TIN TUYỂN DỤNG: NHÂN VIÊN KINH DOANH"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/bai-viet/Tuyen-Dung-NHaN-VIeN-KINH-DOANH.jpg')); ?>" alt="TIN TUYỂN DỤNG: NHÂN VIÊN KINH DOANH"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/tin-tuyen-dung-nhan-vien-kinh-doanh" title="TIN TUYỂN DỤNG: NHÂN VIÊN KINH DOANH">TIN TUYỂN DỤNG: NHÂN VIÊN KINH DOANH</a></h3>
                                    <div class="desc">• Quyền lợi<br />
                                        - Mức lương: 5.000.000 – 8.000.000đ + Thưởng % trên doanh số<br />
                                        - Được đào tạo, hướng dẫn công việc theo quy trình và tiêu chuẩn của/ ... <a href="/tin-tuyen-dung-nhan-vien-kinh-doanh">Xem thêm</a>
                                    </div>
                                    <span class="date">Ngày 31/12/2020</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12">
                            <div class="item">
                                <div class="image">
                                    <a href="/tin-tuyen-dung-nhan-vien-hanh-chinh-nhan-su" title="TIN TUYỂN DỤNG: NHÂN VIÊN HÀNH CHÍNH NHÂN SỰ"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/bai-viet/TUYEN-DUNG-NHAN-VIEN-HANH-CHINH-NHAN-SU.jpg')); ?>" alt="TIN TUYỂN DỤNG: NHÂN VIÊN HÀNH CHÍNH NHÂN SỰ"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/tin-tuyen-dung-nhan-vien-hanh-chinh-nhan-su" title="TIN TUYỂN DỤNG: NHÂN VIÊN HÀNH CHÍNH NHÂN SỰ">TIN TUYỂN DỤNG: NHÂN VIÊN HÀNH CHÍNH NHÂN SỰ</a></h3>
                                    <div class="desc">- Được làm việc trong một môi trường thẻ, thân thiện, năng động, <br />
                                        - Được hưởng lương và các chế độ tương xứng với năng lực và công việc đảm nhận/ ... <a href="/tin-tuyen-dung-nhan-vien-hanh-chinh-nhan-su">Xem thêm</a>
                                    </div>
                                    <span class="date">Ngày 01/12/2020</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12">
                            <div class="item">
                                <div class="image">
                                    <a href="/khong-the-phot-lo-voi-dia-chi-co-chi-phi-nho-rang-khon-moc-lech-hop-ly" title="Không thể phớt lờ với địa chỉ có chi phí nhổ răng khôn mọc lệch hợp lý"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/chi-phi-nho-rang-khon-moc-lech-1.jpg')); ?>" alt="Không thể phớt lờ với địa chỉ có chi phí nhổ răng khôn mọc lệch hợp lý"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/khong-the-phot-lo-voi-dia-chi-co-chi-phi-nho-rang-khon-moc-lech-hop-ly" title="Không thể phớt lờ với địa chỉ có chi phí nhổ răng khôn mọc lệch hợp lý">Không thể phớt lờ với địa chỉ có chi...</a></h3>
                                    <div class="desc">Chi phí nhổ răng khôn mọc lệch cũng ảnh hưởng một phần đến quyết định điều trị của bệnh nhân. Và để biết mức giá cụ thể ra sao, mọi/ ... <a href="/khong-the-phot-lo-voi-dia-chi-co-chi-phi-nho-rang-khon-moc-lech-hop-ly">Xem thêm</a></div>
                                    <span class="date">Ngày 14/06/2020</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12">
                            <div class="item">
                                <div class="image">
                                    <a href="/chia-se-dan-su-bao-nhieu-tien-va-nhung-dieu-can-biet" title="Chia sẻ dán sứ bao nhiêu tiền và những điều cần biết"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/dan-su-bao-nhieu-tien-1.jpg')); ?>" alt="Chia sẻ dán sứ bao nhiêu tiền và những điều cần biết"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/chia-se-dan-su-bao-nhieu-tien-va-nhung-dieu-can-biet" title="Chia sẻ dán sứ bao nhiêu tiền và những điều cần biết">Chia sẻ dán sứ bao nhiêu tiền và những...</a></h3>
                                    <div class="desc">Chi phí dán răng sứ luôn là mối quan tâm hàng đầu của những người muốn sử dụng phương pháp này để phục hình khuyết điểm răng. Giá cả hợp/ ... <a href="/chia-se-dan-su-bao-nhieu-tien-va-nhung-dieu-can-biet">Xem thêm</a></div>
                                    <span class="date">Ngày 30/05/2020</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12">
                            <div class="item">
                                <div class="image">
                                    <a href="/chi-phi-nho-rang-so-8-cuc-re-ma-hieu-qua-cuc-dat-chi-co-tai-win-smile" title="Chi phí nhổ răng số 8 cực rẻ mà hiệu quả cực “đắt” - Chỉ có tại Win Smile"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/chi-phi-nho-rang-so-8-1.jpg')); ?>" alt="Chi phí nhổ răng số 8 cực rẻ mà hiệu quả cực “đắt” - Chỉ có tại Win Smile"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/chi-phi-nho-rang-so-8-cuc-re-ma-hieu-qua-cuc-dat-chi-co-tai-win-smile" title="Chi phí nhổ răng số 8 cực rẻ mà hiệu quả cực “đắt” - Chỉ có tại Win Smile">Chi phí nhổ răng số 8 cực rẻ mà...</a></h3>
                                    <div class="desc">Chi phí nhổ răng số 8 được mọi người quan tâm nhưng chưa phải yếu tố quyết định đến kết quả của việc có giải quyết được những biến chứng/ ... <a href="/chi-phi-nho-rang-so-8-cuc-re-ma-hieu-qua-cuc-dat-chi-co-tai-win-smile">Xem thêm</a></div>
                                    <span class="date">Ngày 23/05/2020</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="control"><a href="/tin-tuc-su-kien" class="btn_yellow">Xem thêm các tin tức mới</a></div>
            </div>
        </div>
        <div class="box_feedbackCategoryHome">
            <div class="container">
                <div class="box_title">
                    <h2 class="title"><a href="/cam-nhan-khach-hang" title="Khách hàng nói gì về WinSmile?">Khách hàng nói gì về WinSmile?</a></h2>
                    <a href="/cam-nhan-khach-hang" class="view_all">Xem tất cả</a>
                </div>
                <div class="box_desc"></div>
                <div class="box_content">
                    <div class="slide">
                        <div class="item">
                            <div class="item_content">Làm xong cũng chẳng đau gì chỉ thấy đẹp thôi, mình tự tin hát và trước ống kính lắm rồi.</div>
                            <div class="item_info">
                                <div class="image">
                                    <a href="/thuong-cin" title="THƯƠNG CIN"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/thuong-cin-2.png')); ?>" alt="THƯƠNG CIN"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/thuong-cin" title="THƯƠNG CIN">THƯƠNG CIN</a></h3>
                                    <div class="desc">Diễn viên <span></span></div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="item_content">Răng của Huyền trước đây khá đều, tuy nhiên lại không được trắng sáng. Dù không tự ti nhưng là 1 Boss của hệ thống hơn 1000 người thì hình ảnh nụ cười rạng rỡ chính là yếu tố khiến Huyền luôn được yêu mến và tin tưởng.</div>
                            <div class="item_info">
                                <div class="image">
                                    <a href="/hoang-phi-huyen" title="HOÀNG PHI HUYỀN"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/hoang-phi-huyen.png')); ?>" alt="HOÀNG PHI HUYỀN"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/hoang-phi-huyen" title="HOÀNG PHI HUYỀN">HOÀNG PHI HUYỀN</a></h3>
                                    <div class="desc">Boss <span>Huyền Phi Comestic</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="item_content">Hiện tại Nụ cười rạng rỡ mà Win Smile mang lại cho tôi đó chính là niềm tin yêu của học viên và sự quý trọng của đối tác. Cám ơn Win Smile luôn đồng hành cùng tôi trên con đường thành công.</div>
                            <div class="item_info">
                                <div class="image">
                                    <a href="/nguyen-tat-kiem" title="NGUYỄN TẤT KIỂM"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/nguyen-tat-kiem.png')); ?>" alt="NGUYỄN TẤT KIỂM"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/nguyen-tat-kiem" title="NGUYỄN TẤT KIỂM">NGUYỄN TẤT KIỂM</a></h3>
                                    <div class="desc">CEO <span>TAKA ACADEMY</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="item_content">Bây giờ mình luôn tự tin , thoải mái mỗi khi cười và nhận được rất nhiều lời khen từ bạn bè và đối tác.</div>
                            <div class="item_info">
                                <div class="image">
                                    <a href="/nguyen-quyen" title="NGUYỄN QUYÊN"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/nguyen-quyen.png')); ?>" alt="NGUYỄN QUYÊN"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/nguyen-quyen" title="NGUYỄN QUYÊN">NGUYỄN QUYÊN</a></h3>
                                    <div class="desc">Boss <span>Mỹ phẩm Herrin Care</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="item_content">Răng của Giang trước đây gặp rất nhiều vấn đề, răng khấp khểnh, cười hở lợi và không được trắng sáng. </div>
                            <div class="item_info">
                                <div class="image">
                                    <a href="/nguyen-tra-giang" title="NGUYỄN TRÀ GIANG"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/nguyen-tra-giang3.png')); ?>" alt="NGUYỄN TRÀ GIANG"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/nguyen-tra-giang" title="NGUYỄN TRÀ GIANG">NGUYỄN TRÀ GIANG</a></h3>
                                    <div class="desc">Boss <span>Mint beauty</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="item_content"> Ai cũng khen răng mình đẹp, đi làm gặp nhiều anh chị nghệ sĩ đã làm răng rồi mà mọi người vẫn hỏi mình làm răng ở đâu, Mình cảm ơn Win Smile rất nhiều.</div>
                            <div class="item_info">
                                <div class="image">
                                    <a href="/pong-chuan" title="PÔNG CHUẨN"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/pong-chuan.png')); ?>" alt="PÔNG CHUẨN"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/pong-chuan" title="PÔNG CHUẨN">PÔNG CHUẨN</a></h3>
                                    <div class="desc">Style list <span></span></div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="item_content">Một người khó tính và sợ đau như Tùng mà sau khi bọc răng sứ tại Win Smile còn cảm thấy hài lòng thì Tùng nghĩ dịch vụ tại Win Smile rất đáng để trải nghiệm.</div>
                            <div class="item_info">
                                <div class="image">
                                    <a href="/tung-min" title="TÙNG MIN"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/tung-min.png')); ?>" alt="TÙNG MIN"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/tung-min" title="TÙNG MIN">TÙNG MIN</a></h3>
                                    <div class="desc">Diễn viên <span></span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="box_book" id="box_book">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5 hidden-xs">
                        <img class="image" src="<?php echo e(asset('public/template/frontend/img/book.png')); ?>">
                    </div>
                    <div class="col-sm-7 col-xs-12">
                        <div class="box_wrap">
                            <div class="box_title">Đặt lịch khám tại WinSmile</div>
                            <div class="box_content">
                                <form name="frmBook" id="frmBook">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group" id="input-name">
                                                <input type="text" name="name" class="form-control" placeholder="Họ tên khách hàng *">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group" id="input-phone">
                                                <input type="text" name="phone" class="form-control" placeholder="Số điện thoại liên hệ *">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group" id="input-day">
                                                <input type="text" name="day" class="form-control datepicker" placeholder="Ngày đặt lịch *">
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group" id="input-location">
                                                <select name="location" class="form-control">
                                                    <option value="">Chọn cơ sở gần bạn *</option>
                                                    <option value="WinSmile Hà Nội">WinSmile Hà Nội</option>
                                                    <option value="WinSmile Hồ Chí Minh">WinSmile Hồ Chí Minh</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-12">
                                            <div class="note">* Thông tin của bạn sẽ được bảo mật!</div>
                                            <div class="btnSuccess">
                                                <input type="hidden" name="form_id" value="1574996192843n19215gc8">
                                                <div class="control">
                                                    <a href="javascript:;" onclick="javascript:formRegister('frmBook');" class="btn_yellow submit">Đặt lịch</a>
                                                    <span class="open">Giờ làm việc: <br><span>8h00 đến 20h00</span></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="box_tuvan hidden-xs" id="box_tuvan">
            <div class="box_content">
                <div class="col col-1">
                    <img class="image" src="<?php echo e(asset('public/template/frontend/img/icon_17.png')); ?>">
                    <div>Đăng</div>
                    <div>Ký</div>
                    <div>Nhận</div>
                    <div>Tư</div>
                    <div>Vấn</div>
                </div>
                <div class="col col-2">
                    <form name="frmTuvan" id="frmTuvan">
                        <div class="form-group" id="input-name">
                            <input type="text" name="name" class="form-control" placeholder="Họ tên khách hàng *">
                        </div>
                        <div class="form-group" id="input-phone">
                            <input type="text" name="phone" class="form-control" placeholder="Số điện thoại liên hệ *">
                        </div>
                        <div class="form-group" id="input-email">
                            <input type="text" name="email" class="form-control" placeholder="Email liên hệ *">
                        </div>
                        <div class="form-group" id="input-location">
                            <select name="location" class="form-control">
                                <option value="">Chọn cơ sở gần bạn *</option>
                                <option value="WinSmile Hà Nội">WinSmile Hà Nội</option>
                                <option value="WinSmile Hồ Chí Minh">WinSmile Hồ Chí Minh</option>
                            </select>
                        </div>
                        <input type="hidden" name="form_id" value="1575130813q7ja36311m0f">
                    </form>
                </div>
                <div class="col col-3" onclick="javascript:formRegister('frmTuvan');">
                    <div class="btnSuccess">
                        <img class="image" src="<?php echo e(asset('public/template/frontend/img/icon_18.png')); ?>">
                        <div>Gửi</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="box_footer">
            <div class="container">
                <div class="logo">
                    <img src="<?php echo e(asset('public/files/upload/default/images/he-thong/logo.png')); ?>">
                </div>
                <div class="row">
                    <div class="col-sm-5">
                        <div class="box_title">Win Smile Lê Duẩn</div>
                        <div class="box_content">
                            <p>Địa chỉ: 51B L&ecirc; Duẩn, Ho&agrave;n Kiếm, H&agrave; Nội<br />
                                Điện thoại: 0966.688.234
                            </p>
                        </div>
                        <div class="box_title">WinSmile Đường Láng</div>
                        <div class="box_content">
                            <p>Địa chỉ: Số 10/1194 đường L&aacute;ng, Đống Đa, H&agrave; Nội<br />
                                Điện thoại: 0967.688.234
                            </p>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="box_title">Hotline</div>
                        <div class="box_content">
                            <div class="hotline">0966 688 234</div>
                        </div>
                        <div class="box_title">Liên kết</div>
                        <div class="box_content">
                            <div class="box_menuFooter">
                                <ul>
                                    <li data-level="2" data-max="2" data-key=""><a href="/ve-winsmile" target="_self" class=""><span class="title">Về WinSmile</span></a></li>
                                    <li data-level="2" data-max="2" data-key=""><a href="/blog" target="_self" class=""><span class="title">Blog</span></a></li>
                                    <li data-level="2" data-max="2" data-key=""><a href="/cam-nhan-khach-hang" target="_self" class=""><span class="title">Cảm nhận khách hàng</span></a></li>
                                    <li data-level="2" data-max="2" data-key=""><a href="/lien-he" target="_self" class=""><span class="title">Liên hệ</span></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="box_content">
                            <div class="box_page">
                                <div class="fb-page" data-href="https://www.facebook.com/nhakhoaquoctewinsmile" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="box_copyright">
            <div class="container">
                Bản quyền thuộc về Win Smile. All Rights Reserved @2019        
            </div>
        </div>
        <div class="box_cart hidden" id="box_cart">
            <a href="/product/cart/"><i class="fa fa-shopping-cart"></i> <span class="cart_amount">0</span></a>
        </div>
        <div class="box_controls_mobile hidden-sm hidden-md hidden-lg" id="box_controls_mobile">
            <div class="wrap">
                <a href="javascript:;" class="btn_register">Đăng ký ngay</a>
                <a href="tel:0966688234" class="btn_hotline">Gọi tư vấn</a>
            </div>
        </div>
        <div class="box_popup_tuvan" id="box_popup_tuvan">
            <div class="wrap">
                <div class="cover"><img src="<?php echo e(asset('public/files/upload/default/images/he-thong/logo-white.png')); ?>"></div>
                <div class="content">
                    <form name="frmTuvanPopup" id="frmTuvanPopup">
                        <div class="form-group" id="input-name">
                            <input type="text" name="name" class="form-control" placeholder="Họ tên khách hàng *">
                        </div>
                        <div class="form-group" id="input-phone">
                            <input type="text" name="phone" class="form-control" placeholder="Số điện thoại *">
                        </div>
                        <div class="form-group" id="input-email">
                            <input type="text" name="email" class="form-control" placeholder="Email">
                        </div>
                        <div class="form-group" id="input-content">
                            <textarea type="text" name="content" class="form-control" placeholder="Nhu cầu tư vấn"></textarea>
                        </div>
                        <div class="form-group">
                            <button type="button" class="form-control btn_submit" onclick="javascript:formRegister('frmTuvanPopup');">Hoàn thành</button>
                        </div>
                        <div class="form-group">
                            <div class="hotline">Hotline tư vấn: <a href="tel:0966688234">0966 688 234</a></div>
                        </div>
                        <div class="form-group">
                            <div class="text">Đăng ký tư vấn miễn phí!</div>
                        </div>
                        <input type="hidden" name="form_id" value="1575130813q7ja36311m0f">
                    </form>
                </div>
                <span class="close_popup"></span>
            </div>
        </div>
        <script type="text/javascript" src="<?php echo e(asset('public/template/frontend/js/jquery.min.js')); ?>"></script>
        <script type="text/javascript" src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <script type="text/javascript" src="<?php echo e(asset('public/template/frontend/js/bootstrap.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('public/template/frontend/plugins/fancybox/source/jquery.fancybox.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('public/template/frontend/plugins/fancybox/source/jquery.fancybox-thumbs.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('public/template/frontend/plugins/bxslider/jquery.bxslider.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('public/template/frontend/plugins/hover-dropdown.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('public/template/frontend/plugins/numeric.min.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('public/template/frontend/js/app.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('public/template/frontend/js/me.js?v=24112021014725')); ?>"></script>
        <script type="text/javascript">
            $(document).ready(function() {
              App.init();
            });
        </script>
        <script type="text/javascript">
            //<!--
                $('#menu_toggle').click(function() {
                let menu = '';
                $('.box_menuMain2').each(function() {
                    menu += $(this).html();
                });
                let xhtml = '<div class="bg_menu_mobile" onclick="close_menu_mobile()"></div><div class="box_menuMobile">'+ menu +'</div>';
                $('body').append(xhtml);
            });
            
            function close_menu_mobile() {
                $('.bg_menu_mobile').remove();
                $('.box_menuMobile').remove();
            }
            
            $('.box_menuMain2>ul>li').each(function() {
                var level = 1;
                $('ul>li', this).each(function() {
                    if($('ul', this).length > 0) {
                        level = 2;
                    }
                });
                $(this).addClass('level_' + level);
            });
            
            $(document).ready(function() {
                $('#box_menuMain .header .toggle').click(function() {
                    var xhtmlMenu = $('#box_menuMain .menu').html();
                    $('body').append('<div class="box_menuMobile">'+ xhtmlMenu +'</div>');
                    $('body').append('<div class="bg_menu_mobile" onclick="close_menu_mobile()"></div>');
                });
            });
            
            //-->
        </script>
        <script type="text/javascript">
            //<!--
                $(document).ready(function() {
                $("#box_bxslider .bxslider").bxSlider({
                  auto: true,
                    minSlides: 1,
                    maxSlides: 1,
                    mode: "fade",
                    //slideWidth: 360,
                    slideMargin: 0,
                    moveSlides: 1,
                    responsive: false,
                    pause: 5000,
                    speed: 1500
                });
                $("#box_bxslider_mobile .bxslider").bxSlider({
                  auto: true,
                    minSlides: 1,
                    maxSlides: 1,
                    mode: "fade",
                    //slideWidth: 360,
                    slideMargin: 0,
                    moveSlides: 1,
                    responsive: false,
                    pause: 5000,
                    speed: 1500
                });
            });
            
            //-->
        </script>
        <script type="text/javascript">
            //<!--
              $(document).ready(function() {
                var w_document = $(document).width();
                var minSlides = 4;
                var slideWidth = 300;
                if(w_document < 900) {
                    minSlides = 2;
                    slideWidth = 450;
                }
            
            $(".box_serviceCategoryHome").show();
            $(".box_serviceCategoryHome .slide").bxSlider({
            auto: true,
            minSlides: minSlides,
            maxSlides: minSlides,
            slideWidth: slideWidth,
            slideMargin: 48,
            moveSlides: 1,
            responsive: true,
            pause: 8000,
            speed: 1000
            });
            });
            
            //-->
        </script>
        <script type="text/javascript">
            //<!--
              $(document).ready(function() {
                var w_document = $(document).width();
                var minSlides = 3;
                var slideWidth = 400;
                var moveSlides = 3;
                if(w_document < 900) {
                    minSlides = 1;
                    moveSlides = 1;
                    slideWidth = 900;
                }
            $(".box_feedbackCategoryHome").show();
            $(".box_feedbackCategoryHome .slide").bxSlider({
            auto: true,
            minSlides: minSlides,
            maxSlides: minSlides,
            slideWidth: slideWidth,
            slideMargin: 50,
            moveSlides: moveSlides,
            responsive: false,
            pause: 8000,
            speed: 1000
            });
            });
            
            //-->
        </script>
        <script type="text/javascript">
            //<!--
                $(document).ready(function() {
                setTimeout(function(){
                    $('#modal-image').modal();
                    let modal_height = $('#modal-image .modal-dialog').height();
                    let window_height = $(window).height();
                    let top = (window_height - modal_height) / 2;
                    if(top > 0) {
                        $('#modal-image .modal-dialog').css({'margin-top': top + 'px'});
                        $('#modal-image').css({'opacity': 1});
                    }
                }, );
                //$('#modal-image-mobile').modal();
            });
            
            //-->
        </script>    
       
    </body>
</html><?php /**PATH C:\Users\cuong123\Desktop\New folder (2)\blog\resources\views/home.blade.php ENDPATH**/ ?>