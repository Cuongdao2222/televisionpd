<!-- Id Field -->
<div class="col-sm-12">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo e($post->id); ?></p>
</div>

<!-- Image Field -->
<div class="col-sm-12">
    <?php echo Form::label('image', 'Image:'); ?>

    <p><?php echo e($post->image); ?></p>
</div>

<!-- Title Field -->
<div class="col-sm-12">
    <?php echo Form::label('title', 'Title:'); ?>

    <p><?php echo e($post->title); ?></p>
</div>

<!-- Content Field -->
<div class="col-sm-12">
    <?php echo Form::label('content', 'Content:'); ?>

    <p><?php echo e($post->content); ?></p>
</div>

<!-- Created At Field -->
<div class="col-sm-12">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($post->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="col-sm-12">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($post->updated_at); ?></p>
</div>

<?php /**PATH /home/dthdenta/public_html/demo1.dthdental.vn/resources/views/posts/show_fields.blade.php ENDPATH**/ ?>