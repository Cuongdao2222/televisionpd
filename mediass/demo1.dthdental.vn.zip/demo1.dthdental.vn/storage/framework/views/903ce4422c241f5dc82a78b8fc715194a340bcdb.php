<div class="row">
    <?php echo $records->links(); ?>

</div>
<?php /**PATH /home/dthdenta/public_html/demo1.dthdental.vn/resources/views/vendor/adminlte-templates/common/paginate.blade.php ENDPATH**/ ?>