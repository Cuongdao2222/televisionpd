
<!DOCTYPE html>
<html lang="vi-VN">
<head>

    <title>D'media</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="google-site-verification" content="__HHZzKGd89GJK-ap9a4fbHYollh_CgQphaMRZ_Dqo4" />
    

    <meta content="D'media" name="description" />
        <link rel="canonical" href="https://www.sapo.vn/thiet-ke-website-ban-hang.html" />
    
    <link rel="shortcut icon" href="http://media.dthdental.vn/images/favicon.png" type="image/x-icon" />

    <script type="text/javascript">
        function addLoadEvent(e) { if (document.readyState === "complete") { e() } else { var t = window.onload; if (typeof window.onload != "function") { window.onload = e } else { window.onload = function () { if (t) { t() } e() } } } }
    </script>
    <script src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/lib/tom-select/tom-select.complete.js')); ?>" async></script>
    <script src="<?php echo e(asset('website/Themes/Portal/Default/Scripts/dist/defaultV2.min.js?v=637720665631753465')); ?>" async></script>
    <link href="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/dist/ld-sellatwebsite.min.css?v=637711847681377667')); ?>" rel="preload" as="style" type="text/css" />
    <link href="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/dist/ld-sellatwebsite.min.css?v=637711847681377667')); ?>" rel="stylesheet" />
    <script src="./variable-trial.js" async></script>

    <meta property="og:image" content="https://www.sapo.vn/Themes/Portal/Default/StylesV2/images/social-banner/sellatwebsite.jpg?v=2" />
    <meta property="og:image:secure_url" content="https://www.sapo.vn/Themes/Portal/Default/StylesV2/images/social-banner/sellatwebsite.jpg?v=2" />
    <meta property="og:title" content="Thiết kế website b&#225;n h&#224;ng, tạo web chuy&#234;n nghiệp | Sapo Web &#174;" />
    <meta property="og:description" content="Với mọi ng&#224;nh h&#224;ng, Sapo Web gi&#250;p bạn thiết kế web b&#225;n h&#224;ng chuy&#234;n nghiệp, tạo website b&#225;n h&#224;ng chuẩn SEO, hỗ trợ tăng trưởng doanh thu trong m&#249;a dịch..." />
    <meta property="og:type" content="website">
        <meta property="og:url" content="https://www.sapo.vn/thiet-ke-website-ban-hang.html" />
    <meta property="og:site_name" content="Thiết kế website b&#225;n h&#224;ng, tạo web chuy&#234;n nghiệp | Sapo Web &#174;" />
    <meta property="og:image:alt" content="Thiết kế website b&#225;n h&#224;ng, tạo web chuy&#234;n nghiệp | Sapo Web &#174;" />

    <meta name="twitter:card" content="Với mọi ng&#224;nh h&#224;ng, Sapo Web gi&#250;p bạn thiết kế web b&#225;n h&#224;ng chuy&#234;n nghiệp, tạo website b&#225;n h&#224;ng chuẩn SEO, hỗ trợ tăng trưởng doanh thu trong m&#249;a dịch...">
    <meta name="twitter:site" content="Thiết kế website b&#225;n h&#224;ng, tạo web chuy&#234;n nghiệp | Sapo Web &#174;">
    <meta name="twitter:creator" content="Thiết kế website b&#225;n h&#224;ng, tạo web chuy&#234;n nghiệp | Sapo Web &#174;">
    <meta name="twitter:url" content="https://www.sapo.vn/thiet-ke-website-ban-hang.html">
    <meta name="twitter:title" content="Thiết kế website b&#225;n h&#224;ng, tạo web chuy&#234;n nghiệp | Sapo Web &#174;">
    <meta name="twitter:description" content="Với mọi ng&#224;nh h&#224;ng, Sapo Web gi&#250;p bạn thiết kế web b&#225;n h&#224;ng chuy&#234;n nghiệp, tạo website b&#225;n h&#224;ng chuẩn SEO, hỗ trợ tăng trưởng doanh thu trong m&#249;a dịch...">
    <meta name="twitter:image" content="https://www.sapo.vn/Themes/Portal/Default/StylesV2/images/social-banner/sellatwebsite.jpg?v=2">
    <meta name="twitter:image:width" content="500">
    <meta name="twitter:image:height" content="300">

    
    
    <style>
        #chat-widget{
            display:none;
        }
        .ld-sellatwebsite .supported:after {
            background:none !important;
        }    
        .btn-registration{
            background-image: linear-gradient(to right, #284b9c 0%, #eb1f81 100%)!important;
        }
        .bg-register{
            background:#284b9c !important;
        }
    </style>
        
</head>
<body>
    <div id="container">

<div id="header" class="index WEB active-child header">
    <div class="main-header d-flex align-items-center flex-wrap">
        <div class="container">
            <div class="row">
                <div class="col-xl-2 col-8 d-flex align-items-center ">
                        <a id="logo" class="main-logo d-xl-block d-none" href="/">
                            <img src="./images/dmedia-logo.svg" alt="dmedia logo" />
                        </a>
                        <a class="main-logo d-block d-xl-none" href="/thiet-ke-website-ban-hang.html">
                            <img src="./images/dmedia-logo.svg" alt="dmedia logo" />
                        </a>
                </div>
               
            </div>
        </div>
    </div>

    <div class="extra-header d-none d-xl-block">
        <div class="container d-xl-flex align-items-center justify-content-between">
            
            <div class="menu justify-content-between">
                <ul class="d-xl-flex align-items-center">
                 
                    <li class=""><a href="/bang-gia.html">Bảng giá<span class="badge ">SALE</span></a></li>
                    <li><a href="/theme.html" target="_blank">Kho giao diện</a></li>
                   
                    
                </ul>
                <a href="#" class="btn-registration">Dùng thử</a>
            </div>
        </div>
    </div>

</div>
<div class="menu-mobile WEB">
    <div class="logo-mobile">
                <a href="/thiet-ke-website-ban-hang.html">
                    <img src="<?php echo e(asset('website')); ?>./Themes/Portal/Default/StylesV2/images/logo/SapoWeb-logo.svg?v=202111161048" alt="Sapo logo" />
                </a>
        <a aria-label="Intermdiate JavaScript" href="javascript:;" class="btn-close-menu" onclick="closeMenu();">
            <i class="ti-close"></i>
        </a>
    </div>
    <div class="box-scroll">

    <ul class="nav">
        <li class=""><a href="/tinh-nang-noi-bat-website.html">Tính năng</a></li>
        <li class=""><a href="/bang-gia.html">Bảng giá<span class="badge ">SALE</span></a></li>
        <li><a href="/theme.html" target="_blank">Kho giao diện</a></li>
        
       
        <li class="trial">
            <a href="javascript:;" class="btn-registration" onclick="showModalTrial(this, 2, false)"><span>Dùng thử</span></a>
        </li>
    </ul>

        <ul class="nav nav-bottom">
            <li class="show-sub">
                <a data-toggle="collapse" href="javascript:;" data-target="#nav-bottom-child-1">
                        Sản phẩm khác

                </a>
                <div id="nav-bottom-child-1" class="panel-collapse collapse">
                    <ul class="sub-menu">
                            <li>
                                <a href="/phan-mem-quan-ly-ban-hang.html">
                                    <strong>Sapo POS</strong>
                                    <span>Phần mềm quản lý bán hàng</span>
                                </a>
                            </li>
                                                    <li>
                                <a href="/phan-mem-quan-ly-nha-hang.html">
                                    <strong>Sapo FnB</strong>
                                    <span>Phần mềm quản lý nhà hàng</span>
                                </a>
                            </li>
                                                    <li>
                                <a href="/quan-ly-ban-hang-online.html">
                                    <strong>Sapo GO</strong>
                                    <span>Quản lý tăng trưởng bán hàng online</span>
                                </a>
                            </li>
                                                                            <li>
                                <a href="/omnichannel.html">
                                    <strong>Sapo Omnichannel</strong>
                                    <span>Giải pháp quản lý bán hàng đa kênh</span>
                                </a>
                            </li>

                                <li>
                                        <a href="/ung-dung-so-ghi-no-va-ban-hang-online.html">
                                            <strong>Sapo 365 <span class="badge">Free</span></strong>
                                            <span>Ứng dụng sổ ghi nợ và bán hàng <br />online miễn phí </span>
                                        </a>
                                    </li>
                                                    <li>
                                <a href="/phan-mem-crm-va-marketing-automation.html">
                                    <strong>Sapo Hub</strong>
                                    <span>Phần mềm CRM 4.0 và Marketing Automation</span>
                                </a>
                            </li>
                        <li>
                                <a href="/enterprise">
                                    <strong>Sapo Enterprise</strong>
                                    <span>Quản lý và phát triển thương hiệu <br />cho doanh nghiệp lớn</span>
                                </a>
                            </li>
                    </ul>
                </div>
            </li>
            <li class="show-sub">
                <a data-toggle="collapse" href="javascript:;" data-target="#nav-bottom-child-1b">
                    Tiện ích
                </a>
                <div id="nav-bottom-child-1b" class="panel-collapse collapse">
                    <ul class="sub-menu">
                        <li>
                            <a href="/sapo-express.html">
                                <strong>Sapo Express</strong>
                                <span>Giải pháp tối ưu vận chuyển</span>
                            </a>
                        </li>
                        <li>
                            <a href="/sapo-fin.html">
                                <strong>Sapo Fin</strong>
                                <span>Giải pháp tiên phong - Vay vốn tin cậy cho nhà bán hàng</span>
                            </a>
                        </li>
                        <li>
                            <a href="/sapo-market.html">
                                <strong>Sapo Market</strong>
                                <span>
                                    Đầu mối nhập hàng giá tốt cho các tiệm tạp hóa, siêu thị mini
                                </span>
                            </a>
                        </li>
                        <li>
                            <a href="/sapo-pay.html">
                                <strong>Sapo Pay</strong>
                                <span>
                                    Giải pháp thanh toán không tiền mặt đa kênh
                                </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li><a href="/blog" rel="noopener" target="_blank">Blog</a></li>
                <li>
                    <a href="#" target="_blank" rel="noopener">Trợ giúp</a>
                </li>
            <li class="show-sub">
                <a data-toggle="collapse" href="javascript:;" data-target="#nav-bottom-child-2">
                    Thêm
                </a>
                
            </li>
                <li >
                    <a href="/dang-nhap-kenh-ban-hang.html">Đăng nhập</a>
                </li>
                            <li class="home">
                    <a href="/">Sapo.vn</a>
                </li>
        </ul>
    </div>
</div>
<div class="overlay-menu" onclick="closeMenu()"></div>
<script type="text/javascript">
    function openMenu() {
        $('body').css('overflow', 'hidden');
        $('.overlay-menu').fadeIn(300);
        $('.menu-mobile').addClass('show');
    }
    function closeMenu() {
        $('body').css('overflow', '');
        $('.overlay-menu').fadeOut(300);
        $('.menu-mobile').removeClass('show');
    }
    addLoadEvent(function () {
            
                var itemTop = $('.header .main-header').offset().top + $('.header .main-header').height() + $('.header .extra-header').height();
                if ($(window).scrollTop() > itemTop) {
                    $('.header .extra-header').addClass('sticky');
                }
                $(window).on('scroll', function () {
                    if ($(this).scrollTop() > itemTop) {
                        $('.header .extra-header').addClass('sticky');
                    } else {
                        $('.header .extra-header').removeClass('sticky');
                    }
                });
            
    });
</script>

        <div id="wrapper" class="clearfix">
            
    <div class="ld-sellatwebsite">

        <div class="banner">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-12 block-content">
                        <a href="javascript:;" class="scroll-downs" data-href=".connect-google"> <span class="arrow"></span></a>
                        <h1>Thiết kế website chuẩn nha khoa</h1>
                        <p class="font-light">
                            Tăng doanh thu bán hàng online với trang web bán hàng<br class="d-none d-md-block" />
                            được lập chuẩn SEO, bắt mắt
                        </p>
                        <a class="btn-registration"  href="#">Dùng thử miễn phí</a>
                        <!-- <p class="text-graphic d-none d-lg-block">
                            D’media đồng hành và chia sẻ với các phòng khám nha khoa vượt qua dịch bệnh với nhiều ưu đãi hấp dẫn
                        </p>
                        <p><b>+100,000</b> phòng khám đã tin dùng D’media</p> -->
                       
                    </div>
                    <div class="col-lg-6 d-none d-lg-block block-img">
                        <span>
                            <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/function/sellatwebsite/thiet-ke-website-ban-hang.png?v=2')); ?>" alt="Thiết kế website bán hàng" / style="width: 100%;">
                            <!--
                        <a class="btn-video" href="https://www.youtube.com/watch?v=lhpp4XWhjqM&feature=youtu.be" data-fancybox="video">
                            <span class="fa"><img src="<?php echo e(asset('website')); ?>./Themes/Portal/Default/StylesV2/images/function/sellatwebsite/playvideo.png?v=2" alt="playvideo" /></span>
                        </a>
                            -->
                        </span>
                    </div>
                </div>
            </div>
            <a href="javascript:;" data-href=".benefit" class="scroll-down">
                <i class="ti-arrow-down" aria-hidden="true"></i>
            </a>
        </div>



        <div class="benefit text-left ">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-12 block-left">
                        <p>D'media hân hạnh đồng hành cùng nha khoa Việt</p>
                        <h2>
                            Giúp phòng khám nha khoa tăng trưởng bền vững
                        </h2>
                        <img class="img-desktop d-none d-lg-block" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/function/sellatwebsite/loi-ich-cua-thiet-ke-web-ban-hang.png?v=2')); ?>" alt="Lợi ích của thiết kế website bán hàng" />
                    </div>
                    <div class="col-lg-6 col-12 block-right">
                        <div class="row">
                            <div class="col-lg-6 col-12">
                                <img class="d-none d-lg-block" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/function/sellatwebsite/benefit-icon-1.png?v=2')); ?>" alt="Tiếp cận 61% người mua hàng trên website" />
                                <h3>
                                    Quy trình tự động đặt lịch thăm khám
                                </h3>
                                <p>Trang web luôn sẵn sàng trả lời và đáp ứng các nhu cầu của khách hàng đến từ mọi nơi tại mọi thời điểm. Điều này cũng có nghĩa là nhân viên phòng khám không phải dành hàng giờ mỗi ngày để trả lời điện thoại và email.
 </p>
                            </div>
                            
                            <div class="col-lg-6 col-12">
                                <img class="d-none d-lg-block" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/function/sellatwebsite/benefit-icon-3.png?v=2')); ?>" alt="Xây dựng được uy tín và thương hiệu" />
                                <h3>
                                    Đưa khách hàng tiềm năng đến phòng khám
                                </h3>
                                <p>Trong thời đại 4.0 khi mà khách hàng luôn tìm kiếm trên Internet đọc về dịch vụ mà mình sắp sử dụng thì website là phương tiện đắc lực để đưa khách hàng tiềm năng đến sử dụng dịch vụ tại phòng khám  </p>
                            </div>
                            
                            <div class="col-lg-6 col-12">
                                <img class="d-none d-lg-block" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/function/sellatwebsite/benefit-icon-2.png?v=2')); ?>" alt="Tăng hiệu quả hoạt động quảng cáo" />
                                <h3>
                                    Giới thiệu thông tin phòng khám một cách chuyên nghiệp
                                </h3>
                                <p>Giống như việc đi mua hàng tại cửa hàng, khách hàng sẽ muốn biết về sản phẩm trước khi mua. Website cho khách hàng tiềm năng cái nhìn rõ ràng về những dịch vụ mà bạn cung cấp và đem đến hình ảnh chuyên nghiệp hơn cho phòng khám nha khoa. </p>
                            </div>
                           
                            <div class="col-lg-6 col-12">
                                <img class="d-none d-lg-block" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/function/sellatwebsite/benefit-icon-4.png?v=2')); ?>" alt=" Hỗ trợ Chăm sóc khách hàng 24/7" />
                                <h3>
                                    Hỗ trợ Chăm sóc khách hàng <br class="d-none d-lg-block" />24/7
                                </h3>
                                <p>Website là công cụ đắc lực giúp phòng khám có thêm khách hàng mới thông qua việc tự động hoá các công đoạn lưu trữ thông tin khách hàng đăng ký, tương tác, phản hồi và đánh giá khách hàng tới thăm khám thông qua các thông tin hiển thị.</p>
                            </div>
                        </div>
                        <div class="d-block d-lg-none">
                            <span class="more-button more">Xem chi tiết <i class="fa fa-angle-down"></i></span>
                        </div>
                        <div class="block-img">
                            <img class="img-desktop d-block d-lg-none" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/function/sellatwebsite/loi-ich-cua-thiet-ke-web-ban-hang.png?v=2')); ?>" alt="Lợi ích của thiết kế website bán hàng" />
                        </div>
                    </div>
                </div>
            </div>

        </div>
        
        


       <div class="supported">
            <div class="container">
                <h2>D’media đưa bệnh nhân đến phòng khám nhanh nhất</h2>
                <p>
                   Kết nối địa chỉ phòng khám với Google map và Googel My Business trong thời gian nhanh nhất
                </p>
                <div class="row">
                    <div class="col-lg-6 col-12">
                        <div class="item-line active">
                            <h4 data-id=".data-1">Nâng cao uy tín cho phòng khám <i class="icon"></i></h4>
                            <p> D’media cung cấp dịch vụ kết nối miễn phí website phòng khám với các công cụ quản lý doanh nghiệp của Google, bao gồm: Google Tìm Kiếm và Google Maps. Các ứng dụng này giúp phòng khám tiếp cận khách hàng một cách nhanh chóng, đồng thời nâng cao uy tín và xây dựng niềm tin với khách hàng. </p>
                        </div>
                       
                        <div class="item-line">
                            <h4 data-id=".data-2">Miễn phí, không tốn thời gian chờ đợi đăng ký <i class="icon"></i></h4>
                            <p>
                                Phòng khám sẽ không phải lo về chi phí thuê thêm dịch vụ tạo Google Doanh Nghiệp, vì đội ngũ D’media sẽ thay bạn hoàn thành tất cả những thủ tục bao gồm tạo hồ sơ phòng khám và xác minh doanh nghiệp trong thời gian sớm nhất và toàn toàn miễn phí.
                            </p>
                        </div>
                        <div class="item-line">
                            <h4 data-id=".data-3">Website kết nối Google Doanh Nghiệp tiện lợi <i class="icon"></i></h4>
                            <p>
                                Các website của D’media được tích hợp sẵn với Google Doanh Nghiệp giúp các phòng khám có thể khắc phục hiệu quả và nhanh chóng các vấn đề khi làm thủ tục xác minh doanh nghiệp với Google.
                            </p>
                        </div>
                        <a class="btn-registration" href="#">Tạo landing page miễn phí</a>
                    </div>
                    <div class="col-lg-6 col-12 block-image d-none d-lg-block">
                        <img class="active data-1 fade show" src="Themes/Portal/Default/StylesV2/images/function/sellatwebsite/thiet-ke-website-chuyen-nghiep-1.png?v=2" alt="lập website bán hàng" style="width:100%">
                        <img class="data-2 two" src="Themes/Portal/Default/StylesV2/images/function/sellatwebsite/thiet-ke-website-ban-hang-chuyen-nghiep.png?v=2" alt="Tích hợp báo cáo Analytics trên quản trị website" style="width:100%">
                        <img class="data-3" src="Themes/Portal/Default/StylesV2/images/function/sellatwebsite/thiet-ke-website-chuyen-nghiep-2.png?v=2" alt="Bảo mật tuyệt đối website với chứng chỉ SSL" style="width:100%">
                        <img class="data-4" src="Themes/Portal/Default/StylesV2/images/function/sellatwebsite/thiet-ke-website-chuyen-nghiep-3.png?v=2" alt="Kết nối với các đơn vị giao hàng, thanh toán trực tuyến" style="width:100%">
                    </div>
                </div>
                <a href="javascript:;" data-href=".seo-ads" class="scroll-down">
                    <i class="ti-arrow-down" aria-hidden="true"></i>
                </a>
            </div>
        </div>
        
        
        
        <div class="seo-ads text-center">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-12 block-img">
                        <p>Làm sao để phòng khám có thêm nhiều khách hàng mới?</p>
                        <h2>Tối ưu tỉ lệ khách hàng tiếp cận dịch vụ</h2>
                        <img class="d-none d-lg-block" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/function/sellatwebsite/thiet-ke-website-chuyen-nghiep-chuan-seo.png')); ?>" alt="Thiết kế website chuẩn SEO" style="width:100%" />
                    </div>
                    <div class="col-lg-6 col-12 block-content">
                        <div class="line-item">
                            <h4>Đội ngũ chuyên gia SEO</h4>
                            <p>Đứng top danh sách các công cụ tìm kiếm đồng nghĩa với việc phòng khám tiếp cận được với nhiều khách hàng tiềm năng hơn.

Các chuyên gia SEO của D’media sẽ giúp website của bạn: 
Xuất hiện trên top đầu kết quả tìm kiếm Google với các từ khoá liên quan.
Tăng lượt truy cập website.
Phát triển thương hiệu bền vững theo thời gian
Tăng lượt khách hàng đặt lịch trên website
Cập nhật nội dung theo chính sách từ khoá của Google</p>
                        <div class="line-item" style="padding:0">
                            <h4>Quảng cáo hiệu quả hơn</h4>
                            <p>Website phòng khám sẽ giúp tăng hiệu quả của các chương trình quảng cáo và tiếp cận đến các khách hàng tiềm năng ngay lập tức.

Khi phòng khám thực hiện các chiến dịch quảng cáo như Google Adwords, Facebook Ads, website đóng vai trò là một trang đích để khách hàng tiềm năng có thể nhìn thấy dịch vụ phòng khám ngay lập tức. Điều này giúp hỗ trợ tăng hiệu quả của các chương trình quảng cáo đạt hiệu quả cao nhất.</p>
                       
                    </div>
                    <div class="d-block d-lg-none">
                        <span class="more-view more">Xem chi tiết <i class="fa fa-angle-down"></i></span>
                    </div>
                    <div class="block-img">
                        <img class="d-block d-lg-none" src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/function/sellatwebsite/thiet-ke-website-chuyen-nghiep-chuan-seo.png?v=3')); ?>" alt="Thiết kế website chuẩn SEO" />
                    </div>
                </div>
            </div>
        </div>
            </div>
        </div>
        <div class="connect-google">
            <div class="container">
                <h2>D’media đưa bệnh nhân đến phòng khám nhanh nhất</h2>
                <p>Kết nối địa chỉ phòng khám với Google map và Googel My Business trong thời gian nhanh nhất</p>
                <div class="row">
                    <div class="col-lg-6 col-12 order-lg-1 order-2 block-content">
                        <div class="line-item">
                            <h4>Nâng cao uy tín cho phòng khám</h4>
                            <p>D’media cung cấp dịch vụ kết nối miễn phí website phòng khám với các công cụ quản lý doanh nghiệp của Google, bao gồm: Google Tìm Kiếm và Google Maps. Các ứng dụng này giúp phòng khám tiếp cận khách hàng một cách nhanh chóng, đồng thời nâng cao uy tín và xây dựng niềm tin với khách hàng. </p>
                        </div>
                        <div class="line-item">
                            <h4>Miễn phí, không tốn thời gian chờ đợi đăng ký</h4>
                            <p>Phòng khám sẽ không phải lo về chi phí thuê thêm dịch vụ tạo Google Doanh Nghiệp, vì đội ngũ D’media sẽ thay bạn hoàn thành tất cả những thủ tục bao gồm tạo hồ sơ phòng khám và xác minh doanh nghiệp trong thời gian sớm nhất và toàn toàn miễn phí.</p>
                        </div>
                        <div class="line-item">
                            <h4>Website kết nối Google Doanh Nghiệp tiện lợi</h4>
                            <p> Các website của D’media được tích hợp sẵn với Google Doanh Nghiệp giúp các phòng khám có thể khắc phục hiệu quả và nhanh chóng các vấn đề khi làm thủ tục xác minh doanh nghiệp với Google.</p>
                        </div>
                        <!--<div class="wrap">Sapo trở thành đối tác chính thức của Google My Business tại Việt Nam</div>-->
                        <div class="d-block d-lg-none">
                            <span class="more-viewsx more">Xem chi tiết <i class="fa fa-angle-down"></i></span>
                        </div>
                    </div>
                    <div class="col-lg-6 col-12 block-img order-lg-2 order-1">
                        <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/function/sellatwebsite/sapo-web-ket-noi-google-my-business-2.png')); ?>" alt="Tạo google maps doanh nghiệp miễn phí" style="width:100%" />
                    </div>
                </div>
                <a class="btn-registration"  href="#">Tạo landing page miễn phí</a>
                <a href="javascript:;" data-href=".title-tech" class="scroll-down d-lg-block">
                    <i class="ti-arrow-down" aria-hidden="true"></i>
                </a>
            </div>
        </div>
        <div class="technology text-center">
            <div class="container">
                <p>Giải pháp toàn diện cho phòng khám hiện đại</p>
                <h2 class="title-tech">
                    Website - Phòng khám nha khoa trực tuyến 24/7
                </h2>
                <div class="row">
                    <div class="col-lg-7 col-12 block-content order-lg-2 order-1">
                        <div class="line-item">
                            <h4>Chat trực tuyến với khách hàng</h4>
                            <p>Website của D’media có tích hợp các phần mềm livechat và chatbot giúp nhân viên chăm sóc của khách hàng của phòng khám có thể chat trực tiếp với khách hàng hoặc cài đặt tin nhắn trả lời tự động để đáp ứng kịp thời mọi nhu cầu của khách hàng đồng thời tăng tỉ lệ chuyển đổi khách hàng đến sử dụng dịch vụ của phòng khám.</p>
                        </div>
                        <div class="line-item">
                            <h4>Tự động đặt lịch thăm khám</h4>
                            <p> Khách hàng có thể có nhu cầu đặt lịch thăm khám bất cứ lúc nào kể cả ngoài giờ làm việc của phòng khám. Một trang web hoạt động 24/24 với quy trình đặt lịch  hoàn toàn tự động sẽ thay cho nhân viên phòng khám xử lý vô số công việc thủ công, khách hàng cũng không cần tốn nhiều thời gian chờ đợi.</p>
                        </div>
                        <div class="line-item">
                            <h4>Tăng tỉ lệ khách hàng mới</h4>
                            <p>Mọi chi tiết của website đều được chăm chút để tối ưu cho việc tối ưu tỉ lệ khách hàng đặt lịch trực tuyến. Website tự động thu thập thông tin của khách hàng để nhân viên phòng khám tiếp tục thực hiện các hành động thúc đẩy quá trình đặt lịch như gửi các chương trình khuyến mãi hay nhắc nhớ khách hàng.</p>
                        </div>
                        <div class="d-block d-lg-none">
                            <span class="more-views more">Xem chi tiết <i class="fa fa-angle-down"></i></span>
                        </div>
                    </div>
                    <div class="col-lg-5 col-12 block-img order-lg-1 order-2">
                        <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/function/sellatwebsite/tao-website-ban-hang-chuyen-nghiep.png')); ?>" alt="Tạo website bán hàng chuyên nghiệp" />
                    </div>
                </div>
                <a href="javascript:;" data-href=".tutorial" class="scroll-down d-lg-block d-none">
                    <i class="ti-arrow-down" aria-hidden="true"></i>
                </a>

            </div>
        </div>

        <div class="tutorial">
            <div class="container">
                <h2>Quy trình tạo website chuẩn nha khoa</h2>
                <p>Tạo website chuyên nghiệp cho phòng khám chỉ trong 7 bước</p>
                <div class="slide-swip slide-create-web">
                    <div class="swiper-container">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="item">
                                    <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/function/sellatwebsite/create-web-1.png?v=2')); ?>" alt="Đăng ký dùng thử" />
                                    <h3>1.Chiến lược</h3>
                                    <p>Đội ngũ D Media sẽ họp ngồi họp với khách hàng để chỉ ra  định hướng website mà phòng khám đang muốn hướng đến.</p>
                                </div>    
                            </div>
                            <div class="swiper-slide">
                                <div class="item">
                                    <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/function/sellatwebsite/create-web-2.png?v=2')); ?>" alt="Lựa chọn giao diện" />
                                    <h3>2. Cấu trúc</h3>
                                    <p>Định hình cấu trúc điều hướng của trang web và xác định những trang quan trọng để  di chuyển tới trang đặt lịch khám.</p>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="item">
                                    <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/function/sellatwebsite/create-web-3.png?v=2')); ?>" alt="Đăng sản phẩm" />
                                    <h3>3. Khung website</h3>
                                    <p>Thảo cấu trúc của website đã thống nhất giữa 2 bên với nhiều mẫu thiết kế khác nhau trên cả giao diện máy tính và di động.</p>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="item">
                                    <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/function/sellatwebsite/create-web-4.png?v=2')); ?>" alt="Đăng ký tên miền" />
                                    <h3>4. Bản mô phỏng</h3>
                                    <p>  Sau khi khung website được phê duyệt, đội ngũ thiết kế của D'media sẽ sử dụng photoshop để thiết kế trở nên sinh động hơn.</p>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="item">
                                    <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/images/function/sellatwebsite/create-web-5.png?v=2')); ?>" alt="Sẵn sàng bán hàng" />
                                    <h3>5. Phát triển</h3>
                                    <p> Xây dựng trang web thật. Bao gồm cả việc di chuyển nội dung từ trang web cũ và/hoặc viết nội dung mới hoàn toàn.</p>
                                </div>    
                            </div>
                        </div>
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
                <a class="btn-registration"  href="#">Tạo landing page miễn phí</a>
            </div>
        </div>

        <div class="faq">
            <div class="container">
                <h2>
                    Các câu hỏi thường gặp về xây dựng website nha khoa
                </h2>
                <div class="block-faq">
                    <div class="in-faq">
                        <div class="item-line active">
                            <h4>1.Website nha khoa là gì? <i class="icon"></i></h4>
                            <p>
                                Website nha khoa là trang web được thiết kế với giao diện, tính năng dành riêng cho các phòng khám nha khoa. Một website có thiết kế dẹp, chuyên nghiệp chính là nền tảng để đem đến hình ảnh thương hiệu uy  tín trong mắt khách hàng và là một phương thức xây dựng chiến lược phát triển phòng khám một cách bền vững. 
                            </p>
                        </div>
                        <div class="item-line">
                            <h4>2. Thiết kế web nha khoa chuẩn SEO là gì? <i class="icon"></i></h4>
                            <p>
Một trang web nha khoa được coi là chuẩn SEO khi website đó có tính năng và nội dung được thiết kế để thuận tiện cho quá trình thu thập dữ liệu của Google hay các công cụ tìm kiếm khác. Cụ thể, nếu một người sử dụng Google tìm kiếm về một dịch vụ nha khoa có liên quan đến lĩnh vực mà phòng khám cung cấp hay tên miền website phòng khám. Thì công cụ tìm kiếm sẽ hiển thị kết quả có chứa từ khóa tìm kiếm tương đương và website phòng khám của bạn sẽ đứng đầu trong danh sách tìm kiếm. Có một website nha khoa chuẩn SEO đồng nghĩa với việc phòng khám của bạn sẽ tiếp cận được nhiều khách hàng tiềm năng hơn.                            </p>
                        </div>
                        <div class="item-line">
                            <h4>3. Không giỏi biết lập trình có thể tạo website không? <i class="icon"></i></h4>
                            <p>
                                Câu trả lời chắc chắn là có! D’media cung cấp các landing page có sẵn và có thể đưa vào sử dụng chỉ trong 1 cú click mà không cần phải là chuyên gia về công nghệ. Bên cạnh đó, nếu phòng khám có nhu cầu xây dựng một website với nhiều tính năng và hiển thị đầy đủ thông tin, hãy liên hệ với D’media để các chuyên gia của chúng tôi thay bạn tạo nên một trang web chuyên nghiệp cho phòng khám.
                            </p>
                        </div>
                        <div class="item-line">
                            <h4>4. Giá để xây dựng một website là bao nhiêu? <i class="icon"></i></h4>
                            <p>
                                Chi phí thiết kế website phụ thuộc vào nhu cầu và quy mô của phòng khám. Tại D’media, chúng tôi cung cấp đa dạng các gói dịch vụ cho khách hàng lựa chọn: Miễn phí, 10TR, 15TR, 20TR, 25TR và gói V.IP. Vui lòng tham khảo bảng giá hoặc gọi điên đến hotline  0886 360 808 để được tư vấn thêm về gói dịch vụ phù hợp cới phòng khám của mình.
                            </p>
                        </div>
                        <div class="item-line">
                            <h4>5. Thời gian để thiết kế trang web bán hàng là bao lâu? <i class="icon"></i></h4>
                            <p>
                                Thời gian hoàn thiện website phụ thuộc vào gói dịch vụ mà phòng khám lựa chọn. Để giúp quá trình thiết kế website được diễn ra suôn sẻ, quý khách hàng vui lòng chuẩn bị một số thông tin dưới đây:
- Logo phòng khám.
- Hình ảnh về phòng khám, dịch vụ
- Các thông tin về phòng khám, đội ngũ, khách hàng, ... mà bạn muốn đưa lên trang web.
                            </p>
                            <p style="margin: -25px 0 0;">>>Xem chi tiết <a href="/bang-gia.html" target="_blank">bảng giá thiết kế website</a> tại D'media</p>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>

        <div class="optimize text-center">
            <div class="container">
                <a href="javascript:;" data-href=".otp-link" class="scroll-down">
                    <i class="ti-arrow-down" aria-hidden="true"></i>
                </a>
                <p class="otp-link">Phòng khám của bạn phục vụ dịch vụ nào?</p>
                <h2>Chọn giải pháp cho phòng khám</h2>
                <div class="list_category">
                    <div class="row">
                        <div class="col-lg-2">
                            <a href="/thiet-ke-web-my-pham.html" rel="nofollow">
                                <i class="icon cosmetic"></i>
                                <span>Tổng quát</span>
                            </a>
                        </div>
                        <div class="col-lg-2">
                            <a href="/thiet-ke-web-thoi-trang.html" rel="dofollow">
                                <i class="icon fashion"></i>
                                <span>Chỉnh nha</span>
                            </a>
                        </div>
                        <div class="col-lg-2">
                            <a href="kinh-doanh-giay-dep-online.html" rel="dofollow" target="_blank">
                                <i class="icon giaydep"></i>
                                <span>Phẫu thuật</span>
                            </a>
                        </div>
                        <div class="col-lg-2">
                            <a href="/thiet-ke-web-bat-dong-san.html" rel="dofollow" target="_blank">
                                <i class="icon batdongsan"></i>
                                <span>Khám định kỳ</span>
                            </a>
                        </div>
                        <div class="col-lg-2">
                            <a href="/thiet-ke-web-khach-san.html" rel="nofollow">
                                <i class="icon khachsan"></i>
                                <span>Răng hàm mặt</span>
                            </a>
                        </div>
                        <div class="col-lg-2">
                            <a href="/thiet-ke-website-chuan-seo.html" rel="dofollow">
                                <i class="icon web-chuanseo"></i>
                                <span>Nhi khoa</span>
                            </a>
                        </div>
                        <div class="col-lg-2">
                            <a href="/thiet-ke-web-doanh-nghiep.html" target="_blank" rel="dofollow">
                                <i class="icon web-uytin"></i>
                                <span>Nội nha</span>
                            </a>
                        </div>
                      
                    </div>
                    <div class="d-block d-md-none text-center">
                        <span class="more-view-web more">Xem thêm <i class="fa fa-angle-down"></i></span>
                    </div>
                </div>


            </div>
        </div>

        <div class="top-refer-website sellatweb text-center">
            <div class="container">
                <h2>Các mẫu website của D’media</h2>
                <div class="slide-referwebsite">
                    <div class="swiper-container">
                        <div class="swiper-wrapper">

                            <div class="swiper-slide">
                                <div class="item">
                                    <div class="website-item">
                                        <div class="item-infomation">
                                            <div class="item-thumbnail">
                                                <a href="#" target="_blank" rel="nofollow" title="Nula Cosmetic">
                                                    <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/themestores/c6c2febac443eaa50b8b632436bcd258.jpg?1587356421940')); ?>" alt="Nula Cosmetic" class="item-img" />
                                                </a>
                                            </div>
                                        </div>
                                        <div class="website-name">
                                            <a href="#" target="_blank" rel="nofollow" title="Nula Cosmetic">Nula Cosmetic</a>
                                            <p class="price">1.300.000 VNĐ</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="item">
                                    <div class="website-item">
                                        <div class="item-infomation">
                                            <div class="item-thumbnail">
                                                <a href="#" target="_blank" rel="nofollow" title="Junior">
                                                    <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/themestores/f8a5b7070fa394407bf3a1accf0ba518.png?1587365010633')); ?>" alt="Junior" class="item-img" />
                                                </a>
                                            </div>
                                        </div>
                                        <div class="website-name">
                                            <a href="#" target="_blank" rel="nofollow" title="Junior">
                                                Junior
                                            </a>
                                            <p class="price">1.300.000 VNĐ</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="item">
                                    <div class="website-item">
                                        <div class="item-infomation">
                                            <div class="item-thumbnail">
                                                <a href="#" target="_blank" rel="nofollow" title="Garden 1989">
                                                    <img src="<?php echo e(asset('website/Themes/Portal/Default/StylesV2/themestores/4d1229d01cf73796450fc46d637b2c5d.jpg?1587356416537')); ?>" alt="Garden 1989" class="item-img" />
                                                </a>
                                            </div>
                                        </div>
                                        <div class="website-name">
                                            <a href="#" target="_blank" rel="nofollow" title="Garden 1989">
                                                Garden 1989
                                            </a>
                                            <p class="price"> 1.300.000 VNĐ</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <a class="btn-registration" href="#" target="_blank">Xem thêm giao diện</a>
            </div>
        </div>

        <div class="quick-registration register-bottom">
            <div class="container">
                <div class="bg-register">
                    <h2>Bắt đầu xây dựng website phòng khám</h2>
                    <label for="site_name_bottom">Hãy để chúng tôi đồng hành cùng phòng khám của bạn</label>
                    <div class="reg-form">
                        <input id="site_name_bottom" class="input-site-name d-none d-md-inline-block" type="text" value="" placeholder="Nhập tên cửa hàng/doanh nghiệp của bạn" onkeypress="return onInputStoreName(event, this)">
                        <a class="btn-registration banner-home-registration event-Sapo-Free-Trial-form-open"  href="#">Dùng thử miễn phí</a>
                    </div>
                </div>
            </div>
        </div>

    </div>


<script type="text/javascript">
    var flagTop = false;
    var flagBot = false;


    addLoadEvent(function () {

        var ulExperience = $('.experience ul');
        if ($(window).width() < 767) {
            ulExperience.find('li:nth-child(n+4):not(.view-more)').addClass('hidden-item');
        }
        $('.more-button').on('click', function () {
            var $this = $(this),
                contentp = $('.benefit .block-right p');

            if ($(this).hasClass('more')) {
                $this.html('Thu gọn <i class="fa fa-angle-up"></i>');
                contentp.addClass('active');
                $(this).removeClass('more').addClass('hie');
                $('html, body').animate({
                    scrollTop: $('.benefit .block-right').offset().top - 30
                }, 500);
            } else {
                $this.html('Xem chi tiết <i class="fa fa-angle-down"></i>');
                contentp.removeClass('active');
                $(this).removeClass('hie').addClass('more');
                $('html, body').animate({
                    scrollTop: $('.benefit .block-right').offset().top - 30
                }, 500);
            }

        });

        $('.more-view').on('click', function () {
            var $this = $(this),
                contentp = $('.seo-ads .block-content p');

            if ($(this).hasClass('more')) {
                $this.html('Thu gọn <i class="fa fa-angle-up"></i>');
                contentp.addClass('active');
                $(this).removeClass('more').addClass('hie');
                $('html, body').animate({
                    scrollTop: $('.seo-ads .block-content').offset().top - 30
                }, 500);
            } else {
                $this.html('Xem chi tiết <i class="fa fa-angle-down"></i>');
                contentp.removeClass('active');
                $(this).removeClass('hie').addClass('more');
                $('html, body').animate({
                    scrollTop: $('.seo-ads .block-content').offset().top - 30
                }, 500);
            }

        });

        $('.more-views').on('click', function () {
            var $this = $(this),
                contentp = $('.technology .block-content p');

            if ($(this).hasClass('more')) {
                $this.html('Thu gọn <i class="fa fa-angle-up"></i>');
                contentp.addClass('active');
                $(this).removeClass('more').addClass('hie');
                $('html, body').animate({
                    scrollTop: $('.technology .block-content').offset().top - 30
                }, 500);
            } else {
                $this.html('Xem chi tiết <i class="fa fa-angle-down"></i>');
                contentp.removeClass('active');
                $(this).removeClass('hie').addClass('more');
                $('html, body').animate({
                    scrollTop: $('.technology .block-content').offset().top - 30
                }, 500);
            }

        });

        $('.more-viewsx').on('click', function () {
            var $this = $(this),
                contentp = $('.connect-google .block-content p');

            if ($(this).hasClass('more')) {
                $this.html('Thu gọn <i class="fa fa-angle-up"></i>');
                contentp.addClass('active');
                $(this).removeClass('more').addClass('hie');
                $('html, body').animate({
                    scrollTop: $('.connect-google .block-content').offset().top - 30
                }, 500);
            } else {
                $this.html('Xem chi tiết <i class="fa fa-angle-down"></i>');
                contentp.removeClass('active');
                $(this).removeClass('hie').addClass('more');
                $('html, body').animate({
                    scrollTop: $('.connect-google .block-content').offset().top - 30
                }, 500);
            }

        });

        $('.more-view-web').on('click', function () {
            var $this = $(this),
                contentp = $('.optimize .list_category');

            if ($(this).hasClass('more')) {
                $this.html('Thu gọn <i class="fa fa-angle-up"></i>');
                contentp.addClass('active');
                $(this).removeClass('more').addClass('hie');
            } else {
                $this.html('Xem thêm <i class="fa fa-angle-down"></i>');
                contentp.removeClass('active');
                $(this).removeClass('hie').addClass('more');
            }

        });

        $("[data-scroll]").on('click', function () {
            var dataScroll = $(this).data('scroll');
            $('html, body').animate({
                scrollTop: $(dataScroll).offset().top - 90
            }, 500);
        });

        $('.supported .item-line h4').on('click', function () {
            var $this = $(this),
                item = $this.parent('.item-line'),
                data = $(this).attr('data-id');
            if (item.hasClass('active')) {

            } else {
                $('.supported .item-line').removeClass('active');
                $('.supported .block-image img').removeClass('active');
                $('.block-image').find(data).addClass('active');
                $this.parent('.item-line').addClass('active');
            }
        });

        $('.faq .item-line h4').on('click', function () {
            var $thisx = $(this),
                itemx = $thisx.parent('.item-line');
            if (itemx.hasClass('active')) {

            } else {
                $('.faq .item-line').removeClass('active');
                $('.faq .item-line p').slideUp(300);
                itemx.find('p').slideDown(300);
                $thisx.parent('.item-line').addClass('active');
            }
        });

        var referSwiper = new Swiper('.top-refer-website .swiper-container', {
            slidesPerView: 3,
            pagination: {
                clickable: true,
            },
            spaceBetween: 55,
            autoplay: '5000',
            loop: false,
            touchRatio: 0,
            breakpoints: {
                767: {
                    slidesPerView: 1,
                    spaceBetween: 40,
                    touchRatio: 1,
                },
                991: {
                    slidesPerView: 2,
                    touchRatio: 1,
                },
                1199: {
                    slidesPerView: 2,
                    spaceBetween: 60,
                    touchRatio: 1,
                }
            }
        });

        var functionSwiper;
        functionSwiper = new Swiper('.slide-create-web .swiper-container', {
            speed: 500,
            loop: false,
            slidesPerView: 5,
            slidesPerColumn: 1,
            spaceBetween: 30,
            grabCursor: false,
            touchRatio: 0,
            pagination: {
                el: '.slide-create-web .swiper-pagination',
                clickable: true,
            },
            breakpoints: {
                1199: {
                    slidesPerView: 4,
                    spaceBetween: 30,
                    touchRatio: 1,
                    loop: true,
                },
                991: {
                    slidesPerView: 3,
                    spaceBetween: 30,
                    slidesPerColumn: 1,
                    touchRatio: 1,
                    loop: true,
                },
                767: {
                    slidesPerView: 1,
                    spaceBetween: 35,
                    slidesPerColumn: 1,
                    touchRatio: 1,
                    loop: true,
                }
            }
        });


        $('.block-mobile .block-info .title').on('click', function () {
            var $this = $(this),
                item = $this.parent('.block-info').find('.content');
            if (item.is(':visible')) {
                item.slideUp(300);
                $this.find(".fa-plus").removeClass('hidden');
                $this.find(".fa-minus").addClass('hidden');
            } else {
                $('.block-mobile .block-info .title .fa-plus').removeClass('hidden');
                $('.block-mobile .block-info .title .fa-minus').addClass('hidden');
                $('.block-mobile .block-info .content').slideUp(300);
                item.slideDown(300);
                $this.find(".fa-plus").addClass('hidden');
                $this.find(".fa-minus").removeClass('hidden');
            }
        });

        $('.scroll-down, .scroll-downs').on('click', function () {
            var dataHref = $(this).data('href'),
                extraHeader = 0;
            if ($(window).width() >= 1200) {
                extraHeader = 64
            }
            $('html, body').animate({
                scrollTop: $(dataHref).offset().top - extraHeader
            }, 500);
        });
        var benefitSwiper = new Swiper('.benefit .swiper-container', {
            slidesPerView: 2,
            spaceBetween: 30,
            pagination: {
                el: ".benefit .swiper-pagination",
                clickable: true,
            },
            navigation: {
                nextEl: '.benefit .swiper-button-next',
                prevEl: '.benefit .swiper-button-prev',
            },
            loop: true,
            autoplay: '20000',
            preventClicks: false,
            preventClicksPropagation: false,
            simulateTouch: false,
            breakpoints: {
                991: {
                    slidesPerView: 1
                }
            }
        });
        var functionSwiper = new Swiper('.function .swiper-container', {
            slidesPerView: 1,
            pagination: {
                el: ".function .swiper-pagination",
                clickable: true,
            },
            navigation: {
                nextEl: '.function .swiper-button-next',
                prevEl: '.function .swiper-button-prev',
            },
            loop: true,
            autoplay: '20000',
            preventClicks: false,
            preventClicksPropagation: false,
            simulateTouch: false
        });
        if ($(window).width() < 1200) {
            functionSwiper.destroy(true, true);
        }
        $(window).on('resize', function () {
            if ($(window).width() < 1200) {
                functionSwiper.destroy(true, true);
            } else {
                functionSwiper = new Swiper('.function .swiper-container', {
                    slidesPerView: 1,
                    pagination: {
                        el: ".function .swiper-pagination",
                        clickable: true,
                    },
                    navigation: {
                        nextEl: '.function .swiper-button-next',
                        prevEl: '.function .swiper-button-prev',
                    },
                    loop: true,
                    autoplay: '20000',
                    preventClicks: false,
                    preventClicksPropagation: false,
                    simulateTouch: false
                });
            }
        });
        if ($(window).width() < 768) {
            var blockSwiper5 = new Swiper('.technology .swiper-container', {
                pagination: {
                    el: ".technology .swiper-pagination",
                    clickable: true,
                },
                slidesPerView: 1,
                autoplay: '5000'
            });
        }
        $('.function h3').on('click', function () {
            var $this = $(this),
                content = $(this).parent('div').find('p');
            if (content.is(":visible")) {
                content.slideUp();
                $this.find('i').removeClass('fa-minus').addClass('fa-plus');
            } else {
                $('.function .block-content p').slideUp();
                $('.function h3 i').removeClass('fa-minus').addClass('fa-plus');
                content.slideDown();
                $this.find('i').removeClass('fa-plus').addClass('fa-minus');
            }
        });
    });

</script>

<script>
    // addLoadEvent(function () {
    //     $("#header .btn-registration").attr("onclick", "showModalTrial(this, 2, false);");
    //     $(".menu-mobile .btn-registration").attr("onclick", "showModalTrial(this, 2, false);");
    //     $(".register-bottom .btn-registration").attr("onclick", "showModalTrial(this, 2, false);");
    // });
</script>
        </div>
        
        
      
<div id="footer" class="footer">
    <div class="footer-menu">
        <div class="container">
            <div class="row">
                <div class="col-lg col-md-4 col-6">
                    <div class="title">D'media</div>
                    <ul>
                        <li>
                            <a href="/ve-chung-toi.html" target="_blank">Về chúng tôi</a>
                        </li>
                        <li>
                            <a href="#" target="_blank">D’media là gì?</a>
                        </li>
                        <li>
                            <a target="_blank" href="https://www.sapo.vn/blog" rel="noopener">Blog</a>
                        </li>
                        <li>
                            <a href="/bang-gia.html" target="_blank">Bảng giá</a>
                        </li>
                        <li>
                            <a href="#" target="_blank" rel="noopener">Tuyển dụng</a>
                        </li>
                        <li>
                            <a href="/profile-san-pham" target="_blank">Profile Sản Phẩm</a>
                        </li>

                    </ul>
                </div>
                <div class="col-lg col-md-4 col-6">
                    <div class="title">Marketing nha khoa</div>
                    <ul>
                        <li>
                            <a href="/phan-mem-quan-ly-ban-hang.html" rel="dofollow" target="_blank">Thiết kế website </a>
                        </li>
                        <li>
                            <a href="/quan-ly-ban-hang-online.html" rel="dofollow" target="_blank">Marketing trực tuyến</a>
                        </li>
                        <li>
                            <a href="/thiet-ke-website-ban-hang.html" rel="dofollow" target="_blank">Xây dựng thương hiệu</a>
                        </li>
                      
                    </ul>
                </div>
                <hr style="border-top-color: #2b2a32; width: 100%; margin: 25px 0 30px;" class="d-block d-md-none" />
                <div class="col-lg col-md-4 col-6">
                    
                </div>
                <div class="col-lg col-md-4 col-6">
                    
                </div>
                <hr style="border-top-color: #2b2a32; width: 100%; margin: 25px 0 30px;" class="d-block d-md-none" />

                <div class="col-lg col-md-4 col-6 d-block d-lg-none">
                    <div class="title">Trợ giúp</div>
                    <ul>
                        <li>
                            <a target="_blank" href="//support.sapo.vn/?utm_campaign=cpn:support_sapo-plm:footer&utm_source=sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" rel="nofollow noopener">Trung tâm trợ giúp</a>
                        </li>
                        <li>
                            <a target="_blank" href="//support.sapo.vn/cac-hinh-thuc-thanh-toan-khi-su-dung-dich-vu-cua-sapo?utm_campaign=cpn:hinh_thuc_thanh_toan-plm:footer&utm_source=sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" rel="nofollow noopener">Hình thức thanh toán</a>
                        </li>
                        <li>
                            <a target="_blank" href="//support.sapo.vn/huong-dan-dang-nhap-he-thong-sapo?utm_campaign=cpn:huong_dan_dang_nhap-plm:footer&utm_source=sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" rel="nofollow noopener">Hướng dẫn đăng nhập Sapo</a>
                        </li>
                        <li>
                            <a target="_blank" href="//support.sapo.vn/quy-dinh-su-dung?utm_campaign=cpn:quy_sinh_su_dung-plm:footer&utm_source=sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" rel="nofollow noopener">Quy định sử dụng</a>
                        </li>
                        <li>
                            <a target="_blank" href="//support.sapo.vn/chinh-sach-bao-mat?utm_campaign=cpn:chinh_sach_bao_mat-plm:footer&utm_source=sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" rel="nofollow noopener">Chính sách bảo mật</a>
                        </li>
                        <li>
                            <a target="_blank" href="//www.sapo.vn/lien-he.html?utm_campaign=cpn:lien_he-plm:footer&utm_source=sapo.vn&utm_medium=internal&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" rel="nofollow noopener">Liên hệ</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="footer-address">
        <div class="container">
            <div class="row">
                <div class="col-w-20 col-md-4 d-lg-block d-none">
                    <div class="title">Trợ giúp</div>
                    <ul>
                        <li>
                            <a href="//support.sapo.vn/?utm_campaign=cpn:support_sapo-plm:footer&utm_source=sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" rel="nofollow noopener" target="_blank">Trung tâm trợ giúp</a>
                        </li>
                        <li>
                            <a href="//support.sapo.vn/cac-hinh-thuc-thanh-toan-khi-su-dung-dich-vu-cua-sapo?utm_campaign=cpn:hinh_thuc_thanh_toan-plm:footer&utm_source=sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" rel="nofollow noopener" target="_blank">Hình thức thanh toán</a>
                        </li>
                        <li>
                            <a href="//support.sapo.vn/huong-dan-dang-nhap-he-thong-sapo?utm_campaign=cpn:huong_dan_dang_nhap-plm:footer&utm_source=sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" rel="nofollow noopener" target="_blank">Hướng dẫn đăng nhập Sapo</a>
                        </li>
                        <li>
                            <a href="//support.sapo.vn/quy-dinh-su-dung?utm_campaign=cpn:quy_sinh_su_dung-plm:footer&utm_source=sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" rel="nofollow noopener" target="_blank">Quy định sử dụng</a>
                        </li>
                        <li>
                            <a href="//support.sapo.vn/chinh-sach-bao-mat?utm_campaign=cpn:chinh_sach_bao_mat-plm:footer&utm_source=sapo.vn&utm_medium=referral&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" rel="nofollow noopener" target="_blank">Chính sách bảo mật</a>
                        </li>
                        <li>
                            <a href="//www.sapo.vn/lien-he.html?utm_campaign=cpn:lien_he-plm:footer&utm_source=sapo.vn&utm_medium=internal&utm_content=fm:text_link-km:-sz:&utm_term=&campaign=footer_sapo" target="_blank" rel="nofollow noopener">Liên hệ</a>
                        </li>
                    </ul>
                </div>
                <div class="col-w-20 col-md-4">
                    <div class="title">Dịch vụ</div>
                    <ul>
                        <li>
                            <a href="//www.sapo.vn/Themes/Portal/Default/Contents/bang-gia-dich-vu-support-don-le-2021.pdf?v=6" target="_blank" rel="noopener">Dịch vụ support</a>
                        </li>
                        <li>
                            <a href="//www.sapo.vn/dang-ky-ten-mien.html" target="_blank" rel="noopener">Đăng ký tên miền</a>
                        </li>
                        <li>
                            <a href="//www.sapo.vn/dich-vu-email-doanh-nghiep.html" target="_blank" rel="noopener">Email doanh nghiệp</a>
                        </li>
                    </ul>
                    
                </div>

                <div class="col-w-60 col-md-8">
                    <div class="title">Liên hệ</div>
                    <ul class="social">
                        <li>
                            <a href="https://www.facebook.com/sapo.vn/" target="_blank" rel="noopener" aria-label="Facebook"><i class="fa fa-facebook-square"></i></a>
                        </li>
                        <li>
                            <a href="https://www.youtube.com/channel/UCXOMQd_gKgELyY_fhmPjI4w" target="_blank" rel="noopener" aria-label="Youtube"><i class="fa fa-youtube"></i></a>
                        </li>
                        <li>
                            <a href="https://www.sapo.vn/blog" target="_blank" rel="noopener" aria-label="Blog sapo"><i class="fa fa-weixin"></i></a>
                        </li>
                    </ul>
                    <div class="contact-info">
                        <p class="text-uppercase">CÔNG TY CỔ PHẦN DỊCH VỤ VÀ CÔNG NGHỆ DTH VIỆT NAM</p>
                        <p><span>Trụ sở <i class="fa fa-map-marker"></i> </span>Tầng 6 - Tòa nhà Ladeco - 266 Đội Cấn - Phường Liễu Giai - Quận Ba Đình - TP Hà Nội</p>
                        <p>
                            <span class="d-xl-inline d-block">Chi nhánh </span><i class="fa fa-map-marker"></i>  78C, Tổ 3, Phường Khương Trung, Quận Thanh Xuân, Thành Phố Hà Nội, Khương Đình, Thanh Xuân, Hà Nội
                        </p>
                       
                        <p><strong>Tổng đài tư vấn và hỗ trợ khách hàng: </strong><b> 0886 360 808</b></p>
                        <p><span>Email: </span><b>dmedia@dthgroup.vn</b></p>
                        <p>Từ 8h00 – 22h00 các ngày từ thứ 2 đến Chủ nhật</p>
                    </div>
                   
                  
                </div>
            </div>
        </div>
    </div>
   
</div>
<!-- Banner marketing -->

<style type="text/css">

    .sapo-advertiser {
        position: fixed;
        bottom: 0;
        left: 0;
        z-index: 999;
    }

        .sapo-advertiser a {
            outline: none;
        }

        .sapo-advertiser .popup-adv {
            position: relative;
        }

            .sapo-advertiser .popup-adv i {
                z-index: 99;
                color: #333;
                font-size: 24px;
                cursor: pointer;
                height: 15px;
                width: 15px;
                line-height: 15px;
            }

            .sapo-advertiser .popup-adv .hide-popup {
                position: absolute;
                right: -15px;
                top: 0;
            }

                .sapo-advertiser .popup-adv .hide-popup.active {
                    top: 0;
                    right: 0;
                }
</style>
<script type="text/javascript">
    addLoadEvent(function () {
        var checkHide = sessionStorage.getItem("hide_banner");
        if (checkHide == null) {
            $(".sapo-advertiser").show();
        }

        $(".sapo-advertiser .popup-adv .hide-popup").click(function () {
            $(".sapo-advertiser").hide();
            sessionStorage.setItem("hide_banner", "true");
        });
    });
</script>

<div style="visibility:hidden; position: absolute; z-index: -1; bottom: 0; left: 0;">
    <svg xmlns="http://www.w3.org/2000/svg">
        <symbol id="icon-sapo-pay">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 327 353" style="enable-background:new 0 0 327 353;" xml:space="preserve">
<style type="text/css">
    .st0-pay {
        fill: url(#SVGID_1_P);
    }

    .st1-pay {
        fill: #FFFFFF;
    }
</style>
<linearGradient id="SVGID_1_P" gradientUnits="userSpaceOnUse" x1="46.5758" y1="6185.751" x2="287.8547" y2="5944.4722" gradientTransform="matrix(1 0 0 1 0 -5882.0005)">
            <stop offset="0" style="stop-color:#006BBB" />















            <stop offset="1" style="stop-color:#30A0E0" />















</linearGradient>
<path class="st0-pay" d="M242.4,317H78.8C53.5,317,33,296.5,33,271.2V108.3c0-22.5,16.3-41.7,38.5-45.2l163.6-26.5  c27.9-4.5,53.1,17,53.1,45.2v189.3C288.2,296.5,267.7,317,242.4,317z" />















<g>
            <path class="st1-pay" d="M254.8,120.9c-2.8-3.3-6.7-5.3-11.1-5.7L109,103.5c-4.3-0.4-8.5,1-11.9,3.8c-3.3,2.8-5.3,6.7-5.7,11l-2.7,25.2   h-10c-9,0-16.3,7.3-16.3,16.3v87.5c0,9,7.3,16.3,16.3,16.3H214c9,0,16.3-7.3,16.3-16.3v-12.7l3.5,0.3c8.9,0.7,16.8-6,17.6-14.9   l7.3-87.2C259,128.4,257.6,124.2,254.8,120.9z M219.8,247.3c0,3.2-2.6,5.8-5.8,5.8H78.8c-3.2,0-5.8-2.6-5.8-5.8v-46.6h146.8V247.3z    M219.8,190.2H73v-13.4h146.8V190.2z M219.8,166.4H73v-6.6c0-3.2,2.6-5.8,5.8-5.8H214c3.2,0,5.8,2.6,5.8,5.8V166.4z M248.2,131.9   L248.2,131.9l-7.3,87.2c-0.1,1.5-0.9,2.9-2,3.9c-1.2,1-2.7,1.5-4.2,1.4l-4.4-0.4v-64.3c0-9-7.3-16.3-16.3-16.3H99.3l2.6-24.1l0-0.1   c0.1-1.5,0.9-2.9,2-3.9c1.2-1,2.7-1.5,4.2-1.4l134.8,11.7c1.5,0.1,2.9,0.9,3.9,2C247.9,128.9,248.3,130.4,248.2,131.9z" />















            <path class="st1-pay" d="M167.6,244.3h37.3c2.9,0,5.2-2.3,5.2-5.2v-24.3c0-2.9-2.3-5.2-5.2-5.2h-37.3c-2.9,0-5.2,2.3-5.2,5.2v24.3   C162.4,242,164.7,244.3,167.6,244.3z M172.9,220h26.9v13.9h-26.9V220z" />















</g>
</svg>
        </symbol>


        <symbol id="icon-sapo-market">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 353.4 353" style="enable-background:new 0 0 353.4 353;" xml:space="preserve">
<style type="text/css">
    .st0-market {
        fill: url(#SVGID_1_MK);
    }

    .st1-market {
        fill: #FFFFFF;
    }
</style>
<linearGradient id="SVGID_1_MK" gradientUnits="userSpaceOnUse" x1="59.7062" y1="50.4697" x2="300.9851" y2="291.7486" gradientTransform="matrix(1 0 0 -1 0 354.2202)">
            <stop offset="0" style="stop-color:#00D08B" />































            <stop offset="1" style="stop-color:#00E290" />































</linearGradient>
<path class="st0-market" d="M255.5,317H91.9c-25.3,0-45.8-20.5-45.8-45.8V108.3c0-22.5,16.3-41.7,38.5-45.2l163.6-26.5  c27.9-4.5,53.1,17,53.1,45.2v189.3C301.3,296.5,280.8,317,255.5,317z" />































<g>
            <path class="st1-market" d="M264.6,147.7c-1.1-1.3-2.8-2.1-4.6-2.1h-18v-30c0-3.3-2.7-6-6-6h-9.5l1.8-1.8c2.3-2.3,2.3-6.1,0-8.5   c-2.3-2.3-6.1-2.3-8.5,0l-7.7,7.7l-7.8-7.8c-2.3-2.3-6.1-2.3-8.5,0c-2.3,2.3-2.3,6.1,0,8.5l1.8,1.8h-9.5c-3.3,0-6,2.7-6,6v6h-53.9   c-3.3,0-6,2.7-6,6v18h-12.3L98,102c-0.7-2.6-3.1-4.4-5.8-4.4H67.4c-3.3,0-6,2.7-6,6s2.7,6,6,6h20.2l33.1,121.5   c-6.3,2.8-10.6,9.1-10.6,16.4c0,8.3,5.6,15.3,13.3,17.3c-0.8,2.1-1.3,4.3-1.3,6.6c0,9.9,8.1,18,18,18c9.9,0,18-8.1,18-18   c0-2.1-0.4-4.1-1-6h50c-0.7,1.9-1,3.9-1,6c0,9.9,8.1,18,18,18c9.9,0,18-8.1,18-18s-8.1-18-18-18h-95.9c-3.3,0-6-2.7-6-6   c0-3.1,2.3-5.7,5.4-6l121-12c2.6-0.2,4.9-2.3,5.4-5l12-71.9C266.2,150.8,265.8,149,264.6,147.7L264.6,147.7z M194.1,121.6h36v24   h-36V121.6z M134.2,133.6h48v12h-48V133.6z M253,157.5L242.9,218l-110.3,11l-19.5-71.4H253z M146.1,271.4c0,3.3-2.7,6-6,6   s-6-2.7-6-6s2.7-6,6-6S146.1,268.1,146.1,271.4z M224.1,277.4c-3.3,0-6-2.7-6-6s2.7-6,6-6s6,2.7,6,6S227.4,277.4,224.1,277.4z" />































            <path class="st1-market" d="M188.1,205.5c3.3,0,6-2.7,6-6v-24c0-3.3-2.7-6-6-6c-3.3,0-6,2.7-6,6v24C182.1,202.8,184.8,205.5,188.1,205.5z" />































            <path class="st1-market" d="M224.1,205.5c3.3,0,6-2.7,6-6v-24c0-3.3-2.7-6-6-6s-6,2.7-6,6v24C218.1,202.8,220.8,205.5,224.1,205.5z" />































            <path class="st1-market" d="M152.1,205.5c3.3,0,6-2.7,6-6v-24c0-3.3-2.7-6-6-6s-6,2.7-6,6v24C146.1,202.8,148.8,205.5,152.1,205.5z" />































</g>
</svg>
        </symbol>


        <symbol id="icon-sapo-express">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 327 353" style="enable-background:new 0 0 327 353;" xml:space="preserve">
            <style type="text/css">
                .st0-express {
                    fill: url(#SVGID_1_);
                }

                .st1-express {
                    fill: #FFFFFF;
                }
</style>
            <linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="33" y1="422.5004" x2="288.22" y2="422.5004" gradientTransform="matrix(1 0 0 1 0 -246)">
            <stop offset="0" style="stop-color:#0088FF" />































            <stop offset="1" style="stop-color:#00B7FF" />































                </linearGradient>
            <path class="st0-express" d="M242.39,317H78.83C53.52,317,33,296.48,33,271.17V108.3c0-22.49,16.31-41.65,38.51-45.24L235.07,36.6  c27.87-4.51,53.15,17.01,53.15,45.24v189.33C288.22,296.48,267.7,317,242.39,317z" />































            <path class="st1-express" d="M254.31,137.59c-0.51-0.43-1.16-0.71-1.77-0.96c-0.53-0.21-1.05-0.43-1.58-0.64c-0.84-0.34-1.68-0.68-2.51-1.02  c-1.11-0.45-2.22-0.9-3.33-1.36c-1.34-0.55-2.68-1.09-4.02-1.64c-1.53-0.62-3.06-1.25-4.6-1.87c-1.68-0.69-3.37-1.37-5.05-2.06  c-1.8-0.73-3.6-1.47-5.39-2.2c-1.87-0.76-3.74-1.53-5.62-2.29c-1.91-0.78-3.81-1.55-5.72-2.33c-1.9-0.78-3.8-1.55-5.7-2.33  c-1.86-0.76-3.71-1.51-5.57-2.27c-1.77-0.72-3.55-1.45-5.32-2.17c-1.65-0.67-3.3-1.35-4.95-2.02c-1.49-0.61-2.97-1.21-4.46-1.82  c-1.29-0.52-2.57-1.05-3.86-1.57c-1.04-0.43-2.09-0.85-3.13-1.28c-0.76-0.31-1.53-0.62-2.29-0.93c-0.44-0.18-0.88-0.36-1.33-0.54  c-0.1-0.04-0.2-0.07-0.29-0.12c-1.24-0.62-2.91-0.62-4.02-0.06c-0.36,0.15-0.71,0.29-1.07,0.44c-1,0.41-2,0.82-3,1.23  c-1.54,0.63-3.07,1.26-4.61,1.89c-1.97,0.81-3.93,1.61-5.9,2.42c-2.29,0.94-4.57,1.87-6.86,2.81c-2.5,1.03-5.01,2.05-7.51,3.08  c-2.61,1.07-5.22,2.14-7.83,3.21c-2.61,1.07-5.22,2.14-7.84,3.21c-2.51,1.03-5.01,2.05-7.52,3.08c-2.29,0.94-4.59,1.88-6.88,2.82  c-1.97,0.81-3.95,1.62-5.92,2.43c-1.55,0.63-3.09,1.27-4.64,1.9c-1.01,0.42-2.03,0.83-3.04,1.25c-1.78,0.73-4.73,1.68-4.73,4.07  v22.73H59.23c-2.99,0-5.42,2.43-5.42,5.42c0,2.36,1.44,5.72,5.5,5.77l0.15,0.01h36.98v10.31H80.88c-2.99,0-5.42,2.43-5.42,5.42  s2.43,5.42,5.42,5.42h15.56v10.31H66.46c-2.99,0-5.42,2.43-5.42,5.42s2.43,5.42,5.42,5.42h29.99v12.64c0,1.5,0.55,3.56,3.28,4.92  l74.43,31.07l0.45,0.14c0.28,0.14,0.74,0.36,1.33,0.36c0.42,0,1.24,0,2.04-0.61l73.9-30.88c2.12-0.53,3.54-2.54,3.54-5  c0,0,0-88.45,0-88.5c0-0.78-0.2-1.61-0.67-2.25C254.62,137.88,254.47,137.72,254.31,137.59z M175.93,116.95l23.41,9.31l-59.54,25.09  l-24.49-10.28L175.93,116.95z M170.51,250.3l-63.59-26.66v-8.91h12.28c2.99,0,5.42-2.43,5.42-5.42s-2.43-5.42-5.42-5.42h-12.28  v-10.31h30.71c2.99,0,5.42-2.43,5.42-5.42s-2.43-5.42-5.42-5.42h-30.71v-9.95h5.06c2.99,0,5.42-2.43,5.42-5.42s-2.43-5.42-5.42-5.42  h-5.06v-13.9l23.84,9.79l39.75,17.59L170.51,250.3L170.51,250.3z M175.93,166.52l-22.43-9.27l59.67-25.48l23.41,9.3l-36.76,15.62  L175.93,166.52z M245.29,223.64l-63.95,26.67v-74.83l18.4-7.5l45.55-19.18V223.64z" />































            </svg>
        </symbol>
        <symbol id="icon-sapo-fin">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" x="0px" y="0px" viewBox="0 0 327 353" style="enable-background:new 0 0 327 353;" xml:space="preserve">
            <style type="text/css">
                .st0 {
                    fill: url(#SVGID_1_2);
                }

                .st1 {
                    fill: #FFFFFF;
                }
</style>
            <linearGradient id="SVGID_1_2" gradientUnits="userSpaceOnUse" x1="33" y1="176.5" x2="288.2192" y2="176.5">
            <stop offset="0" style="stop-color:#00C5A7" />































            <stop offset="1" style="stop-color:#00D69A" />































            </linearGradient>
            <path class="st0" d="M242.39,317H78.83C53.52,317,33,296.48,33,271.17V108.3c0-22.49,16.31-41.65,38.51-45.24L235.07,36.6  c27.87-4.51,53.15,17.01,53.15,45.24v189.33C288.22,296.48,267.7,317,242.39,317z" />































            <g>
            <g>
            <g>
            <path class="st1" d="M127.04,206.54c-2.95,0-5.53-2.76-5.53-5.9c0-2.32,1.46-4.41,3.64-5.2c2.84-1.04,6.15,0.37,9.08,3.85     c1.97,2.34,5.46,2.64,7.8,0.68c2.34-1.97,2.64-5.46,0.68-7.8c-2.99-3.56-6.47-6.01-10.13-7.24v-6.43c0-3.06-2.48-5.53-5.53-5.53     s-5.53,2.48-5.53,5.53v6.48c-0.05,0.02-0.1,0.03-0.15,0.05c-6.53,2.38-10.92,8.65-10.92,15.6c0,4.41,1.7,8.61,4.78,11.83     c3.17,3.31,7.37,5.14,11.83,5.14c3.05,0,5.53,2.48,5.53,5.53c0,2.23-1.33,4.23-3.38,5.1c-2.48,1.05-5.44,0.15-8.14-2.46     c-2.2-2.13-5.7-2.07-7.83,0.12c-2.13,2.2-2.07,5.7,0.12,7.82c2.5,2.42,5.28,4.13,8.15,5.1v6.45c0,3.06,2.48,5.53,5.53,5.53     s5.53-2.48,5.53-5.53v-6.48c6.75-2.4,11.07-8.7,11.07-15.65C143.64,213.99,136.19,206.54,127.04,206.54z" />































                    </g>
                </g>
            <g>
            <g>
            <path class="st1" d="M236.98,91.01c-10.19-4.48-23.55-6.95-37.63-6.95c-28.81,0-55.34,10.58-55.34,27.67c0,4.28,0,37.52,0,41.52     c-5.46-1.59-11.16-2.41-16.97-2.41c-16.22,0-31.51,6.41-43.04,18.05c-11.5,11.6-17.83,26.94-17.83,43.19     c0,33.57,27.31,60.87,60.87,60.87c11.2,0,21.97-3.01,31.38-8.65c10.29,5.52,24.96,8.65,40.93,8.65c14.08,0,27.44-2.47,37.63-6.95     c11.66-5.13,18.08-12.49,18.08-20.72c0-3.45,0-130.03,0-133.55C255.05,103.49,248.63,96.14,236.98,91.01z M127.04,261.88     c-27.46,0-49.81-22.34-49.81-49.81c0-27.67,22.34-50.17,49.81-50.17c27.67,0,50.17,22.51,50.17,50.17     C177.21,239.53,154.7,261.88,127.04,261.88z M243.99,245.28c0,6.77-17.39,16.6-44.64,16.6c-11.59,0-22.54-1.86-30.85-5.11     c0.59-0.54,1.17-1.09,1.74-1.65c4.98-4.94,9-10.56,11.98-16.66c5.5,0.85,11.24,1.28,17.14,1.28c14.55,0,32.6-2.83,44.64-10.71     V245.28z M243.99,212.07c0,6.77-17.39,16.6-44.64,16.6c-4.51,0-8.92-0.28-13.16-0.83c1.37-5.09,2.09-10.38,2.09-15.77     c0-2.17-0.12-4.33-0.34-6.46c3.73,0.37,7.54,0.56,11.41,0.56c14.55,0,32.6-2.83,44.64-10.71V212.07z M243.99,178.5     c0,6.77-17.39,16.6-44.64,16.6c-4.71,0-9.32-0.31-13.75-0.91c-2.87-9.32-8-17.89-15.1-25.07c8.56,2.5,18.49,3.84,28.85,3.84     c14.55,0,32.6-2.83,44.64-10.71V178.5z M243.99,145.3c0,6.77-17.39,16.6-44.64,16.6c-12.55,0-24.26-2.13-32.97-6.01     c-6.97-3.1-11.3-7.16-11.3-10.6v-16.53c11.98,7.85,29.87,10.63,44.27,10.63c14.55,0,32.6-2.83,44.64-10.71V145.3z M199.35,128.33     c-27.03,0-44.27-9.69-44.27-16.6c0-6.94,17.29-16.6,44.27-16.6c27.25,0,44.64,9.83,44.64,16.6S226.6,128.33,199.35,128.33z" />































                    </g>
                </g>
            </g>
            </svg>
        </symbol>

        <symbol id="icon-sapo-pos">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 68.63 75.45"><defs><linearGradient id="linear-gradient-pos" x1="153.38" y1="125.97" x2="-5.62" y2="6.97" gradientTransform="matrix(1, 0, 0, -1, 0, 78)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#00ffc6" /><stop offset="1" stop-color="#006eff" /></linearGradient></defs><g><path d="M68.63,13.62A13.62,13.62,0,0,0,55,0h0L13.61,6.82A13.61,13.61,0,0,0,0,20.43H0V61.84A13.61,13.61,0,0,0,13.61,75.45H55A13.61,13.61,0,0,0,68.63,61.86V45.64c0-.7-.07-1.4-.07-2.12s0-1.45.07-2.16Z" fill="url(#linear-gradient-pos)" /><path d="M34.56,15.71,11.8,38.52a5.49,5.49,0,0,0,0,7.74L26.36,60.84a5.41,5.41,0,0,0,3.87,1.61h0a5.46,5.46,0,0,0,3.87-1.6L56.93,38V15.71ZM53.28,36.53,31.52,58.26a1.78,1.78,0,0,1-1.29.54h0a1.84,1.84,0,0,1-1.29-.54L14.38,43.68a1.83,1.83,0,0,1,0-2.58l21.7-21.74h17.2ZM43.79,27a1.83,1.83,0,1,1,1.84,1.82h0A1.84,1.84,0,0,1,43.79,27Zm-6,5.6L40,30.47l2.59,2.58-2.13,2.12a4.85,4.85,0,0,1,.47,1.94,4.68,4.68,0,0,1-1.38,3.54l-.32.32L36.6,38.39l.32-.32a1.27,1.27,0,0,0-.12-1.79,1.38,1.38,0,0,0-1-.42,1.17,1.17,0,0,0-.83.34c-.63.63-.66,1.5-.11,3.22h0a14.91,14.91,0,0,1,.78,3.36,4.81,4.81,0,0,1-1.37,3.86,5.6,5.6,0,0,1-6.4,1l-2.13,2.13-2.58-2.59,2.16-2.16a5.6,5.6,0,0,1,1.09-6.25l.51-.51,2.59,2.58L29,41.4a1.93,1.93,0,0,0,0,2.68,1.84,1.84,0,0,0,1.33.53,2,2,0,0,0,1.36-.55c.55-.56.32-1.55-.31-3.54h0c-.38-1.22-1.41-4.47,1-6.9a4.83,4.83,0,0,1,3.42-1.41,4.92,4.92,0,0,1,2,.42Z" fill="#fff" /></g></svg>
        </symbol>
        <symbol id="icon-sapo-pos-mobile">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 46.74 46.74">
                <defs>
                    <style>
                        .cls-1 {
                            fill: url(#linear-gradient);
                        }
                    </style>
                    <linearGradient id="linear-gradient" x1="-49.3" y1="23.37" x2="52.94" y2="23.37" gradientUnits="userSpaceOnUse"><stop offset="0.18" stop-color="#00ffc6" /><stop offset="0.32" stop-color="#00eccd" /><stop offset="0.6" stop-color="#00bce0" /><stop offset="1" stop-color="#006eff" /></linearGradient>
                </defs>
                <g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="cls-1" d="M24.36,0,1.6,22.81a5.49,5.49,0,0,0,0,7.74L16.16,45.13A5.41,5.41,0,0,0,20,46.74h0a5.47,5.47,0,0,0,3.88-1.6L46.74,22.33V0ZM43.08,20.82,21.32,42.55a1.78,1.78,0,0,1-1.29.54h0a1.82,1.82,0,0,1-1.29-.54L4.18,28a1.83,1.83,0,0,1,0-2.58L25.88,3.65h17.2Zm-9.49-9.5a1.83,1.83,0,1,1,1.83,1.83A1.83,1.83,0,0,1,33.59,11.32Zm-6,5.6,2.16-2.16,2.58,2.58-2.12,2.13a5.12,5.12,0,0,1,.47,1.93,4.68,4.68,0,0,1-1.39,3.54l-.32.32L26.4,22.68l.32-.32a1.27,1.27,0,0,0-.12-1.79,1.42,1.42,0,0,0-1-.42,1.16,1.16,0,0,0-.83.34c-.62.63-.65,1.5-.11,3.22v0a14.41,14.41,0,0,1,.77,3.35A4.79,4.79,0,0,1,24.08,31,5.6,5.6,0,0,1,17.68,32l-2.12,2.13L13,31.55l2.16-2.16a5.63,5.63,0,0,1-.51-2.34,5.53,5.53,0,0,1,1.6-3.92l.52-.51,2.58,2.58-.51.51a1.92,1.92,0,0,0,0,2.68,1.85,1.85,0,0,0,1.32.53,1.92,1.92,0,0,0,1.36-.55c.55-.56.32-1.55-.31-3.54v0c-.39-1.22-1.41-4.47,1-6.9a4.77,4.77,0,0,1,3.41-1.41A5,5,0,0,1,27.6,16.92Z" /></g></g>
            </svg>
        </symbol>
        <symbol id="icon-sapo-fnb">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 68.63 75.45"><defs><linearGradient id="linear-gradient-fnb" x1="50.04" y1="76.83" x2="26.04" y2="15.83" gradientTransform="matrix(1, 0, 0, -1, 0, 78)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#7cd1ff" /><stop offset="0.99" stop-color="#0cc2ed" /></linearGradient></defs><g><path d="M68.63,13.61A13.62,13.62,0,0,0,55,0h0L13.61,6.82A13.61,13.61,0,0,0,0,20.43H0V61.84A13.61,13.61,0,0,0,13.61,75.45H55A13.61,13.61,0,0,0,68.63,61.86V45.64c0-.7-.07-1.4-.07-2.12s0-1.45.07-2.16Z" fill="url(#linear-gradient-fnb)" /><path d="M54.81,21.48C52.89,17.91,50.43,16,47.88,16s-5,2-6.93,5.53a19.64,19.64,0,0,0-2.41,8.25v.34A8.88,8.88,0,0,0,46,38.57V63.78h3.74V38.57a8.87,8.87,0,0,0,7.47-8.5v-.34A19.63,19.63,0,0,0,54.81,21.48Zm-1.33,8.59c0,2.72-2.51,4.94-5.6,4.94s-5.6-2.22-5.6-4.94v-.34a15.92,15.92,0,0,1,2-6.48c1.19-2.2,2.58-3.56,3.64-3.56s2.45,1.36,3.64,3.56a15.92,15.92,0,0,1,2,6.48Z" fill="#fff" /><path d="M32.89,52.56a12.7,12.7,0,1,1,.84-25.39,11.21,11.21,0,0,1,1.3.11,22.7,22.7,0,0,1,1-3.64,18.61,18.61,0,0,0-2.11-.21,16.44,16.44,0,1,0,8.43,30.21V48.85A12.65,12.65,0,0,1,32.89,52.56Z" fill="#fff" /><path d="M32.64,60A20.18,20.18,0,0,1,34,19.7a20.42,20.42,0,0,1,3.48.42l.21-.42a20.08,20.08,0,0,1,1.91-2.92A24.32,24.32,0,0,0,34.1,16a23.92,23.92,0,1,0,8.18,46.09V57.94A20,20,0,0,1,32.64,60Z" fill="#fff" /><path d="M57.2,38.77a13.2,13.2,0,0,1-3.71,2.51V52.72a23.84,23.84,0,0,0,3.72-12.07C57.23,40,57.22,39.4,57.2,38.77Z" fill="#fff" /></g></svg>
        </symbol>
        <symbol id="icon-sapo-fnb-mobile">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 47.83 47.83">
                <defs>
                    <style>
                        .cls-1b {
                            fill: url(#linear-gradientb);
                        }

                        .cls-2b {
                            fill: url(#linear-gradient-2b);
                        }

                        .cls-3b {
                            fill: url(#linear-gradient-3b);
                        }

                        .cls-4b {
                            fill: url(#linear-gradient-4b);
                        }
                    </style>
                    <linearGradient id="linear-gradientb" x1="29.15" y1="23.91" x2="47.83" y2="23.91" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#7cd1ff" /><stop offset="0.99" stop-color="#0cc2ed" /></linearGradient>
                    <linearGradient id="linear-gradient-2b" x1="7.47" y1="23.91" x2="32.88" y2="23.91" xlink:href="#linear-gradientb" />
                    <linearGradient id="linear-gradient-3b" x1="0" y1="23.91" x2="32.88" y2="23.91" xlink:href="#linear-gradientb" />
                    <linearGradient id="linear-gradient-4b" x1="44.09" y1="29.8" x2="47.83" y2="29.8" xlink:href="#linear-gradientb" />
                </defs>
                <g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="cls-1b" d="M45.42,5.53C43.49,2,41,0,38.49,0s-5,2-6.93,5.53a19.58,19.58,0,0,0-2.41,8.25v.34a8.88,8.88,0,0,0,7.47,8.5V47.83h3.74V22.62a8.88,8.88,0,0,0,7.47-8.5v-.34A19.58,19.58,0,0,0,45.42,5.53Zm-1.33,8.59c0,2.72-2.51,4.94-5.6,4.94s-5.61-2.22-5.61-4.94v-.34a16,16,0,0,1,2-6.48C36,5.1,37.43,3.74,38.49,3.74S40.94,5.1,42.13,7.3a15.91,15.91,0,0,1,2,6.48Z" /><path class="cls-2b" d="M23.5,36.61a12.7,12.7,0,1,1,.83-25.39,11,11,0,0,1,1.3.11,23.82,23.82,0,0,1,.94-3.64,18.38,18.38,0,0,0-2.11-.21,16.44,16.44,0,1,0,8.42,30.21V32.9A12.64,12.64,0,0,1,23.5,36.61Z" /><path class="cls-3b" d="M23.25,44.08A20.18,20.18,0,0,1,24.58,3.75a19.71,19.71,0,0,1,3.47.42l.22-.42A20.75,20.75,0,0,1,30.18.83,24.34,24.34,0,0,0,24.7,0,23.91,23.91,0,0,0,6.46,40.26,23.95,23.95,0,0,0,32.88,46.1V42A20,20,0,0,1,23.25,44.08Z" /><path class="cls-4b" d="M47.8,22.82a12.92,12.92,0,0,1-3.71,2.51V36.77A23.84,23.84,0,0,0,47.82,24.7C47.84,24.07,47.83,23.45,47.8,22.82Z" /></g></g>
            </svg>
        </symbol>
        <symbol id="icon-sapo-go">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 68.63 75.45"><defs><linearGradient id="linear-gradient-go" x1="78.88" y1="94.64" x2="-2.12" y2="-10.36" gradientTransform="matrix(1, 0, 0, -1, 0, 78)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#0fd186" /><stop offset="0.11" stop-color="#18ca8f" /><stop offset="0.38" stop-color="#2abda1" /><stop offset="0.66" stop-color="#35b5ac" /><stop offset="1" stop-color="#38b2af" /></linearGradient></defs><g><path d="M68.63,13.61A13.62,13.62,0,0,0,55,0h0L13.61,6.82A13.61,13.61,0,0,0,0,20.43H0V61.84A13.61,13.61,0,0,0,13.61,75.45H55A13.61,13.61,0,0,0,68.63,61.86V45.64c0-.7-.07-1.4-.07-2.12s0-1.45.07-2.16Z" fill="url(#linear-gradient-go)" /><path d="M11,40.93V36.62c.09,0,.1-.09.11-.17a23.82,23.82,0,0,1,1.79-6.79l.49-1.09a30.27,30.27,0,0,1,3.21-4.86,36.57,36.57,0,0,1,2.92-2.92,30.27,30.27,0,0,1,4.86-3.21l1.09-.49a26,26,0,0,1,5-1.52,13.85,13.85,0,0,0,2.12-.38h4s.07.09.11.1a23.51,23.51,0,0,1,6.56,1.55l.25.08,1.22.54a.92.92,0,0,0,.47.24l1,.55a.85.85,0,0,0,.44.25l.88.56a1.08,1.08,0,0,0,.49.32l.92.68.44.34.81.68.43.37.68.66a1.68,1.68,0,0,0,.46.46l.77.84a.48.48,0,0,0,.25.29l.77,1,.24.31.59.86a1.1,1.1,0,0,0,.32.48l.66,1.13c0,.08,0,.18.12.22L56,28.81a.48.48,0,0,0,.15.32l.46,1.14.17.46a2,2,0,0,1-.25,1.93l-.27.28a3.4,3.4,0,0,1-2,.41H46.63c-1.48,0-1.48,0-1.3,1.47v.69A2,2,0,0,1,43.8,37h-.57a3.08,3.08,0,0,1-1-.48L41.88,36a4.07,4.07,0,0,1-.23-1.1v-.57c0-1.31,0-1-1-1H28c-.41,0-.4.08-.42.36,0,.49-.07,1-.11,1.46l-.1,1.72a1.89,1.89,0,0,0,0,.67V39.8a6,6,0,0,0,.07,1.59V42a7.24,7.24,0,0,0,.12,1.47,1.44,1.44,0,0,0,.08.68,9.26,9.26,0,0,0,.17,1.39l.09.54a6.24,6.24,0,0,0,.23,1.36l.11.57a7.93,7.93,0,0,0,.33,1.36l.13.45a7.21,7.21,0,0,0,.41,1.37.4.4,0,0,0,.11.34,5.93,5.93,0,0,0,.38,1.24l.11.57a1.9,1.9,0,0,1-1.83,1.83h-.45a3.74,3.74,0,0,1-.92-.55l-.32-.47L25.86,53l-.15-.48-.38-1.23a.66.66,0,0,0-.13-.45l-.35-1.36a.71.71,0,0,0-.11-.45c-.24-1.41-.09-1.13-.9-1.12H16.76l.74,1.23a1.21,1.21,0,0,0,.31.49,3.46,3.46,0,0,0,.6.87,1,1,0,0,0,.33.44,3.21,3.21,0,0,0,.66.81.73.73,0,0,0,.32.35,5.06,5.06,0,0,0,.84.89.57.57,0,0,0,.28.25,4.49,4.49,0,0,0,1.06.93l.23.19A3.21,3.21,0,0,0,23,55a1.09,1.09,0,0,0,.46.33,3.88,3.88,0,0,0,.91.57l.45.31a2.69,2.69,0,0,1,.66,1v.29c-.09,1.28-.62,1.82-1.94,2l-.46-.08-1-.57-.48-.31-.87-.6a.55.55,0,0,0-.32-.24l-.95-.77a.57.57,0,0,0-.3-.25l-.83-.77-.47-.45a4.14,4.14,0,0,0-.78-.84l-.24-.28a4,4,0,0,0-.67-.81l-.35-.45a4.23,4.23,0,0,0-.66-.91.6.6,0,0,0-.24-.34,5,5,0,0,0-.64-1L14,50.38a4.87,4.87,0,0,0-.55-1,.49.49,0,0,0-.16-.32l-.52-1.15a1.28,1.28,0,0,0-.24-.59A35.88,35.88,0,0,1,11.32,43,8.66,8.66,0,0,0,11,40.93Zm34.11-19.2a5,5,0,0,0-1.22-.68,11.2,11.2,0,0,0-2.79-1.16,25.42,25.42,0,0,1,1.4,2.56l.55,1.35a.39.39,0,0,0,.14.37l.36,1.11.14.47.4,1.35a.66.66,0,0,0,.12.45l.26,1.24.12.59c0,.28.14.33.39.32h7.4a13.7,13.7,0,0,0-1.33-2.2c0-.08,0-.15-.12-.17a3.54,3.54,0,0,0-.72-1A.72.72,0,0,0,50,26a3.13,3.13,0,0,0-.79-.91.92.92,0,0,0-.35-.38,3,3,0,0,0-.8-.75.79.79,0,0,0-.36-.34,3.19,3.19,0,0,0-.86-.69,1.07,1.07,0,0,0-.39-.31,3.43,3.43,0,0,0-.87-.59.72.72,0,0,0-.44-.3ZM14.89,35.82a1.81,1.81,0,0,0-.1.69,9.13,9.13,0,0,0-.11,1.81v.57a5.58,5.58,0,0,0,.09,1.58V41A8,8,0,0,0,15,42.51a.74.74,0,0,0,.1.46c.05.25.1.5.13.76,0,.41.25.58.66.46h7.77c.29,0,.34-.09.31-.35-.08-.79-.13-1.58-.19-2.37a1.11,1.11,0,0,0-.06-.57V36.31a12,12,0,0,0,.11-1.7,1.43,1.43,0,0,0,.07-.68c.13-.4.07-.64-.44-.57a8.34,8.34,0,0,1-1,0h-6.8c-.22,0-.33,0-.38.28A13.27,13.27,0,0,0,14.89,35.82Zm9.86-7.25.57-2.27a2,2,0,0,0,.23-.79l1-2.66L27,21.76l1-1.87a12.09,12.09,0,0,0-2,.84,3.88,3.88,0,0,0-1.13.57,11.12,11.12,0,0,0-2,1.24A18.53,18.53,0,0,0,17.14,29a1.34,1.34,0,0,0-.33.66h6.8c1,.06,1,.06,1.13-.89A1.34,1.34,0,0,0,24.75,28.57Zm15.63-1.48-.12-.45a5.59,5.59,0,0,0-.43-1.37.34.34,0,0,0-.11-.33,4.27,4.27,0,0,0-.46-1.25.87.87,0,0,0-.2-.46,4.35,4.35,0,0,0-.55-1.15.89.89,0,0,0-.26-.45,3.36,3.36,0,0,0-.59-.89.72.72,0,0,0-.29-.35,2.45,2.45,0,0,0-.81-.79.89.89,0,0,0-.48-.33,2.18,2.18,0,0,0-1.35-.43,2.73,2.73,0,0,0-2.07.73,8.79,8.79,0,0,0-2.59,3.89,12,12,0,0,0-.94,2.62,1.78,1.78,0,0,0-.21.78,12.71,12.71,0,0,0-.54,2.27c-.15.35-.27.67.34.55H40.66c.25,0,.34-.05.28-.31C40.75,28.62,40.57,27.86,40.38,27.09Z" fill="#fff" /><path d="M56.5,42.42H35.59c-.28,0-.38.06-.29.34.34,1.13.67,2.27,1,3.4a.69.69,0,0,0,.13.46l.34,1.24.18.58a4.87,4.87,0,0,0,.35,1.24.67.67,0,0,0,.14.45c.09.37.19.74.27,1.12s.19.28.41.22H54.67c.2,0,.34,0,.4-.26.28-1.13.59-2.25.88-3.37a1.79,1.79,0,0,0,.21-.79,12.93,12.93,0,0,0,.58-2.11,4,4,0,0,0,.3-1.07c.06-.19.13-.39.18-.58C57.49,42.36,57.48,42.36,56.5,42.42Z" fill="none" /><path d="M39.57,41.54a4.13,4.13,0,0,0-4-3.19h-4.1v4.14h4.06l2.36,10a4.14,4.14,0,0,0,4,3.2h8.19A5.12,5.12,0,0,0,54.92,52L58,42.91H39.89Zm12.66,5.52L51,50.74h0a1,1,0,0,1-.85.73H41.93L40.87,47Zm-7.9,12.65a2.08,2.08,0,1,1-2.09-2.07h0A2.09,2.09,0,0,1,44.33,59.71Zm7.78,0A2.08,2.08,0,1,1,50,57.64a2.08,2.08,0,0,1,2.11,2.07Z" fill="#fff" /></g></svg>
        </symbol>
        <symbol id="icon-sapo-go-mobile">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 46.98 46.6">
                <defs>
                    <style>
                        .cls-1go {
                            fill: url(#linear-gradientgo);
                        }

                        .cls-2go {
                            fill: url(#linear-gradient-2go);
                        }
                    </style>
                    <linearGradient id="linear-gradientgo" y1="22.15" x2="45.9" y2="22.15" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#0fd186" /><stop offset="0.11" stop-color="#18ca8f" /><stop offset="0.38" stop-color="#2abda1" /><stop offset="0.66" stop-color="#35b5ac" /><stop offset="1" stop-color="#38b2af" /></linearGradient>
                    <linearGradient id="linear-gradient-2go" x1="20.44" y1="34.88" x2="46.98" y2="34.88" xlink:href="#linear-gradientgo" />
                </defs>
                <g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="cls-1go" d="M0,25.74V21.43c.09,0,.11-.08.12-.16a23.87,23.87,0,0,1,1.78-6.8l.49-1.09A30.78,30.78,0,0,1,5.61,8.52,40,40,0,0,1,8.52,5.61a30.78,30.78,0,0,1,4.86-3.22l1.09-.49a26.72,26.72,0,0,1,5-1.52A13.64,13.64,0,0,0,21.54,0h4s.07.1.11.1a24,24,0,0,1,6.57,1.55l.24.09,1.22.54a.9.9,0,0,0,.47.23l1,.55a.94.94,0,0,0,.44.26l.89.55A1.22,1.22,0,0,0,37,4.2l.93.67.44.34.81.68.42.37.69.66a1.52,1.52,0,0,0,.45.46l.78.85a.51.51,0,0,0,.24.28l.77,1,.24.31.6.87a1.17,1.17,0,0,0,.31.48l.66,1.12c0,.09,0,.18.12.22L45,13.62a.46.46,0,0,0,.15.33l.46,1.13.16.47a2,2,0,0,1-.24,1.92l-.27.29a3.34,3.34,0,0,1-2,.4H35.83l-.22,0c-1.48,0-1.48,0-1.3,1.47l0,.69a2,2,0,0,1-1.5,1.48H32.2a3.08,3.08,0,0,1-1-.48l-.37-.46a4.22,4.22,0,0,1-.23-1.11l0-.57c0-1.31,0-1-1-1H18.26c-.42,0-.83,0-1.24,0s-.41.07-.43.36c0,.49-.07,1-.11,1.46l-.1,1.71a1.52,1.52,0,0,0,0,.67l0,1.7v.57a6.43,6.43,0,0,0,.08,1.58l0,.57a8,8,0,0,0,.11,1.47,1.35,1.35,0,0,0,.09.69,7.13,7.13,0,0,0,.17,1.38l.08.54a6.78,6.78,0,0,0,.23,1.36l.12.57a6.43,6.43,0,0,0,.33,1.36l.12.46A7.11,7.11,0,0,0,18.12,36c0,.13,0,.25.11.34a6.62,6.62,0,0,0,.39,1.24l.1.57c-.23,1.2-.68,1.66-1.82,1.83l-.45,0a3.31,3.31,0,0,1-.92-.55l-.33-.47-.36-1.12-.15-.47-.39-1.24a.61.61,0,0,0-.13-.45l-.35-1.36a.66.66,0,0,0-.11-.45c-.24-1.41-.09-1.13-.9-1.11H5.74l.74,1.23a1.06,1.06,0,0,0,.31.49,3,3,0,0,0,.59.87,1.08,1.08,0,0,0,.34.45,3.21,3.21,0,0,0,.66.81.75.75,0,0,0,.31.35,4.73,4.73,0,0,0,.85.88.51.51,0,0,0,.28.26,4.9,4.9,0,0,0,1,.93l.24.19a3.3,3.3,0,0,0,.9.67,1,1,0,0,0,.46.34,4.09,4.09,0,0,0,.91.57l.46.3a2.75,2.75,0,0,1,.65,1l0,.3c-.09,1.27-.61,1.81-1.94,2l-.45-.07-1-.57-.47-.31-.87-.61a.57.57,0,0,0-.32-.23l-1-.78a.46.46,0,0,0-.29-.24l-.84-.78-.46-.45a4.73,4.73,0,0,0-.78-.83l-.25-.29a4.31,4.31,0,0,0-.67-.81l-.35-.44A4.29,4.29,0,0,0,4.21,37,.67.67,0,0,0,4,36.62a6.18,6.18,0,0,0-.64-1l-.27-.45a4.51,4.51,0,0,0-.55-1,.46.46,0,0,0-.15-.33l-.53-1.14a1.42,1.42,0,0,0-.23-.6A33.24,33.24,0,0,1,.37,27.74,8.5,8.5,0,0,0,0,25.74ZM34.11,6.54a5,5,0,0,0-1.21-.68A11.59,11.59,0,0,0,30.1,4.7a29.15,29.15,0,0,1,1.41,2.56l.54,1.36c0,.13,0,.27.14.36l.37,1.11.14.47.4,1.35a.6.6,0,0,0,.11.45l.26,1.25.13.58c0,.28.14.34.38.33l1.28,0h6.12a13.59,13.59,0,0,0-1.32-2.21c0-.07,0-.15-.12-.16a3.67,3.67,0,0,0-.73-1,.71.71,0,0,0-.29-.35,3.28,3.28,0,0,0-.79-.91.89.89,0,0,0-.35-.37A3,3,0,0,0,37,8.72a.88.88,0,0,0-.36-.33,3.44,3.44,0,0,0-.87-.7.83.83,0,0,0-.39-.3,3.07,3.07,0,0,0-.87-.6A.68.68,0,0,0,34.11,6.54ZM3.86,20.64a1.72,1.72,0,0,0-.09.68,10,10,0,0,0-.12,1.81v.57a5.67,5.67,0,0,0,.08,1.59l0,.56A7.44,7.44,0,0,0,4,27.33a.72.72,0,0,0,.11.45c0,.25.1.51.12.76,0,.41.25.58.66.47H10c.89,0,1.78,0,2.66,0,.29,0,.34-.09.31-.36-.08-.79-.13-1.58-.19-2.37a1.1,1.1,0,0,0,0-.57l0-1.7v-.57l0-1.7,0-.68a12.15,12.15,0,0,0,.12-1.7,1.31,1.31,0,0,0,.06-.68c.13-.41.07-.64-.44-.57a8.64,8.64,0,0,1-1,0H6.35c-.57,0-1.13,0-1.69,0-.22,0-.33,0-.39.28A15.22,15.22,0,0,0,3.86,20.64Zm9.86-7.26.57-2.27a2,2,0,0,0,.24-.79l1-2.66L16,6.58l1-1.87a10.08,10.08,0,0,0-2,.84,3.76,3.76,0,0,0-1.13.57,11.16,11.16,0,0,0-2,1.23,18.41,18.41,0,0,0-5.7,6.48,1.37,1.37,0,0,0-.33.67h6.8c1,.06,1,.06,1.13-.89A1.62,1.62,0,0,0,13.72,13.38Zm15.63-1.47-.12-.46a5.8,5.8,0,0,0-.42-1.36.37.37,0,0,0-.12-.34,4.38,4.38,0,0,0-.46-1.25A.74.74,0,0,0,28,8a4.11,4.11,0,0,0-.54-1.14,1,1,0,0,0-.27-.45,2.66,2.66,0,0,0-.59-.89.65.65,0,0,0-.29-.36,2.42,2.42,0,0,0-.8-.79.91.91,0,0,0-.48-.33,2.2,2.2,0,0,0-1.36-.43,2.8,2.8,0,0,0-2.07.73A9,9,0,0,0,19,8.27a12.79,12.79,0,0,0-.94,2.62,2.1,2.1,0,0,0-.21.78A11.82,11.82,0,0,0,17.35,14c-.15.34-.27.67.34.55h9.07c1,0,1.92,0,2.88,0,.25,0,.34-.06.27-.32C29.72,13.44,29.54,12.67,29.35,11.91Z" /><path class="cls-2go" d="M28.54,26.35a4.12,4.12,0,0,0-4-3.19H20.44v4.15h4.07l2.35,10a4.14,4.14,0,0,0,4,3.19h8.19a5.15,5.15,0,0,0,4.81-3.62L47,27.72H28.87ZM41.2,31.87,40,35.55l0,.06a1,1,0,0,1-.85.72H30.9l-1-4.46ZM33.3,44.53a2.07,2.07,0,1,1-2.07-2.08A2.07,2.07,0,0,1,33.3,44.53Zm7.78,0A2.08,2.08,0,1,1,39,42.45,2.07,2.07,0,0,1,41.08,44.53Z" /></g></g>
            </svg>
        </symbol>
        <symbol id="icon-sapo-web">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 68.63 75.45"><defs><linearGradient id="linear-gradient-web" x1="67.46" y1="93.68" x2="32.46" y2="33.68" gradientTransform="matrix(1, 0, 0, -1, 0, 78)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#4bef85" /><stop offset="0.58" stop-color="#28de86" /><stop offset="1" stop-color="#0fd186" /></linearGradient></defs><g><path d="M68.63,13.61A13.62,13.62,0,0,0,55,0h0L47.84,1.18h0L13.61,6.82A13.61,13.61,0,0,0,0,20.43H0V61.84A13.61,13.61,0,0,0,13.61,75.45H55A13.61,13.61,0,0,0,68.63,61.86V45.64c0-.7-.07-1.4-.07-2.12s0-1.45.07-2.16Z" fill="url(#linear-gradient-web)" /><path d="M52.94,16H18.45a5.27,5.27,0,0,0-5.28,5.28h0V55.72A5.3,5.3,0,0,0,18.45,61H52.94a5.3,5.3,0,0,0,5.28-5.28V21.23A5.28,5.28,0,0,0,52.94,16ZM18.45,19.47H52.94a1.76,1.76,0,0,1,1.76,1.76v5.28h-38V21.23A1.76,1.76,0,0,1,18.45,19.47Zm34.49,38H18.45a1.76,1.76,0,0,1-1.76-1.76V30h38V55.72a1.76,1.76,0,0,1-1.75,1.76ZM19.33,23a1.76,1.76,0,1,1,1.76,1.76A1.76,1.76,0,0,1,19.33,23Zm6.16,0a1.76,1.76,0,1,1,1.76,1.76A1.76,1.76,0,0,1,25.49,23Zm5.73,13.44a3.53,3.53,0,0,0-3.43-2.71H24.34v3.52h3.45l2,8.47a3.51,3.51,0,0,0,3.42,2.71h6.95a4.36,4.36,0,0,0,4.08-3.08l2.62-7.75H31.49ZM42,41.11l-1.1,3.13h0a.83.83,0,0,1-.72.62h-7l-.89-3.79ZM35.3,51.85a1.76,1.76,0,1,1-1.76-1.76h0a1.77,1.77,0,0,1,1.71,1.76Zm6.6,0a1.76,1.76,0,1,1-1.76-1.76h0a1.77,1.77,0,0,1,1.71,1.76Z" fill="#fff" /></g></svg>
        </symbol>
        <symbol id="icon-sapo-web-mobile">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 45.05 45.05">
                <defs>
                    <style>
                        .cls-1web {
                            fill: url(#linear-gradientweb);
                        }
                    </style>
                    <linearGradient id="linear-gradientweb" y1="22.53" x2="45.05" y2="22.53" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#4bef85" /><stop offset="0.58" stop-color="#28de86" /><stop offset="1" stop-color="#0fd186" /></linearGradient>
                </defs>
                <g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="cls-1web" d="M39.77,0H5.28A5.29,5.29,0,0,0,0,5.28V39.77a5.28,5.28,0,0,0,5.28,5.28H39.77a5.27,5.27,0,0,0,5.28-5.28V5.28A5.28,5.28,0,0,0,39.77,0ZM5.28,3.52H39.77a1.76,1.76,0,0,1,1.76,1.76v5.28h-38V5.28A1.76,1.76,0,0,1,5.28,3.52Zm34.49,38H5.28a1.76,1.76,0,0,1-1.76-1.76V14.08h38V39.77A1.75,1.75,0,0,1,39.77,41.53ZM6.16,7A1.76,1.76,0,1,1,7.92,8.8,1.76,1.76,0,0,1,6.16,7Zm6.16,0A1.76,1.76,0,1,1,14.08,8.8,1.76,1.76,0,0,1,12.32,7Zm5.73,13.45a3.51,3.51,0,0,0-3.43-2.71H11.18V21.3h3.44l2,8.46a3.51,3.51,0,0,0,3.43,2.71h7a4.34,4.34,0,0,0,4.07-3.07l2.62-7.75H18.32Zm10.74,4.68-1.06,3.12v.05A.86.86,0,0,1,27,29H20.05l-.9-3.78ZM22.09,35.9a1.76,1.76,0,1,1-1.76-1.76A1.76,1.76,0,0,1,22.09,35.9Zm6.6,0a1.76,1.76,0,1,1-1.76-1.76A1.76,1.76,0,0,1,28.69,35.9Z" /></g></g>
            </svg>
        </symbol>
        <symbol id="icon-sapo-omnichannel">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 68.63 75.45"><defs><linearGradient id="linear-gradient-omni" x1="65.73" y1="79.75" x2="13.73" y2="8.75" gradientTransform="matrix(1, 0, 0, -1, 0, 78)" gradientUnits="userSpaceOnUse"><stop offset="0.01" stop-color="#ab5af4" /><stop offset="0.36" stop-color="#8a66f0" /><stop offset="0.77" stop-color="#6a72ec" /><stop offset="1" stop-color="#5e76eb" /></linearGradient></defs><g><path d="M68.63,13.61A13.62,13.62,0,0,0,55,0h0L13.61,6.82A13.61,13.61,0,0,0,0,20.43H0V61.84A13.61,13.61,0,0,0,13.61,75.45H55A13.61,13.61,0,0,0,68.63,61.86V45.64c0-.7-.07-1.4-.07-2.12s0-1.45.07-2.16Z" fill="url(#linear-gradient-omni)" /><path d="M54.15,44.4V34.8a5.55,5.55,0,1,0-5.82-9.18l-7.81-3.78v-.4a5.56,5.56,0,0,0-11.11,0v.44l-7.84,3.71A5.56,5.56,0,1,0,15.8,34.8v9.6a5.56,5.56,0,1,0,3.87,10.43,5.68,5.68,0,0,0,2-1.26l7.8,3.73a3.53,3.53,0,0,0,0,.46,5.56,5.56,0,1,0,11.11.47,3.69,3.69,0,0,0,0-.47v-.5l7.83-3.66a5.56,5.56,0,0,0,7.75-8,5.79,5.79,0,0,0-1.94-1.22ZM52.21,27.74a1.86,1.86,0,1,1-1.86,1.86,1.86,1.86,0,0,1,1.86-1.86ZM35,19.59a1.86,1.86,0,1,1-1.85,1.87v0A1.85,1.85,0,0,1,35,19.59ZM17.74,27.74a1.86,1.86,0,1,1-1.85,1.87h0A1.87,1.87,0,0,1,17.74,27.74Zm0,23.72A1.86,1.86,0,1,1,19.6,49.6h0a1.85,1.85,0,0,1-1.85,1.85ZM35,59.61a1.85,1.85,0,1,1,1.86-1.85A1.85,1.85,0,0,1,35,59.61Zm0-7.41a5.51,5.51,0,0,0-4,1.72l-7.7-3.68q0-.32,0-.63a5.55,5.55,0,0,0-3.8-5.27V34.87a5.56,5.56,0,0,0,3.8-5.27v-.7L31,25.26a5.56,5.56,0,0,0,7.85.24l.24-.24L46.73,29a3.64,3.64,0,0,0,0,.66,5.56,5.56,0,0,0,3.8,5.27v9.47a5.55,5.55,0,0,0-3.8,5.27,3.75,3.75,0,0,0,0,.67L39,53.9A5.49,5.49,0,0,0,35,52.2Zm17.24-.74a1.86,1.86,0,1,1,1.85-1.87v0a1.85,1.85,0,0,1-1.85,1.85h0Z" fill="#fff" /><path d="M31.12,35.25a3.09,3.09,0,0,0-3-2.38h-3V36h3l1.76,7.43a3.08,3.08,0,0,0,3,2.39H39a3.83,3.83,0,0,0,3.59-2.7l2.3-6.82H31.36Zm9.44,4.12-.93,2.74h0a.74.74,0,0,1-.64.54h-6.1l-.79-3.32ZM34.67,48.8a1.55,1.55,0,1,1-1.56-1.54h0a1.54,1.54,0,0,1,1.55,1.53Zm5.8,0a1.55,1.55,0,1,1-1.56-1.54h0a1.54,1.54,0,0,1,1.55,1.53Z" fill="#fff" /></g></svg>
        </symbol>
        <symbol id="icon-sapo-omnichannel-mobile">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 45.58 47.43">
                <defs>
                    <style>
                        .cls-1omni {
                            fill: url(#linear-gradientomni);
                        }

                        .cls-2omni {
                            fill: url(#linear-gradient-2omni);
                        }
                    </style>
                    <linearGradient id="linear-gradientomni" y1="23.72" x2="45.58" y2="23.72" gradientUnits="userSpaceOnUse"><stop offset="0.01" stop-color="#ab5af4" /><stop offset="0.36" stop-color="#8a66f0" /><stop offset="0.77" stop-color="#6a72ec" /><stop offset="1" stop-color="#5e76eb" /></linearGradient>
                    <linearGradient id="linear-gradient-2omni" x1="12.9" y1="25.73" x2="32.68" y2="25.73" xlink:href="#linear-gradientomni" />
                </defs>
                <g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><path class="cls-1omni" d="M42,28.52v-9.6a5.56,5.56,0,1,0-5.82-9.19L28.33,6c0-.13,0-.26,0-.39a5.56,5.56,0,0,0-11.12,0c0,.14,0,.29,0,.43L9.4,9.7A5.51,5.51,0,0,0,5.56,8.15,5.56,5.56,0,0,0,3.61,18.92v9.6a5.55,5.55,0,1,0,5.84,9.16l7.8,3.74c0,.15,0,.3,0,.46a5.56,5.56,0,0,0,11.12,0c0-.17,0-.34,0-.5l7.83-3.67A5.55,5.55,0,1,0,42,28.52ZM40,11.86a1.85,1.85,0,1,1-1.85,1.85A1.86,1.86,0,0,1,40,11.86ZM22.79,3.71a1.85,1.85,0,1,1-1.85,1.85A1.85,1.85,0,0,1,22.79,3.71ZM5.56,11.86a1.85,1.85,0,1,1-1.85,1.85A1.85,1.85,0,0,1,5.56,11.86Zm0,23.72a1.86,1.86,0,1,1,1.85-1.86A1.86,1.86,0,0,1,5.56,35.58Zm17.23,8.15a1.86,1.86,0,1,1,1.85-1.85A1.85,1.85,0,0,1,22.79,43.73Zm0-7.41a5.52,5.52,0,0,0-4,1.72l-7.7-3.69a6.26,6.26,0,0,0,0-.63,5.57,5.57,0,0,0-3.8-5.27V19a5.57,5.57,0,0,0,3.8-5.27,5.49,5.49,0,0,0,0-.7l7.69-3.63a5.54,5.54,0,0,0,8.09,0l7.65,3.7c0,.22,0,.44,0,.66A5.57,5.57,0,0,0,38.26,19v9.47a5.57,5.57,0,0,0-3.8,5.27,4.91,4.91,0,0,0,0,.67L26.78,38A5.56,5.56,0,0,0,22.79,36.32ZM40,35.58a1.86,1.86,0,1,1,1.86-1.86A1.86,1.86,0,0,1,40,35.58Z" /><path class="cls-2omni" d="M18.94,19.37a3.08,3.08,0,0,0-3-2.38h-3v3.09h3l1.75,7.44a3.08,3.08,0,0,0,3,2.38H26.8a3.82,3.82,0,0,0,3.58-2.7l2.3-6.81H19.18Zm9.43,4.11-.92,2.75,0,0a.74.74,0,0,1-.63.54H20.69l-.78-3.33Zm-5.88,9.44a1.55,1.55,0,1,1-1.55-1.55A1.55,1.55,0,0,1,22.49,32.92Zm5.8,0a1.55,1.55,0,1,1-1.55-1.55A1.55,1.55,0,0,1,28.29,32.92Z" /></g></g>
            </svg>
        </symbol>
        <symbol id="icon-sapo-enterprise">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 68.63 75.45"><defs><linearGradient id="linear-gradient-enterprise" x1="81.64" y1="96.38" x2="15.64" y2="13.38" gradientTransform="matrix(1, 0, 0, -1, 0, 78)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#ffcb52" /><stop offset="1" stop-color="#ff7b02" /></linearGradient></defs><g><path d="M68.63,13.62A13.62,13.62,0,0,0,55,0h0L13.61,6.82A13.61,13.61,0,0,0,0,20.43H0V61.84A13.61,13.61,0,0,0,13.61,75.45H55A13.61,13.61,0,0,0,68.63,61.86V45.64c0-.7-.07-1.4-.07-2.12s0-1.45.07-2.16Z" fill="url(#linear-gradient-enterprise)" /><path d="M57.48,45.24A1.79,1.79,0,0,1,55.69,47H45.84v2.9a1.79,1.79,0,0,1-3.58,0V47H26.86v2.9a1.79,1.79,0,0,1-3.58,0V47H17.91v6.45A3.6,3.6,0,0,0,21.49,57H47.63a3.6,3.6,0,0,0,3.58-3.58,1.79,1.79,0,1,1,3.58,0,7.18,7.18,0,0,1-7.16,7.16H21.49a7.18,7.18,0,0,1-7.16-7.16V47h-.89a1.79,1.79,0,0,1-1.79-1.79h0V29.13A7.17,7.17,0,0,1,18.81,22h6.8V20.18A5.38,5.38,0,0,1,31,14.81h7.16a5.39,5.39,0,0,1,5.37,5.37V22h6.8a7.17,7.17,0,0,1,7.17,7.16ZM29.19,22H39.93V20.18a1.79,1.79,0,0,0-1.79-1.79H31a1.79,1.79,0,0,0-1.79,1.79h0ZM53.9,43.45V29.13a3.58,3.58,0,0,0-3.58-3.58H18.81a3.58,3.58,0,0,0-3.58,3.58V43.45Z" fill="#fff" /></g></svg>
        </symbol>
        <symbol id="icon-sapo-enterprise-mobile">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 45.83 45.83">
                <defs>
                    <style>
                        .cls-1en {
                            fill: url(#linear-gradienten);
                        }
                    </style>
                    <linearGradient id="linear-gradienten" y1="22.91" x2="45.83" y2="22.91" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#ffcb52" /><stop offset="1" stop-color="#ff7b02" /></linearGradient>
                </defs>
                <g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><g id="surface1"><path class="cls-1en" d="M45.83,30.43A1.79,1.79,0,0,1,44,32.22H34.19v2.87a1.79,1.79,0,0,1-3.58,0V32.22H15.22v2.87a1.8,1.8,0,0,1-3.59,0V32.22H6.26v6.45a3.59,3.59,0,0,0,3.58,3.58H36a3.58,3.58,0,0,0,3.58-3.58,1.79,1.79,0,0,1,3.58,0A7.17,7.17,0,0,1,36,45.83H9.84a7.17,7.17,0,0,1-7.16-7.16V32.22H1.79A1.79,1.79,0,0,1,0,30.43V14.32A7.17,7.17,0,0,1,7.16,7.16H14V5.37A5.38,5.38,0,0,1,19.33,0h7.16a5.38,5.38,0,0,1,5.37,5.37V7.16h6.81a7.17,7.17,0,0,1,7.16,7.16ZM17.54,7.16H28.28V5.37a1.79,1.79,0,0,0-1.79-1.79H19.33a1.79,1.79,0,0,0-1.79,1.79ZM42.25,28.64V14.32a3.59,3.59,0,0,0-3.58-3.58H7.16a3.58,3.58,0,0,0-3.58,3.58V28.64Z" /></g></g></g>
            </svg>
        </symbol>
        <symbol id="icon-sapo-hub">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 688.24 652.94" style="enable-background:new 0 0 688.24 652.94;" xml:space="preserve">
            <style type="text/css">
                .st0-hub {
                    fill: url(#linear-gradienten-hub);
                }

                .st1-hub {
                    fill: #FFFFFF;
                }
</style>
            <linearGradient id="linear-gradienten-hub" gradientUnits="userSpaceOnUse" x1="161.3661" y1="523.3684" x2="553.9286" y2="130.8059">
            <stop offset="0.2346" style="stop-color:#0859D3" />

            <stop offset="1" style="stop-color:#0095FE" />

                </linearGradient>
            <path class="st0-hub" d="M557.47,168.91c0-46.08-37.35-83.43-83.42-83.43l-253.7,41.79c-46.08,0-83.41,37.35-83.41,83.43v253.69  c0,46.07,37.33,83.42,83.41,83.42h253.7c46.07,0,83.42-37.35,83.42-83.42v-99.23c-0.25-4.28-0.41-8.61-0.41-13.02  c0-4.44,0.15-8.86,0.42-13.23V168.91z" /><g>
            <path class="st1-hub" d="M461.93,377.06c5.52-6.16,8.89-14.29,8.89-23.2c0-19.19-15.61-34.8-34.8-34.8s-34.8,15.61-34.8,34.8   c0,8.91,3.37,17.04,8.89,23.2c-7.87,3.71-14.82,9.06-20.41,15.61l-31.99-25.59v-65.43h52.21v-26.1c0-24.32-14.33-45.35-34.99-55.11   c5.52-6.16,8.89-14.29,8.89-23.2c0-19.19-15.61-34.8-34.8-34.8s-34.8,15.61-34.8,34.8c0,8.91,3.37,17.04,8.89,23.2   c-20.66,9.75-34.99,30.79-34.99,55.11v26.1h52.21v65.43l-31.99,25.59c-5.59-6.55-12.54-11.9-20.41-15.61   c5.52-6.16,8.89-14.29,8.89-23.2c0-19.19-15.61-34.8-34.8-34.8s-34.8,15.61-34.8,34.8c0,8.91,3.37,17.04,8.89,23.2   c-20.66,9.75-34.99,30.79-34.99,55.11v26.1H322.9v-26.1c0-8.79-1.87-17.14-5.24-24.69L349,382.41l31.34,25.07   c-3.36,7.55-5.24,15.91-5.24,24.69v26.1h121.81v-26.1C496.92,407.85,482.59,386.82,461.93,377.06L461.93,377.06z M331.6,197.25   c0-9.6,7.81-17.4,17.4-17.4c9.6,0,17.4,7.81,17.4,17.4c0,9.6-7.81,17.4-17.4,17.4C339.4,214.65,331.6,206.84,331.6,197.25   L331.6,197.25z M305.49,275.56c0-23.99,19.52-43.5,43.5-43.5s43.5,19.52,43.5,43.5v8.7h-87.01L305.49,275.56z M244.59,353.86   c0-9.6,7.81-17.4,17.4-17.4c9.6,0,17.4,7.81,17.4,17.4c0,9.6-7.81,17.4-17.4,17.4C252.39,371.27,244.59,363.46,244.59,353.86z    M305.49,440.87h-87.01v-8.7c0-23.99,19.52-43.5,43.5-43.5s43.5,19.52,43.5,43.5V440.87z M418.61,353.86c0-9.6,7.81-17.4,17.4-17.4   c9.6,0,17.4,7.81,17.4,17.4c0,9.6-7.81,17.4-17.4,17.4C426.41,371.27,418.61,363.46,418.61,353.86z M479.51,440.87H392.5v-8.7   c0-23.99,19.52-43.5,43.5-43.5c23.99,0,43.5,19.52,43.5,43.5V440.87z" /></g>
            </svg>
        </symbol>
        <symbol id="icon-sapo-hub-mobile">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 688.24 652.94" style="enable-background:new 0 0 688.24 652.94;" xml:space="preserve">
            <style type="text/css">
                .st0-hub2 {
                    fill: url(#linear-gradienten-hub-2);
                }

                .st1-hub2 {
                    fill: #FFFFFF;
                }
</style>
            <g>
            <linearGradient id="linear-gradienten-hub-2" gradientUnits="userSpaceOnUse" x1="157.6994" y1="546.0804" x2="557.0681" y2="146.7117">
            <stop offset="0.2346" style="stop-color:#0859D3" />

            <stop offset="1" style="stop-color:#0095FE" />

                </linearGradient>
            <path class="st0-hub2" d="M560.67,185.47c0-46.88-38-84.87-84.86-84.87l-258.1,42.51c-46.88,0-84.86,38-84.86,84.87v258.09   c0,46.87,37.98,84.86,84.86,84.86h258.1c46.87,0,84.86-38,84.86-84.86V385.13c-0.25-4.35-0.42-8.76-0.42-13.24   c0-4.52,0.15-9.01,0.42-13.46V185.47z" /><g>
            <path class="st1-hub2" d="M350.91,340.03c28.77,0,52.18-23.4,52.18-52.17s-23.41-52.17-52.18-52.17c-28.77,0-52.18,23.4-52.18,52.17    S322.14,340.03,350.91,340.03z M350.91,256.94c17.05,0,30.92,13.87,30.92,30.92c0,17.05-13.87,30.92-30.92,30.92    c-17.05,0-30.92-13.87-30.92-30.92C319.99,270.81,333.86,256.94,350.91,256.94z" />

            <path class="st1-hub2" d="M447.85,367.73c21.12,0,38.32-17.19,38.32-38.32c0-21.13-17.19-38.32-38.32-38.32    c-21.12,0-38.32,17.19-38.32,38.32C409.53,350.54,426.72,367.73,447.85,367.73z M447.85,312.33c9.42,0,17.08,7.66,17.08,17.08    c0,9.41-7.66,17.07-17.08,17.07c-9.41,0-17.06-7.66-17.06-17.07C430.78,319.99,438.44,312.33,447.85,312.33z" />

            <path class="st1-hub2" d="M254.95,367.73c21.12,0,38.32-17.19,38.32-38.32c0-21.13-17.19-38.32-38.32-38.32s-38.32,17.19-38.32,38.32    C216.63,350.54,233.83,367.73,254.95,367.73z M254.95,312.33c9.42,0,17.08,7.66,17.08,17.08c0,9.41-7.66,17.07-17.08,17.07    s-17.08-7.66-17.08-17.07C237.87,319.99,245.53,312.33,254.95,312.33z" />

            <path class="st1-hub2" d="M447.85,374.18c-8.88,0-17.61,1.81-25.73,5.25c-17.21-20.13-42.72-32.95-71.21-32.95    c-28.49,0-54,12.82-71.2,32.94c-8.11-3.43-16.85-5.25-25.74-5.25c-36.4,0-66.02,29.61-66.02,66.02c0,5.86,4.77,10.63,10.62,10.63    s10.62-4.77,10.62-10.63c0-24.69,20.08-44.77,44.78-44.77c4.65,0,9.16,0.89,13.52,2.27c-6.53,12.77-10.3,27.19-10.3,42.5    c0,5.86,4.77,10.63,10.62,10.63c5.87,0,10.63-4.77,10.63-10.63c0-39.96,32.51-72.47,72.46-72.47c39.97,0,72.48,32.51,72.48,72.47    c0,5.86,4.77,10.63,10.62,10.63c5.85,0,10.62-4.77,10.62-10.63c0-15.31-3.76-29.72-10.29-42.49c4.36-1.38,8.87-2.28,13.52-2.28    c24.69,0,44.78,20.08,44.78,44.77c0,5.86,4.77,10.63,10.62,10.63c5.85,0,10.62-4.77,10.62-10.63    C513.86,403.8,484.24,374.18,447.85,374.18z" />

                </g></g>
            </svg>
        </symbol>
        <symbol id="icon-sapo-365">
            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 427.82 470.33">
            <defs>
                <style>
                                                                                                                                     .cls-1365 {
                                                                                                                                         fill: url(#linear-gradient365);
                                                                                                                                     }

                                                                                                                                     .cls-2365 {
                                                                                                                                         fill: #fff;
                                                                                                                                         stroke: #fff;
                                                                                                                                         stroke-miterlimit: 10;
                                                                                                                                         stroke-width: 3px;
                                                                                                                                     }
            </style><linearGradient id="linear-gradient365" x1="-462.51" y1="814.55" x2="683.23" y2="-130.84" gradientUnits="userSpaceOnUse">
                <stop offset="0" stop-color="#0059e8" /><stop offset="1" stop-color="#78fff8" /></linearGradient></defs>
            <g data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1">
                <path class="cls-1365" d="M427.82,84.87A84.86,84.86,0,0,0,343,0L84.86,42.51A84.86,84.86,0,0,0,0,127.38V385.47a84.85,84.85,0,0,0,84.86,84.86H343a84.86,84.86,0,0,0,84.86-84.86V284.53c-.25-4.35-.42-8.76-.42-13.24s.15-9,.42-13.46Z" />
                <path class="cls-2365" d="M315.49,87.2c.54.22,1.07.47,1.62.65a16.44,16.44,0,0,1,1.54,31c-.55.24-1.1.45-1.89.78.42,1,.79,2,1.24,2.91,5.21,10.84,10.38,21.7,15.68,32.5a31.55,31.55,0,0,1,3.45,15.24c-.21,5.86.21,11.82-.74,17.56-1.93,11.61-8.84,19.83-19.47,24.71-2.34,1.07-3,2.24-3,4.63q.09,72.72.07,145.45c0,8.09-2,15.34-7.61,21.35-5.91,6.33-13.27,9.18-21.89,9.17q-62.56,0-125.13,0c-5.58,0-11.15,0-16.73,0-15.83-.12-27.77-11.45-28.74-27.25-.09-1.58-.1-3.18-.1-4.77q0-71.68,0-143.36c0-2.64-.52-4.07-3.24-5.37-12.57-6-19.31-16.14-19.88-30.16-.17-4.37,0-8.76,0-13.14A30.46,30.46,0,0,1,94,155.28c5.73-11.79,11.4-23.62,17.15-35.56-.75-.33-1.37-.62-2-.88a16.45,16.45,0,0,1,1.53-31c.56-.17,1.09-.43,1.63-.64ZM154.66,198.91c-2.38,2.69-4.74,5.23-6.92,7.92a5,5,0,0,0-1,2.94q-.08,53.16,0,106.33c0,5.55,3,8.3,8.66,8.3q58.53,0,117.07,0c5.65,0,8.63-2.77,8.64-8.33q.07-53.16,0-106.32a4.22,4.22,0,0,0-.61-2.5c-2.37-2.85-4.88-5.58-7.33-8.35-13.53,21.68-44.81,22.85-59.25.07C199.22,221.94,167.93,220.37,154.66,198.91ZM290.1,213.73v44.9c0,19,0,38,0,57.06,0,11-6.84,17.66-17.74,17.68H244.56q-44.81,0-89.62,0c-8.17,0-14.56-4.59-16.52-12a26.57,26.57,0,0,1-.66-6.8q-.06-48.69,0-97.38v-3.42l-14.81,2.42c0,.57-.11,1.16-.11,1.75q0,73,0,146.08c0,12.08,8.35,20.15,20.41,20.16q70.65,0,141.29,0a24.15,24.15,0,0,0,4.17-.27C299,382,305,374.22,305,362.84q0-71.83,0-143.68v-3ZM214,111.1h95.85a32.78,32.78,0,0,0,3.29-.06,7.44,7.44,0,0,0,0-14.82,23.92,23.92,0,0,0-2.68-.06H117.26c-.8,0-1.6,0-2.39,0a7.43,7.43,0,0,0-6.71,9.33c.86,3.55,3.87,5.56,8.46,5.56Zm53.56,47.66c-3.12-13-6.2-25.82-9.25-38.55H218.5v38.55Zm-107.28,0H209.1V120.06H175.16c-5.6,0-5.63,0-7,5.54C165.54,136.6,162.92,147.62,160.25,158.73Zm0-38.44a10.65,10.65,0,0,0-1.37-.22c-12,0-24.08,0-36.12-.06-1.88,0-2.31,1-2.92,2.31q-8.14,16.94-16.3,33.84c-.37.78-.65,1.61-1,2.59H151C154.12,145.88,157.17,133.14,160.26,120.29Zm165,38.49a5.7,5.7,0,0,0-.27-1.16c-5.76-12-11.5-24-17.38-36a3.93,3.93,0,0,0-3-1.53c-11.54-.11-23.09-.07-34.63-.06-.73,0-1.46.14-2.39.23,3.12,13,6.17,25.7,9.24,38.48ZM277.83,168c0,4.83-.07,9.4,0,14a25.22,25.22,0,0,0,22.71,24.63c12.44,1.31,24.48-7.07,26.83-19.52,1.16-6.15.75-12.59,1.06-19.07Zm-128.32,0H99.71c0,4.91-.12,9.66,0,14.4a25.09,25.09,0,0,0,23.1,24.21c12.76,1,24.53-7.63,26.52-20.29C150.27,180.45,149.51,174.3,149.51,168Zm9.53,0c0,5.15-.24,10.11.05,15A25.22,25.22,0,0,0,182,206.62c12.31,1.12,24-6.94,26.51-19.2,1.27-6.23.88-12.79,1.26-19.39Zm59.52,0c0,5.3-.28,10.46.05,15.58.75,11.8,9.71,21.05,21.83,22.9,11,1.68,22.54-5.19,26.64-15.86,2.84-7.39,1.46-15,1.75-22.62Z" /></g></g>
            </svg>
        </symbol>
    </svg>
</div>
    </div>
        

    






    <img class="scroll-top" data-src="<?php echo e(asset('website')); ?>./Themes/Portal/Default/Images/totop.png" alt="Lên đầu trang" style="display:none;cursor :pointer; position : fixed;bottom : 90px;right : 33px;z-index : 99;" />
    <script>
        var images = document.querySelectorAll('source, img');
        if ('IntersectionObserver' in window) {
            var onChange = function onChange(changes, observer) {
                changes.forEach(function (change) {
                    if (change.intersectionRatio > 0) {
                        loadImage(change.target);
                        observer.unobserve(change.target);
                    }
                });
            };
            var config = { root: null, threshold: 0.1 }; var observer = new IntersectionObserver(onChange, config); images.forEach(function (img) { return observer.observe(img); });
        } else {
            images.forEach(function (image) { return loadImage(image); });
        }

        function loadImage(image) {
            image.classList.add('fade', 'show');
            if (image.dataset && image.dataset.src) {
                image.src = image.dataset.src;
            }

            if (image.dataset && image.dataset.srcset) {
                image.srcset = image.dataset.srcset;
            }
        }
        addLoadEvent(function () {
            $(window).scroll(function () {
                if ($(window).scrollTop() > 700) {
                    $('.scroll-top').show();
                }
                else {
                    $('.scroll-top').hide();
                }
            });

            $('.scroll-top').click(function () {
                $("html, body").animate({ scrollTop: 0 }, "slow");
            });
            if ($(window).width() < 768) {
                $('.scroll-top').css({ 'bottom': '90px', 'right': '8px' });
            }
        });
    </script>
 
   
   
</body>
</html>
<?php /**PATH C:\Users\cuong123\Desktop\blog\resources\views/website.blade.php ENDPATH**/ ?>