<!-- Banner Image Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('banner_image', 'Banner Image:'); ?>

    <div class="input-group">
        <div class="custom-file">
            <?php echo Form::file('banner_image', ['class' => 'custom-file-input']); ?>

            <?php echo Form::label('banner_image', 'Choose file', ['class' => 'custom-file-label']); ?>

        </div>
    </div>
</div>
<div class="clearfix"></div>
<?php /**PATH /home/dthdenta/public_html/demo1.dthdental.vn/resources/views/banners/fields.blade.php ENDPATH**/ ?>