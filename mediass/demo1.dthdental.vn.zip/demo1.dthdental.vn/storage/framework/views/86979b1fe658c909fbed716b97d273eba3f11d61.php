<div class="row">
    <?php echo $records->links(); ?>

</div>
<?php /**PATH C:\Users\Admin\Desktop\New folder (5)\demo1.dthdental.vn\resources\views/vendor/adminlte-templates/common/paginate.blade.php ENDPATH**/ ?>