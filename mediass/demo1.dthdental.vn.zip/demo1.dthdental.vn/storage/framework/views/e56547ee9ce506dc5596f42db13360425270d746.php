<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="wrapper">
        <div class="row">
            <div class="col-sm-9 col-sm-push-3">
                <div class="container">
                    <div class="box_module">
                        <div class="box_title">
                            <h1 class="title"><a href="/nha-khoa-benh-ly" title="Nha khoa bệnh lý">Nha khoa bệnh lý</a></h1>
                        </div>
                        <div class="box_content">
                            <div class="layout_category_product">
                                <div class="productGrid service">
                                    <div class="row">
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="item">
                                                <div class="image">
                                                    <a href="/quy-trinh-tham-kham-tu-van-tai-nha-khoa-win-smile" title="Quy trình thăm khám tư vấn tại Nha Khoa Win Smile"><img src="<?php echo e(asset('public/files/upload/default/medium/images/dich-vu/tay-trang-rang.jpg')); ?>" alt="Quy trình thăm khám tư vấn tại Nha Khoa Win Smile"><span>Xem thêm</span></a>
                                                </div>
                                                <div class="info">
                                                    <h3 class="title"><a href="/quy-trinh-tham-kham-tu-van-tai-nha-khoa-win-smile" title="Quy trình thăm khám tư vấn tại Nha Khoa Win Smile">Quy trình thăm khám tư vấn tại Nha Khoa Win Smile</a></h3>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="item">
                                                <div class="image">
                                                    <a href="/dieu-tri-cuoi-ho-loi" title="Điều trị cười hở lợi"><img src="<?php echo e(asset('public/files/upload/default/medium/images/dich-vu/dieu-tri-cuoi-hoi-loi.jpg')); ?>" alt="Điều trị cười hở lợi"><span>Xem thêm</span></a>
                                                </div>
                                                <div class="info">
                                                    <h3 class="title"><a href="/dieu-tri-cuoi-ho-loi" title="Điều trị cười hở lợi">Điều trị cười hở lợi</a></h3>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="item">
                                                <div class="image">
                                                    <a href="/dieu-tri-nha-chu" title="Điều trị nha chu"><img src="<?php echo e(asset('public/files/upload/default/medium/images/dich-vu/dieu-tri-nha-chu-1.jpg')); ?>" alt="Điều trị nha chu"><span>Xem thêm</span></a>
                                                </div>
                                                <div class="info">
                                                    <h3 class="title"><a href="/dieu-tri-nha-chu" title="Điều trị nha chu">Điều trị nha chu</a></h3>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="item">
                                                <div class="image">
                                                    <a href="/dieu-tri-rang-sau" title="Điều trị răng sâu"><img src="<?php echo e(asset('public/files/upload/default/medium/images/dich-vu/dieu-tri-rang-sau.jpeg')); ?>" alt="Điều trị răng sâu"><span>Xem thêm</span></a>
                                                </div>
                                                <div class="info">
                                                    <h3 class="title"><a href="/dieu-tri-rang-sau" title="Điều trị răng sâu">Điều trị răng sâu</a></h3>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="item">
                                                <div class="image">
                                                    <a href="/dieu-tri-tuy-rang" title="Điều trị tủy răng"><img src="<?php echo e(asset('public/files/upload/default/medium/images/dich-vu/dieu-tri-tuy-rang.jpg')); ?>" alt="Điều trị tủy răng"><span>Xem thêm</span></a>
                                                </div>
                                                <div class="info">
                                                    <h3 class="title"><a href="/dieu-tri-tuy-rang" title="Điều trị tủy răng">Điều trị tủy răng</a></h3>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="item">
                                                <div class="image">
                                                    <a href="/tay-trang-rang" title="Tẩy trắng răng"><img src="<?php echo e(asset('public/files/upload/default/medium/images/dich-vu/tay-trang-rang.jpg')); ?>" alt="Tẩy trắng răng"><span>Xem thêm</span></a>
                                                </div>
                                                <div class="info">
                                                    <h3 class="title"><a href="/tay-trang-rang" title="Tẩy trắng răng">Tẩy trắng răng</a></h3>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="item">
                                                <div class="image">
                                                    <a href="/han-tram-rang" title="Hàn trám răng"><img src="<?php echo e(asset('public/files/upload/default/medium/images/dich-vu/tay-trang-rang.jpg')); ?>" alt="Hàn trám răng"><span>Xem thêm</span></a>
                                                </div>
                                                <div class="info">
                                                    <h3 class="title"><a href="/han-tram-rang" title="Hàn trám răng">Hàn trám răng</a></h3>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="item">
                                                <div class="image">
                                                    <a href="/nho-rang-khon" title="Nhổ răng khôn"><img src="<?php echo e(asset('public/files/upload/default/medium/images/san-pham/nho-rang-khon-tai-winsmile.png')); ?>" alt="Nhổ răng khôn"><span>Xem thêm</span></a>
                                                </div>
                                                <div class="info">
                                                    <h3 class="title"><a href="/nho-rang-khon" title="Nhổ răng khôn">Nhổ răng khôn</a></h3>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3 col-sm-pull-9">
                <div class="box_support" id="box_support">
                    <div class="box_title">
                        <div class="title">Hỗ trợ trực tuyến</div>
                    </div>
                    <div class="box_content">
                        <div class="item">
                            <div class="name"><i class="fa fa-user" aria-hidden="true"></i> Hỗ trợ trực tuyến 24/7</div>
                            <div class="phone"><i class="fas fa-mobile-alt"></i> 0966 688 234 - 0977 688 234</div>
                            <div class="zalo"><i class="far fa-zalo">Z</i> 0966 688 234 - 0977 688 234</div>
                            <div class="email"><i class="far fa-envelope"></i> </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cuong123\Desktop\New folder (2)\blog\resources\views/frontend/benhly.blade.php ENDPATH**/ ?>