

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="wrapper">
        <div class="row">
            <div class="col-sm-9 col-sm-push-3">
                <div class="container">
                    <div class="box_module">
                        <div class="box_title">
                            <h1 class="title"><a href="/nha-khoa-benh-ly" title="Nha khoa bệnh lý">Nha khoa bệnh lý</a></h1>
                        </div>
                        <div class="box_content">
                            <div class="layout_category_product">
                                <div class="productGrid service">
                                    <div class="row">

                                        <?php 
                                            $news =  App\Models\post::whereIn('id', [30, 31, 32,33,34,35,36,37])->get();

                                        ?>
                                        <?php if(count($news)>0): ?>
                                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newss): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="item">
                                                <div class="image">
                                                    <a href="<?php echo e(route('single', @$newss['link'])); ?>" title="<?php echo e(@$newss['title']); ?>"><img src="<?php echo e(@url($newss['image'])); ?>" alt="<?php echo e(@$newss['title']); ?>"><span>Xem thêm</span></a>
                                                </div>
                                                <div class="info">
                                                    <h3 class="title"><a href="<?php echo e(route('single', @$newss['link'])); ?>" title="<?php echo e(@$newss['title']); ?>"><?php echo e(@$newss['title']); ?></a></h3>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3 col-sm-pull-9">
                <div class="box_support" id="box_support">
                    <div class="box_title">
                        <div class="title">Hỗ trợ trực tuyến</div>
                    </div>
                    <div class="box_content">
                        <div class="item">
                            <div class="name"><i class="fa fa-user" aria-hidden="true"></i> Hỗ trợ trực tuyến 24/7</div>
                            <div class="phone"><i class="fas fa-mobile-alt"></i> 0987 654 321 - 0987 654 321</div>
                            <div class="zalo"><i class="far fa-zalo">Z</i> 0987 654 321 - 0987 654 321</div>
                            <div class="email"><i class="far fa-envelope"></i> </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dthdenta/public_html/demo1.dthdental.vn/resources/views/frontend/benhly.blade.php ENDPATH**/ ?>