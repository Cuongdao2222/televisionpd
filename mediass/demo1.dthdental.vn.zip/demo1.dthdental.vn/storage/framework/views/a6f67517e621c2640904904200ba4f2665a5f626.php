<?php $__env->startSection('content'); ?>
<div class="box_breadcrumb">
    <div class="container">
        <ul class="breadcrumb">
            <li><a href="/">Trang chủ</a></li>
            <li><a href="/cam-nhan-khach-hang" title="Khách hàng nói gì về D'media?">Khách hàng nói gì về D'media?</a></li>
        </ul>
    </div>
</div>
<div class="wrapper">
    <div class="container">
        <div class="box_module">
            <div class="box_title hidden">
                <h1 class="title"><a href="/cam-nhan-khach-hang" title="Khách hàng nói gì về D'media?">Khách hàng nói gì về D'media?</a></h1>
            </div>
            <div class="box_content" style="padding: 30px 0;">
                <div class="layout_category_feedback">
                    <div class="row">
                        <div class="col-sm-4 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/thuong-cin" title="THƯƠNG CIN"><img src="<?php echo e(asset('public/files/upload/default/medium/images/cam-nhan-khach-hang/thuong-cin-2.png')); ?>" alt="THƯƠNG CIN"><span>Xem thêm</span></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/thuong-cin" title="THƯƠNG CIN">THƯƠNG CIN</a></h3>
                                    <div class="location">Diễn viên <span></span></div>
                                    <div class="desc">Làm xong cũng chẳng đau gì chỉ thấy đẹp thôi, mình tự tin hát và trước ống kính lắm rồi. ... <a href="/thuong-cin">Xem thêm</a></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/hoang-phi-huyen" title="HOÀNG PHI HUYỀN"><img src="<?php echo e(asset('public/files/upload/default/medium/images/cam-nhan-khach-hang/hoang-phi-huyen.png')); ?>" alt="HOÀNG PHI HUYỀN"><span>Xem thêm</span></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/hoang-phi-huyen" title="HOÀNG PHI HUYỀN">HOÀNG PHI HUYỀN</a></h3>
                                    <div class="location">Boss <span>Huyền Phi Comestic</span></div>
                                    <div class="desc">Răng của Huyền trước đây khá đều, tuy nhiên lại không được trắng sáng. Dù không tự ti nhưng là 1 Boss của hệ thống hơn 1000 người thì hình ... <a href="/hoang-phi-huyen">Xem thêm</a></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/nguyen-tat-kiem" title="NGUYỄN TẤT KIỂM"><img src="<?php echo e(asset('public/files/upload/default/medium/images/cam-nhan-khach-hang/nguyen-tat-kiem.png')); ?>" alt="NGUYỄN TẤT KIỂM"><span>Xem thêm</span></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/nguyen-tat-kiem" title="NGUYỄN TẤT KIỂM">NGUYỄN TẤT KIỂM</a></h3>
                                    <div class="location">CEO <span>TAKA ACADEMY</span></div>
                                    <div class="desc">Hiện tại Nụ cười rạng rỡ mà Win Smile mang lại cho tôi đó chính là niềm tin yêu của học viên và sự quý trọng của đối tác. Cám ... <a href="/nguyen-tat-kiem">Xem thêm</a></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/nguyen-quyen" title="NGUYỄN QUYÊN"><img src="<?php echo e(asset('public/files/upload/default/medium/images/cam-nhan-khach-hang/nguyen-quyen.png')); ?>" alt="NGUYỄN QUYÊN"><span>Xem thêm</span></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/nguyen-quyen" title="NGUYỄN QUYÊN">NGUYỄN QUYÊN</a></h3>
                                    <div class="location">Boss <span>Mỹ phẩm Herrin Care</span></div>
                                    <div class="desc">Bây giờ mình luôn tự tin , thoải mái mỗi khi cười và nhận được rất nhiều lời khen từ bạn bè và đối tác. ... <a href="/nguyen-quyen">Xem thêm</a></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/nguyen-tra-giang" title="NGUYỄN TRÀ GIANG"><img src="<?php echo e(asset('public/files/upload/default/medium/images/cam-nhan-khach-hang/nguyen-tra-giang3.png')); ?>" alt="NGUYỄN TRÀ GIANG"><span>Xem thêm</span></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/nguyen-tra-giang" title="NGUYỄN TRÀ GIANG">NGUYỄN TRÀ GIANG</a></h3>
                                    <div class="location">Boss <span>Mint beauty</span></div>
                                    <div class="desc">Răng của Giang trước đây gặp rất nhiều vấn đề, răng khấp khểnh, cười hở lợi và không được trắng sáng. ... <a href="/nguyen-tra-giang">Xem thêm</a></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/pong-chuan" title="PÔNG CHUẨN"><img src="<?php echo e(asset('public/files/upload/default/medium/images/cam-nhan-khach-hang/pong-chuan.png')); ?>" alt="PÔNG CHUẨN"><span>Xem thêm</span></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/pong-chuan" title="PÔNG CHUẨN">PÔNG CHUẨN</a></h3>
                                    <div class="location">Style list <span></span></div>
                                    <div class="desc"> Ai cũng khen răng mình đẹp, đi làm gặp nhiều anh chị nghệ sĩ đã làm răng rồi mà mọi người vẫn hỏi mình làm răng ở đâu, Mình ... <a href="/pong-chuan">Xem thêm</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="box_pagination">
                            <a href="javascript:;" class="active">1</a> <a href="/cam-nhan-khach-hang/page/2">2</a> <a href="/cam-nhan-khach-hang/page/2" class="next">Next</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="box_productCategoryHome bg_gray">
    <div class="container">
        <div class="box_title">
            <h2 class="title"><a href="/rang-su-tham-my" title="Răng sứ thẩm mỹ">Răng sứ thẩm mỹ</a></h2>
            <a href="/rang-su-tham-my" class="view_all">Xem tất cả</a>
        </div>
        <div class="box_desc">Win Smile tập trung cung cấp các dịch vụ nha khoa thẩm mỹ trong môi trường nhẹ nhàng, chu đáo, chuyên nghiệp. Đảm bảo mọi khách hàng tới Win Smile đều có những trải nhiệm nha khoa đẳng cấp, ưng ý nhất cho đường cười của chính mình. </div>
        <div class="box_content">
            <div class="row productGrid">
                <div class="col-sm-3 col-xs-6">
                    <div class="item">
                        <div class="image">
                            <a href="/dan-su-veneer" title="Dán sứ Veneer Emax Laminate"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/ngo-lan-huong.jpg')); ?>" alt="Dán sứ Veneer Emax Laminate"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/dan-su-veneer" title="Dán sứ Veneer Emax Laminate">Dán sứ Veneer Emax Laminate</a></h3>
                            <div class="price">Giá: <span class="value">Liên hệ</span></div>
                        </div>
                        <div class="control">
                            <a href="/dan-su-veneer" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-6">
                    <div class="item">
                        <div class="image">
                            <a href="/rang-su-lava-3m" title="Răng sứ Lava 3M Plus"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/quynh-kool.jpg')); ?>" alt="Răng sứ Lava 3M Plus"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/rang-su-lava-3m" title="Răng sứ Lava 3M Plus">Răng sứ Lava 3M Plus</a></h3>
                            <div class="price">Giá: <span class="value">Liên hệ</span></div>
                        </div>
                        <div class="control">
                            <a href="/rang-su-lava-3m" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-6">
                    <div class="item">
                        <div class="image">
                            <a href="/rang-su-orodent" title="Răng sứ Orodent"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/bui-bich-uyen.jpg')); ?>" alt="Răng sứ Orodent"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/rang-su-orodent" title="Răng sứ Orodent">Răng sứ Orodent</a></h3>
                            <div class="price">Giá: <span class="value">Liên hệ</span></div>
                        </div>
                        <div class="control">
                            <a href="/rang-su-orodent" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-6">
                    <div class="item">
                        <div class="image">
                            <a href="/rang-su-biodiamond" title="Răng sứ Bio Diamond"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/hoang-phi-huyen.jpg')); ?>" alt="Răng sứ Bio Diamond"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/rang-su-biodiamond" title="Răng sứ Bio Diamond">Răng sứ Bio Diamond</a></h3>
                            <div class="price">Giá: <span class="value">Liên hệ</span></div>
                        </div>
                        <div class="control">
                            <a href="/rang-su-biodiamond" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-6">
                    <div class="item">
                        <div class="image">
                            <a href="/rang-su-nacera" title="Răng sứ Nacera"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/nguyen-tat-kiem.jpg')); ?>" alt="Răng sứ Nacera"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/rang-su-nacera" title="Răng sứ Nacera">Răng sứ Nacera</a></h3>
                            <div class="price">Giá: <span class="value">Liên hệ</span></div>
                        </div>
                        <div class="control">
                            <a href="/rang-su-nacera" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-6">
                    <div class="item">
                        <div class="image">
                            <a href="/rang-su-nacera-q3" title="Răng sứ Nacera Q3"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/tran-quang-minh.jpg')); ?>" alt="Răng sứ Nacera Q3"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/rang-su-nacera-q3" title="Răng sứ Nacera Q3">Răng sứ Nacera Q3</a></h3>
                            <div class="price">Giá: <span class="value">Liên hệ</span></div>
                        </div>
                        <div class="control">
                            <a href="/rang-su-nacera-q3" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-6">
                    <div class="item">
                        <div class="image">
                            <a href="/rang-su-ceramill" title="Răng sứ Ceramill"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/nguyen-quyen.jpg')); ?>" alt="Răng sứ Ceramill"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/rang-su-ceramill" title="Răng sứ Ceramill">Răng sứ Ceramill</a></h3>
                            <div class="price">Giá: <span class="value">Liên hệ</span></div>
                        </div>
                        <div class="control">
                            <a href="/rang-su-ceramill" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-6">
                    <div class="item">
                        <div class="image">
                            <a href="/dan-su-veneer-lisi" title="Dán sứ Veneer Lisi"><img src="<?php echo e(asset('public/files/upload/default/thumbs/images/anh-thumb-home/nguyen-kieu-my.jpg')); ?>" alt="Dán sứ Veneer Lisi"></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="/dan-su-veneer-lisi" title="Dán sứ Veneer Lisi">Dán sứ Veneer Lisi</a></h3>
                            <div class="price">Giá: <span class="value">Liên hệ</span></div>
                        </div>
                        <div class="control">
                            <a href="/dan-su-veneer-lisi" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       <!--  <div class="control"><a href="/rang-su-tham-my" class="btn_yellow">Xem tất cả dịch vụ thẩm mỹ răng tại D'media</a></div> -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\cuong123\Desktop\New folder (2)\blog\resources\views/frontend/khachhang.blade.php ENDPATH**/ ?>