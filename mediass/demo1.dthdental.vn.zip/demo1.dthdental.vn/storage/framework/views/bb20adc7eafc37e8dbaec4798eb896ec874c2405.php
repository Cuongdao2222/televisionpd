

<?php $__env->startSection('content'); ?>

<div class="box_breadcrumb">
    <div class="container">
        <ul class="breadcrumb">
            <li><a href="/">Trang chủ</a></li>
            <li><a href="/lien-he" title="Liên hệ">Liên hệ</a></li>
        </ul>
    </div>
</div>
<div class="container">
    <div class="wrapper">
        <div class="row">
            <div class="col-sm-7">
                <form action="#" id="frmContact" name="frmContact" method="POST" class="form">
                    <div class="category_content">
                        <p><span style="color:#284b9c"><span style="font-size:26px">Đến với nha khoa thẩm mỹ Quốc tế D'media</span></span></p>
                        <p>Trải nghiệm sự kh&aacute;c biệt đến từ đội ngũ chuy&ecirc;n nghiệp.</p>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group" id="input-name">
                                <input type="text" name="name" class="form-control" placeholder="Họ và tên *">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group" id="input-phone">
                                <input type="text" name="phone" class="form-control" placeholder="Số điện thoại liên hệ *">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group" id="input-email">
                                <input type="text" name="email" class="form-control" placeholder="Email liên hệ *">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group" id="input-location">
                                <select name="location" class="form-control">
                                    <option value="">Chọn cơ sở gần bạn *</option>
                                    <option value="D'media Hà Nội">D'media Hà Nội</option>
                                    <option value="D'media Hồ Chí Minh">D'media Hồ Chí Minh</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group" id="input-content">
                                <textarea name="content" class="form-control" style="height: 80px;" placeholder="Lời nhắn"></textarea>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="note">
                                * Thông tin của bạn sẽ được bảo mật!
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="btnSuccess">
                                <input type="hidden" name="form_id" value="155819945236c7u33z2978">
                                <a href="javascript:;" onclick="alert('chức năng đang hoàn thiện, xin quay lại sau')" class="btn_yellow">Gửi thông tin</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-sm-5">
                <div class="image"><img src="<?php echo e(asset('public/files/upload/default/images/bai-viet/anh-contact.png')); ?>"></div>
            </div>
        </div>
    </div>
</div>
<div class="box_defaultCategoryFooter">
    <div class="container">
        <div class="box_title">
            <h2 class="title"><a href="/bao-chi-noi-ve-win-smile" title="Báo chí nói về Win Smile">Báo chí nói về Win Smile</a></h2>
            <a href="/bao-chi-noi-ve-win-smile" class="view_all">Xem tất cả</a>
        </div>
        <div class="box_desc"></div>
        <div class="box_content">
            <div class="slide">
                <div class="item">
                    <div class="image">
                        <a href="/nu-doanh-nhan-bich-uyen" title="Nữ doanh nhân Bích Uyên"><img src="<?php echo e(asset('public/files/upload/default/medium/images/bai-viet/baochi.png')); ?>" alt="Nữ doanh nhân Bích Uyên"><span>Xem thêm</span></a>
                    </div>
                    <div class="info">
                        <h3 class="title"><a href="/nu-doanh-nhan-bich-uyen" title="Nữ doanh nhân Bích Uyên">Nữ doanh nhân Bích Uyên</a></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dthdenta/public_html/demo1.dthdental.vn/resources/views/frontend/lienhe.blade.php ENDPATH**/ ?>