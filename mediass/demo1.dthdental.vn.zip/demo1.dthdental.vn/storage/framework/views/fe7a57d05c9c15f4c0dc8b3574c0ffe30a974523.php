<!-- Menu Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('menu_name', 'Menu Name:'); ?>

    <?php echo Form::text('menu_name', null, ['class' => 'form-control']); ?>

</div>

<!-- Menu Link Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('menu_link', 'Menu Link:'); ?>

    <?php echo Form::text('menu_link', null, ['class' => 'form-control']); ?>

</div><?php /**PATH C:\xampp\htdocs\blog\resources\views/menus/fields.blade.php ENDPATH**/ ?>