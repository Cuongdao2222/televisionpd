
@extends('frontend.layouts.app')

@section('content')
<?php 
    $image = new App\Models\banner();

    $image = $image->get();


    $news =  new \App\Models\post();

    $news = $news->orderBy('id')->take(6)->get(); 

?>

<div class="box_bxslider hidden-xs" id="box_bxslider">
            <div class="box_content">
                <ul class="bxslider">
                    @if(count($image)>0)
                    @foreach($image as $banner)
                    <li><a href=""><img src="{{ url( $banner->banner_image ) }}" alt="D'media - Thành công từ những nụ cười"></a></li>
                   
                    @endforeach
                    @endif
                </ul>
            </div>
        </div>
        <div class="box_bxslider_mobile hidden-sm hidden-md hidden-lg" id="box_bxslider_mobile">
            <div class="box_content">
                <ul class="bxslider">
                     @if(count($image)>0)
                    @foreach($image as $banner)
                    <li><a href=""><img src="{{ url( $banner->banner_image ) }}" alt="D'media - Thành công từ những nụ cười"></a></li>
                    @endforeach
                    @endif
                </ul>
            </div>
        </div>
        <div class="box_defaultHighlightCategory">
            <div class="container">
                <div class="wrapper">
                    <div class="box_wrap">
                        <div class="box_title">
                            <h1 class="title"><a href="/ve-D'media" title="Về D'media">Về D’ Dental</a></h1>
                        </div>
                        <div class="box_content">
                            <p>Được thành lập vào năm 2021 bởi đội ngũ Y Bác Sĩ giàu kinh nghiệm, nhiệt huyết với nghề, Nha khoa D’ Dental mang trong mình sứ mệnh đem đến nụ cười hạnh phúc và tự tin cho khách hàng. Hai yếu tố sức khoẻ và tính thẩm mỹ luôn được đội ngũ của D’ Dental đặt lên hàng đầu trong mọi dịch vụ của phòng khám đẻ đem đến cho khách hàng những trải nghiệm hài lòng nhất tại mọi cơ sở phòng khám của D’ Dental.
                            </p>
                            <div class="controls">
                              
                                <a href="javascript:;" class="view btn_yellow book go_box" data-box="box_book">Đặt lịch khám</a>
                            </div>
                        </div>
                    </div>
                    <div class="image"><img src="{{asset('public/files/upload/default/images/bai-viet/gioithieu.png')}}" style="
    width: 90%;"></div>
                </div>
            </div>
        </div>
        <div class="box_productCategoryHome">
            <div class="container">
                <div class="box_title">
                    <h2 class="title"><a href="/rang-su-tham-my" title="Răng sứ thẩm mỹ">Răng sứ thẩm mỹ</a></h2>
                    <a href="/rang-su-tham-my" class="view_all">Xem tất cả</a>
                </div>
                <div class="box_desc">D'media tập trung cung cấp các dịch vụ nha khoa thẩm mỹ trong môi trường nhẹ nhàng, chu đáo, chuyên nghiệp. Đảm bảo mọi khách hàng tới D'media đều có những trải nhiệm nha khoa đẳng cấp, ưng ý nhất cho đường cười của chính mình. </div>
                <div class="box_content">
                    <div class="row productGrid">
                        <div class="col-sm-3 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/dan-su-veneer" title="Dán sứ Veneer Emax Laminate"><img src="{{asset('public/files/upload/default/thumbs/images/anh-thumb-home/ngo-lan-huong.jpg')}}" alt="Dán sứ Veneer Emax Laminate"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/dan-su-veneer" title="Dán sứ Veneer Emax Laminate">Dán sứ Veneer Emax Laminate</a></h3>
                                    <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                </div>
                                <div class="control">
                                    <a href="/dan-su-veneer" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/rang-su-lava-3m" title="Răng sứ Lava 3M Plus"><img src="{{asset('public/files/upload/default/thumbs/images/anh-thumb-home/quynh-kool.jpg')}}" alt="Răng sứ Lava 3M Plus"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/rang-su-lava-3m" title="Răng sứ Lava 3M Plus">Răng sứ Lava 3M Plus</a></h3>
                                    <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                </div>
                                <div class="control">
                                    <a href="/rang-su-lava-3m" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/rang-su-orodent" title="Răng sứ Orodent"><img src="{{asset('public/files/upload/default/thumbs/images/anh-thumb-home/bui-bich-uyen.jpg')}}" alt="Răng sứ Orodent"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/rang-su-orodent" title="Răng sứ Orodent">Răng sứ Orodent</a></h3>
                                    <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                </div>
                                <div class="control">
                                    <a href="/rang-su-orodent" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/rang-su-biodiamond" title="Răng sứ Bio Diamond"><img src="{{asset('public/files/upload/default/thumbs/images/anh-thumb-home/hoang-phi-huyen.jpg')}}" alt="Răng sứ Bio Diamond"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/rang-su-biodiamond" title="Răng sứ Bio Diamond">Răng sứ Bio Diamond</a></h3>
                                    <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                </div>
                                <div class="control">
                                    <a href="/rang-su-biodiamond" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/rang-su-nacera" title="Răng sứ Nacera"><img src="{{asset('public/files/upload/default/thumbs/images/anh-thumb-home/nguyen-tat-kiem.jpg')}}" alt="Răng sứ Nacera"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/rang-su-nacera" title="Răng sứ Nacera">Răng sứ Nacera</a></h3>
                                    <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                </div>
                                <div class="control">
                                    <a href="/rang-su-nacera" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/rang-su-nacera-q3" title="Răng sứ Nacera Q3"><img src="{{asset('public/files/upload/default/thumbs/images/anh-thumb-home/tran-quang-minh.jpg')}}" alt="Răng sứ Nacera Q3"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/rang-su-nacera-q3" title="Răng sứ Nacera Q3">Răng sứ Nacera Q3</a></h3>
                                    <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                </div>
                                <div class="control">
                                    <a href="/rang-su-nacera-q3" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/rang-su-ceramill" title="Răng sứ Ceramill"><img src="{{asset('public/files/upload/default/thumbs/images/anh-thumb-home/nguyen-quyen.jpg')}}" alt="Răng sứ Ceramill"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/rang-su-ceramill" title="Răng sứ Ceramill">Răng sứ Ceramill</a></h3>
                                    <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                </div>
                                <div class="control">
                                    <a href="/rang-su-ceramill" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3 col-xs-6">
                            <div class="item">
                                <div class="image">
                                    <a href="/dan-su-veneer-lisi" title="Dán sứ Veneer Lisi"><img src="{{asset('public/files/upload/default/thumbs/images/anh-thumb-home/nguyen-kieu-my.jpg')}}" alt="Dán sứ Veneer Lisi"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/dan-su-veneer-lisi" title="Dán sứ Veneer Lisi">Dán sứ Veneer Lisi</a></h3>
                                    <div class="price">Giá: <span class="value">Liên hệ</span></div>
                                </div>
                                <div class="control">
                                    <a href="/dan-su-veneer-lisi" class="add_card"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Đặt hàng</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="control"><a href="/rang-su-tham-my" class="btn_yellow">Xem tất cả dịch vụ </a></div>
            </div>
        </div>
        <div class="box_serviceCategoryHome">
            <div class="container">
                <div class="box_title">
                    <h2 class="title"><a href="/nha-khoa-benh-ly" title="Nha khoa bệnh lý">Nha khoa bệnh lý</a></h2>
                    <a href="/nha-khoa-benh-ly" class="view_all">Xem tất cả</a>
                </div>
                <div class="box_desc">Triết lý của D'media sẽ giúp bạn khỏe mạnh, hạnh phúc vì chúng tôi hiểu vai trò quan trọng trong sức khỏe răng miệng và chất lượng cuộc sống của bạn.</div>
                <div class="box_content">
                    <div class="slide">
                        <?php 
                            $benhly =  App\Models\post::whereIn('id', [30, 31, 32,33,34,35,36,37])->get();

                        ?>

                        @if(count($benhly)>0)
                        @foreach($benhly as $newss)
                        <div class="item">
                            <div class="image">
                                <a href="{{ route('single', @$newss['link']) }}" title="{{ @$newss['title'] }}"><img src="{{  @url($newss['image']) }}" alt="{{ @$newss['title'] }}"><span>Xem thêm</span></a>
                            </div>
                            <div class="info">
                                <h3 class="title"><a href="{{ route('single', @$newss['link']) }}" title="{{ @$newss['title'] }}">{{ @$newss['title'] }}
                            </div>
                        </div>
                         @endforeach
                         @endif
                       
                    </div>
                </div>
            </div>
        </div>
        <div class="box_defaultCategoryHome">
            <div class="container">
                <div class="box_title">
                    <h2 class="title"><a href="/tin-tuc-su-kien" title="Tin Tức / Sự Kiện">Tin Tức / Sự Kiện</a></h2>
                </div>
                <div class="box_desc">Các Tin Tức / Sự Kiện nổi bật của hệ thống Nha Khoa Thẩm Mỹ Quốc Tế D'media.</div>
                <div class="box_content">
                    <div class="row">


                        @if(count($news)>=6)
                        @foreach($news as $newss)
                        <div class="col-sm-6 col-xs-12">
                            <div class="item">
                                <div class="image">
                                    <a href="{{ route('single', @$newss['link']) }}" title="{{ @$newss['title'] }}"><img src="{{  @url($newss['image']) }}" alt="{{ @$newss['title'] }}"></a>
                                </div>


                                <div class="info">
                                    <h3 class="title"><a href="" title="{{ @$newss['title'] }}"> {{ $newss['title'] }}</a></h3>
                                    <div class="desc"> {!! _substrs(@$newss['content'],150) !!}<a href="{{ route('single', @$newss['link']) }}">Xem thêm</a></div>
                                    <span class="date">Ngày {{ date('d/m/Y',strtotime( $newss['created_at'])) }}   </span>
                                </div>
                            </div>
                        </div>
                        @endforeach
                        @endif
                       
                       
                    </div>
                </div>
                <div class="control"><a href="/tin-tuc-su-kien" class="btn_yellow">Xem thêm các tin tức mới</a></div>
            </div>
        </div>
        <div class="box_feedbackCategoryHome">
            <div class="container">
                <div class="box_title">
                    <h2 class="title"><a href="/cam-nhan-khach-hang" title="Khách hàng nói gì về D'media?">Khách hàng nói gì về D'media?</a></h2>
                    <a href="/cam-nhan-khach-hang" class="view_all">Xem tất cả</a>
                </div>
                <div class="box_desc"></div>
                <div class="box_content">
                    <div class="slide">
                        <div class="item">
                            <div class="item_content">Làm xong cũng chẳng đau gì chỉ thấy đẹp thôi, mình tự tin hát và trước ống kính lắm rồi.</div>
                            <div class="item_info">
                                <div class="image">
                                    <a href="/thuong-cin" title="THƯƠNG CIN"><img src="{{asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/thuong-cin-2.png')}}" alt="THƯƠNG CIN"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/thuong-cin" title="THƯƠNG CIN">THƯƠNG CIN</a></h3>
                                    <div class="desc">Diễn viên <span></span></div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="item_content">Răng của Huyền trước đây khá đều, tuy nhiên lại không được trắng sáng. Dù không tự ti nhưng là 1 Boss của hệ thống hơn 1000 người thì hình ảnh nụ cười rạng rỡ chính là yếu tố khiến Huyền luôn được yêu mến và tin tưởng.</div>
                            <div class="item_info">
                                <div class="image">
                                    <a href="/hoang-phi-huyen" title="HOÀNG PHI HUYỀN"><img src="{{asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/hoang-phi-huyen.png')}}" alt="HOÀNG PHI HUYỀN"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/hoang-phi-huyen" title="HOÀNG PHI HUYỀN">HOÀNG PHI HUYỀN</a></h3>
                                    <div class="desc">Boss <span>Huyền Phi Comestic</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="item_content">Hiện tại Nụ cười rạng rỡ mà D'media mang lại cho tôi đó chính là niềm tin yêu của học viên và sự quý trọng của đối tác. Cám ơn D'media luôn đồng hành cùng tôi trên con đường thành công.</div>
                            <div class="item_info">
                                <div class="image">
                                    <a href="/nguyen-tat-kiem" title="NGUYỄN TẤT KIỂM"><img src="{{asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/nguyen-tat-kiem.png')}}" alt="NGUYỄN TẤT KIỂM"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/nguyen-tat-kiem" title="NGUYỄN TẤT KIỂM">NGUYỄN TẤT KIỂM</a></h3>
                                    <div class="desc">CEO <span>TAKA ACADEMY</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="item_content">Bây giờ mình luôn tự tin , thoải mái mỗi khi cười và nhận được rất nhiều lời khen từ bạn bè và đối tác.</div>
                            <div class="item_info">
                                <div class="image">
                                    <a href="/nguyen-quyen" title="NGUYỄN QUYÊN"><img src="{{asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/nguyen-quyen.png')}}" alt="NGUYỄN QUYÊN"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/nguyen-quyen" title="NGUYỄN QUYÊN">NGUYỄN QUYÊN</a></h3>
                                    <div class="desc">Boss <span>Mỹ phẩm Herrin Care</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="item_content">Răng của Giang trước đây gặp rất nhiều vấn đề, răng khấp khểnh, cười hở lợi và không được trắng sáng. </div>
                            <div class="item_info">
                                <div class="image">
                                    <a href="/nguyen-tra-giang" title="NGUYỄN TRÀ GIANG"><img src="{{asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/nguyen-tra-giang3.png')}}" alt="NGUYỄN TRÀ GIANG"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/nguyen-tra-giang" title="NGUYỄN TRÀ GIANG">NGUYỄN TRÀ GIANG</a></h3>
                                    <div class="desc">Boss <span>Mint beauty</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="item_content"> Ai cũng khen răng mình đẹp, đi làm gặp nhiều anh chị nghệ sĩ đã làm răng rồi mà mọi người vẫn hỏi mình làm răng ở đâu, Mình cảm ơn D'media rất nhiều.</div>
                            <div class="item_info">
                                <div class="image">
                                    <a href="/pong-chuan" title="PÔNG CHUẨN"><img src="{{asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/pong-chuan.png')}}" alt="PÔNG CHUẨN"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/pong-chuan" title="PÔNG CHUẨN">PÔNG CHUẨN</a></h3>
                                    <div class="desc">Style list <span></span></div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="item_content">Một người khó tính và sợ đau như Tùng mà sau khi bọc răng sứ tại D'media còn cảm thấy hài lòng thì Tùng nghĩ dịch vụ tại D'media rất đáng để trải nghiệm.</div>
                            <div class="item_info">
                                <div class="image">
                                    <a href="/tung-min" title="TÙNG MIN"><img src="{{asset('public/files/upload/default/thumbs/images/cam-nhan-khach-hang/tung-min.png')}}" alt="TÙNG MIN"></a>
                                </div>
                                <div class="info">
                                    <h3 class="title"><a href="/tung-min" title="TÙNG MIN">TÙNG MIN</a></h3>
                                    <div class="desc">Diễn viên <span></span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

@endsection