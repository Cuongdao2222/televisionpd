@extends('frontend.layouts.app')

@section('content')

<div class="container">
    <div class="wrapper">
        <div class="row">
            <div class="col-sm-9 col-sm-push-3">
                <div class="container">
                    <div class="box_module">
                        <div class="box_title">
                            <h1 class="title"><a href="/nha-khoa-benh-ly" title="Nha khoa bệnh lý">Nha khoa bệnh lý</a></h1>
                        </div>
                        <div class="box_content">
                            <div class="layout_category_product">
                                <div class="productGrid service">
                                    <div class="row">

                                        <?php 
                                            $news =  App\Models\post::whereIn('id', [30, 31, 32,33,34,35,36,37])->get();

                                        ?>
                                        @if(count($news)>0)
                                        @foreach($news as $newss)
                                        <div class="col-sm-3 col-xs-6">
                                            <div class="item">
                                                <div class="image">
                                                    <a href="{{ route('single', @$newss['link']) }}" title="{{ @$newss['title'] }}"><img src="{{  @url($newss['image']) }}" alt="{{ @$newss['title'] }}"><span>Xem thêm</span></a>
                                                </div>
                                                <div class="info">
                                                    <h3 class="title"><a href="{{ route('single', @$newss['link']) }}" title="{{ @$newss['title'] }}">{{ @$newss['title'] }}</a></h3>
                                                </div>
                                            </div>
                                        </div>
                                        @endforeach
                                        @endif

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-3 col-sm-pull-9">
                <div class="box_support" id="box_support">
                    <div class="box_title">
                        <div class="title">Hỗ trợ trực tuyến</div>
                    </div>
                    <div class="box_content">
                        <div class="item">
                            <div class="name"><i class="fa fa-user" aria-hidden="true"></i> Hỗ trợ trực tuyến 24/7</div>
                            <div class="phone"><i class="fas fa-mobile-alt"></i> 0987 654 321 - 0987 654 321</div>
                            <div class="zalo"><i class="far fa-zalo">Z</i> 0987 654 321 - 0987 654 321</div>
                            <div class="email"><i class="far fa-envelope"></i> </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection