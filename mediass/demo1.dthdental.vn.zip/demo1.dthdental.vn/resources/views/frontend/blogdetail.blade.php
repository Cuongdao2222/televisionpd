@extends('frontend.layouts.app')

@section('content')
<?php  
    $news =  new \App\Models\post();

    $news = $news->orderBy('id')->take(6)->get();  
?>

<div class="box_breadcrumb">
    <div class="container">
        <ul class="breadcrumb">
            <li><a href="/">Trang chủ</a></li>
            <li><a href="/blog" title="Blog kiến thức">Tin tức</a></li>
            <li><a href="{{ route('single', @$datas['link']) }}" title="{{ @$datas['title'] }}">{{ @$datas['title'] }}</a></li>
          
        </ul>
    </div>
</div>
<div class="container">
    <div class="wrapper">
        <div class="row">
            <div class="col-sm-8">
                <div class="box_module">
                    <div class="box_title">
                        <h1 class="title"><a href="{{ route('single', @$datas['link']) }}" title="Tiết lộ bí mật ít người biết về chỉnh nha không mắc cài Invisalign">{{ @$datas['title'] }}</a></h1>
                    </div>
                    <div class="box_content">
                        <div class="layout_item_default">
                            {!! @$datas['content'] !!}
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 hidden-xs">
                <div style="padding-left: 20px;">
                    <div class="box_adsRight" id="box_adsRight">
                        <a href="" title="Ảnh 1"><img src="/public/files/upload/default/images/quang-cao/ads-right.jpg" alt="Ảnh 1"></a>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<div class="box_defaultCategoryHot">
    <div class="container">
        <div class="box_title">
            <h2 class="title">Kiến thức khác</h2>
        </div>
        <div class="box_content">
            <div class="row">
                @if(count($news)>5)
                @foreach($news as $newss)
                <div class="col-sm-4 col-xs-6">
                    <div class="item">
                        <div class="image">
                            <a href="{{ route('single', @$newss['link']) }}" title="{{ @$newss['title'] }}"><img src="{{  @url($newss['image']) }}" alt="{{ @$newss['title'] }}"><span>Xem thêm</span></a>
                        </div>
                        <div class="info">
                            <h3 class="title"><a href="{{ route('single', @$newss['link']) }}" title="{{ @$newss['title'] }}">{{ @$newss['title'] }}</a></h3>
                            <span class="category">Chuyên mục <a href="/kien-thuc" title="Kiến thức">Kiến thức</a></span><span class="date">Ngày 30/07/2020</span>
                            <div class="desc">{!! @_substrs($newss['content'], 150) !!} <a href="{{ route('single', @$newss['link']) }}">Xem thêm</a></div>
                        </div>
                    </div>
                </div>

                @endforeach
                @endif
               
               
            </div>
        </div>
    </div>
</div>
@endsection