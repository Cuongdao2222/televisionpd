<!-- Menu Name Field -->
<div class="form-group col-sm-6">
    {!! Form::label('menu_name', 'Menu Name:') !!}
    {!! Form::text('menu_name', null, ['class' => 'form-control']) !!}
</div>

<!-- Menu Link Field -->
<div class="form-group col-sm-6">
    {!! Form::label('menu_link', 'Menu Link:') !!}
    {!! Form::text('menu_link', null, ['class' => 'form-control']) !!}
</div>